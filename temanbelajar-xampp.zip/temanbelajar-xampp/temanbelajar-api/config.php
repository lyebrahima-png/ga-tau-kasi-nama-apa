<?php
// Pengaturan API. Nilai bawaan cocok untuk XAMPP (user root tanpa kata sandi).
return [
    'db' => [
        'host' => '127.0.0.1',
        'port' => 3306,
        'name' => 'temanbelajar',
        'user' => 'root',
        'pass' => '',
    ],

    // GANTI dengan kalimat acak yang panjang sebelum dipakai sungguhan.
    'jwt_secret' => 'ganti-dengan-kalimat-rahasia-yang-panjang-dan-acak',
    'jwt_ttl'    => 604800, // masa berlaku token: 7 hari (detik)

    // Alamat frontend yang boleh memanggil API langsung (CORS).
    // Tidak dipakai bila frontend memakai proxy Vite atau satu domain dengan API.
    'cors_origins' => ['http://localhost:5173', 'http://127.0.0.1:5173'],

    // Unggah materi
    'max_upload_mb' => 20,
    'allowed_ext'   => ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'xls', 'xlsx', 'txt', 'csv',
                        'png', 'jpg', 'jpeg', 'gif', 'zip', 'rar', 'mp4', 'mp3'],
];
