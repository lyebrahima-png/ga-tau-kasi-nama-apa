-- TemanBelajar: skema + data contoh untuk MySQL/MariaDB (XAMPP)
-- Cara pakai: phpMyAdmin > tab Import > pilih file ini > Import.
-- File ini membuat database `temanbelajar`. Aman diimpor ulang (data lama dihapus).

DROP DATABASE IF EXISTS temanbelajar;
CREATE DATABASE temanbelajar CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE temanbelajar;

CREATE TABLE users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','user','petugas') NOT NULL DEFAULT 'user',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE mentor_profiles (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL UNIQUE,
  expertise VARCHAR(150) NOT NULL,
  education_level VARCHAR(50) NOT NULL,
  verification_status ENUM('pending','verified','rejected') NOT NULL DEFAULT 'pending',
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE study_groups (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  mentor_id INT UNSIGNED NULL,
  title VARCHAR(150) NOT NULL,
  subject VARCHAR(100) NOT NULL,
  description TEXT NULL,
  capacity INT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (mentor_id) REFERENCES mentor_profiles(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE group_members (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  group_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'active',
  UNIQUE KEY uq_group_user (group_id, user_id),
  FOREIGN KEY (group_id) REFERENCES study_groups(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE study_sessions (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  group_id INT UNSIGNED NOT NULL,
  session_date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  topic VARCHAR(200) NOT NULL,
  FOREIGN KEY (group_id) REFERENCES study_groups(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE session_registrations (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  session_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'registered',
  UNIQUE KEY uq_session_user (session_id, user_id),
  FOREIGN KEY (session_id) REFERENCES study_sessions(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE files (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  original_name VARCHAR(255) NOT NULL,
  stored_name VARCHAR(255) NOT NULL,
  mime_type VARCHAR(100) NULL,
  size INT UNSIGNED NULL
) ENGINE=InnoDB;

CREATE TABLE learning_materials (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  group_id INT UNSIGNED NOT NULL,
  title VARCHAR(200) NOT NULL,
  file_id INT UNSIGNED NULL,
  description TEXT NULL,
  FOREIGN KEY (group_id) REFERENCES study_groups(id) ON DELETE CASCADE,
  FOREIGN KEY (file_id) REFERENCES files(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE learning_progress (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  group_id INT UNSIGNED NOT NULL,
  progress_note TEXT NOT NULL,
  progress_date DATE NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (group_id) REFERENCES study_groups(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE mentor_reviews (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  mentor_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  rating TINYINT UNSIGNED NOT NULL,
  review TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CHECK (rating BETWEEN 1 AND 5),
  FOREIGN KEY (mentor_id) REFERENCES mentor_profiles(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- Data contoh ----------
-- admin@temanbelajar.id / admin123, petugas@temanbelajar.id / petugas123,
-- user@temanbelajar.id / user123,   mentor@temanbelajar.id / mentor123
INSERT INTO users (name, email, password_hash, role) VALUES
 ('Admin TemanBelajar', 'admin@temanbelajar.id',   '$2y$10$dv2A40gV2XEEU77bnvdUtOi3wrO5bmwOfG0V7Eddfv1uMEhEQ6TFu',   'admin'),
 ('Petugas Satu',       'petugas@temanbelajar.id', '$2y$10$FJ.aNjrbR1sdGXHn05jPLeDGn8meJ2/LfoBUE44OmSlmGH4.EUsT.', 'petugas'),
 ('Budi Pelajar',       'user@temanbelajar.id',    '$2y$10$OKsXpyUUKEhrK8Y5ChoDguScda/Li1LVahRS7bzDqPZs9k.XJ.Xnm',    'user'),
 ('Sari Mentor',        'mentor@temanbelajar.id',  '$2y$10$up/qNPLcinqInlPFYblXCeXpMLi/lQ2t14vy9agJ47M0SHCNwNeXq',  'user');

INSERT INTO mentor_profiles (user_id, expertise, education_level, verification_status)
VALUES (4, 'Matematika dan Fisika', 'S2', 'verified');

INSERT INTO study_groups (mentor_id, title, subject, description, capacity) VALUES
 (1, 'Persiapan UTBK Matematika', 'Matematika',
  'Latihan soal dan pembahasan setiap minggu untuk persiapan UTBK.', 15);

INSERT INTO study_sessions (group_id, session_date, start_time, end_time, topic)
VALUES (1, DATE_ADD(CURDATE(), INTERVAL 3 DAY), '19:00:00', '20:30:00', 'Limit dan turunan');

INSERT INTO group_members (group_id, user_id) VALUES (1, 3);
