<?php
// Sesi, materi, progres, dan ulasan.

// POST /sessions  (petugas, admin)
function h_session_create($params, $user)
{
    $b = body();
    need($b, ['group_id', 'session_date', 'start_time', 'end_time', 'topic']);
    $groupId = to_id($b['group_id'], 'group_id');
    if (!db_one('SELECT id FROM study_groups WHERE id = ?', [$groupId])) {
        throw new HttpError(404, 'Kelompok tidak ditemukan.');
    }
    if (!valid_date($b['session_date'])) {
        throw new HttpError(400, 'Format tanggal harus YYYY-MM-DD.');
    }
    if (!valid_time($b['start_time']) || !valid_time($b['end_time'])) {
        throw new HttpError(400, 'Format jam harus HH:MM.');
    }
    if ($b['end_time'] <= $b['start_time']) {
        throw new HttpError(400, 'Jam selesai harus setelah jam mulai.');
    }
    db_run(
        'INSERT INTO study_sessions (group_id, session_date, start_time, end_time, topic) VALUES (?, ?, ?, ?, ?)',
        [$groupId, $b['session_date'], $b['start_time'], $b['end_time'], trim((string) $b['topic'])]
    );
    $row = db_one('SELECT * FROM study_sessions WHERE id = ?', [db_id()]);
    json_out(session_clean($row), 201);
}

// POST /sessions/{id}/register  — hanya anggota kelompok
function h_session_register($params, $user)
{
    $id = to_id($params['id']);
    $session = db_one('SELECT * FROM study_sessions WHERE id = ?', [$id]);
    if (!$session) {
        throw new HttpError(404, 'Sesi tidak ditemukan.');
    }
    $member = db_one(
        "SELECT 1 AS ok FROM group_members WHERE group_id = ? AND user_id = ? AND status = 'active'",
        [$session['group_id'], $user['id']]
    );
    if (!$member) {
        throw new HttpError(403, 'Bergabunglah ke kelompok ini terlebih dahulu.');
    }
    if (db_one('SELECT id FROM session_registrations WHERE session_id = ? AND user_id = ?', [$id, $user['id']])) {
        throw new HttpError(409, 'Kamu sudah terdaftar di sesi ini.');
    }
    db_run('INSERT INTO session_registrations (session_id, user_id) VALUES (?, ?)', [$id, $user['id']]);
    json_out(['message' => 'Pendaftaran sesi berhasil.', 'session_id' => $id], 201);
}

// POST /materials  (petugas, admin) — multipart (field "file" opsional) atau JSON
function h_material_create($params, $user)
{
    $type = isset($_SERVER['CONTENT_TYPE']) ? $_SERVER['CONTENT_TYPE'] : '';
    if (empty($_POST) && empty($_FILES)
        && (int) (isset($_SERVER['CONTENT_LENGTH']) ? $_SERVER['CONTENT_LENGTH'] : 0) > 0
        && stripos($type, 'multipart') !== false) {
        throw new HttpError(413, 'Ukuran file melebihi batas server (atur post_max_size di php.ini).');
    }

    $b = body();
    need($b, ['group_id', 'title']);
    $groupId = to_id($b['group_id'], 'group_id');
    if (!db_one('SELECT id FROM study_groups WHERE id = ?', [$groupId])) {
        throw new HttpError(404, 'Kelompok tidak ditemukan.');
    }

    $fileId = null;
    $url = null;
    if (isset($_FILES['file']) && $_FILES['file']['error'] !== UPLOAD_ERR_NO_FILE) {
        $f = $_FILES['file'];
        if ($f['error'] !== UPLOAD_ERR_OK) {
            $tooBig = $f['error'] === UPLOAD_ERR_INI_SIZE || $f['error'] === UPLOAD_ERR_FORM_SIZE;
            throw new HttpError(400, $tooBig ? 'Ukuran file terlalu besar.' : 'Gagal mengunggah file.');
        }
        if ($f['size'] > (int) cfg('max_upload_mb', 20) * 1024 * 1024) {
            throw new HttpError(400, 'Ukuran file maksimal ' . cfg('max_upload_mb', 20) . ' MB.');
        }
        $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, cfg('allowed_ext', []), true)) {
            throw new HttpError(400, 'Jenis file tidak diizinkan.');
        }
        $dir = __DIR__ . '/../uploads';
        if (!is_dir($dir)) {
            mkdir($dir, 0775, true);
        }
        $stored = bin2hex(random_bytes(16)) . '.' . $ext;
        if (!move_uploaded_file($f['tmp_name'], $dir . '/' . $stored)) {
            throw new HttpError(500, 'File tidak dapat disimpan di server.');
        }
        db_run(
            'INSERT INTO files (original_name, stored_name, mime_type, size) VALUES (?, ?, ?, ?)',
            [basename($f['name']), $stored, isset($f['type']) ? $f['type'] : null, (int) $f['size']]
        );
        $fileId = db_id();
        $url = file_url($stored);
    }

    db_run(
        'INSERT INTO learning_materials (group_id, title, file_id, description) VALUES (?, ?, ?, ?)',
        [$groupId, trim((string) $b['title']), $fileId, isset($b['description']) ? (string) $b['description'] : '']
    );
    json_out([
        'id'       => db_id(),
        'group_id' => $groupId,
        'title'    => trim((string) $b['title']),
        'file_id'  => $fileId,
        'url'      => $url,
    ], 201);
}

// POST /progress — mencatat progres milik pengguna yang sedang masuk
function h_progress_create($params, $user)
{
    $b = body();
    need($b, ['group_id', 'progress_note', 'progress_date']);
    $groupId = to_id($b['group_id'], 'group_id');
    if (!db_one('SELECT id FROM study_groups WHERE id = ?', [$groupId])) {
        throw new HttpError(404, 'Kelompok tidak ditemukan.');
    }
    if (!valid_date($b['progress_date'])) {
        throw new HttpError(400, 'Format tanggal harus YYYY-MM-DD.');
    }
    db_run(
        'INSERT INTO learning_progress (user_id, group_id, progress_note, progress_date) VALUES (?, ?, ?, ?)',
        [$user['id'], $groupId, trim((string) $b['progress_note']), $b['progress_date']]
    );
    json_out(db_one('SELECT * FROM learning_progress WHERE id = ?', [db_id()]), 201);
}

// GET /progress — riwayat progres milik sendiri
function h_progress_list($params, $user)
{
    json_out(db_all(
        'SELECT p.*, g.title AS group_title FROM learning_progress p
         JOIN study_groups g ON g.id = p.group_id
         WHERE p.user_id = ? ORDER BY p.progress_date DESC, p.id DESC',
        [$user['id']]
    ));
}

// POST /reviews
function h_review_create($params, $user)
{
    $b = body();
    need($b, ['mentor_id', 'rating', 'review']);
    $mentorId = to_id($b['mentor_id'], 'mentor_id');
    $rating = filter_var($b['rating'], FILTER_VALIDATE_INT);
    if ($rating === false || $rating < 1 || $rating > 5) {
        throw new HttpError(400, 'Rating harus bilangan bulat 1 sampai 5.');
    }
    $mentor = db_one('SELECT user_id FROM mentor_profiles WHERE id = ?', [$mentorId]);
    if (!$mentor) {
        throw new HttpError(404, 'Mentor tidak ditemukan.');
    }
    if ((int) $mentor['user_id'] === $user['id']) {
        throw new HttpError(400, 'Kamu tidak bisa menilai dirimu sendiri.');
    }
    db_run(
        'INSERT INTO mentor_reviews (mentor_id, user_id, rating, review) VALUES (?, ?, ?, ?)',
        [$mentorId, $user['id'], $rating, trim((string) $b['review'])]
    );
    json_out(db_one('SELECT * FROM mentor_reviews WHERE id = ?', [db_id()]), 201);
}
