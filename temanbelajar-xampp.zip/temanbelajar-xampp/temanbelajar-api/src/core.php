<?php
// Fungsi dasar: konfigurasi, database, JSON, validasi, JWT, autentikasi.

class HttpError extends Exception
{
    public $status;

    public function __construct($status, $message)
    {
        parent::__construct($message);
        $this->status = $status;
    }
}

function cfg($key, $default = null)
{
    static $config = null;
    if ($config === null) {
        $config = require __DIR__ . '/../config.php';
    }
    $value = $config;
    foreach (explode('.', $key) as $part) {
        if (!is_array($value) || !array_key_exists($part, $value)) {
            return $default;
        }
        $value = $value[$part];
    }
    return $value;
}

function json_out($data, $status = 200)
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

// ---------- Database ----------

function db()
{
    static $pdo = null;
    if ($pdo === null) {
        $dsn = sprintf(
            'mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
            cfg('db.host'),
            cfg('db.port'),
            cfg('db.name')
        );
        $pdo = new PDO($dsn, cfg('db.user'), cfg('db.pass'), [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    }
    return $pdo;
}

function db_run($sql, $params = [])
{
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt;
}

function db_one($sql, $params = [])
{
    $row = db_run($sql, $params)->fetch();
    return $row ? $row : null;
}

function db_all($sql, $params = [])
{
    return db_run($sql, $params)->fetchAll();
}

function db_id()
{
    return (int) db()->lastInsertId();
}

// ---------- Request ----------

// Isi request sebagai array: JSON atau form (multipart / urlencoded).
function body()
{
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }
    $type = isset($_SERVER['CONTENT_TYPE']) ? $_SERVER['CONTENT_TYPE'] : '';
    if (stripos($type, 'application/json') !== false) {
        $raw = file_get_contents('php://input');
        $data = json_decode($raw, true);
        if ($raw !== '' && !is_array($data)) {
            throw new HttpError(400, 'Format JSON tidak valid.');
        }
        $cache = is_array($data) ? $data : [];
    } else {
        $cache = $_POST;
    }
    return $cache;
}

function need($data, $fields)
{
    $missing = [];
    foreach ($fields as $f) {
        if (!isset($data[$f]) || !is_scalar($data[$f]) || trim((string) $data[$f]) === '') {
            $missing[] = $f;
        }
    }
    if ($missing) {
        throw new HttpError(400, 'Field wajib diisi: ' . implode(', ', $missing));
    }
}

function to_id($value, $label = 'id')
{
    $n = filter_var($value, FILTER_VALIDATE_INT);
    if ($n === false || $n < 1) {
        throw new HttpError(400, $label . ' tidak valid.');
    }
    return $n;
}

function valid_date($s)
{
    if (!is_string($s) || !preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $s, $m)) {
        return false;
    }
    return checkdate((int) $m[2], (int) $m[3], (int) $m[1]);
}

function valid_time($s)
{
    return is_string($s) && preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $s) === 1;
}

// Alamat dasar API, mis. http://localhost/temanbelajar-api
function base_url()
{
    $https = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';
    $dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
    return ($https ? 'https' : 'http') . '://' . $host . $dir;
}

function file_url($storedName)
{
    return base_url() . '/uploads/' . rawurlencode($storedName);
}

// ---------- JWT (HS256) ----------

function b64url_encode($s)
{
    return rtrim(strtr(base64_encode($s), '+/', '-_'), '=');
}

function b64url_decode($s)
{
    return base64_decode(strtr($s, '-_', '+/'));
}

function jwt_encode($payload)
{
    $head = b64url_encode(json_encode(['alg' => 'HS256', 'typ' => 'JWT']));
    $body = b64url_encode(json_encode($payload));
    $sig = b64url_encode(hash_hmac('sha256', $head . '.' . $body, cfg('jwt_secret'), true));
    return $head . '.' . $body . '.' . $sig;
}

function jwt_decode($token)
{
    $parts = explode('.', $token);
    if (count($parts) !== 3) {
        return null;
    }
    list($head, $body, $sig) = $parts;
    $expected = b64url_encode(hash_hmac('sha256', $head . '.' . $body, cfg('jwt_secret'), true));
    if (!hash_equals($expected, $sig)) {
        return null;
    }
    $payload = json_decode(b64url_decode($body), true);
    if (!is_array($payload)) {
        return null;
    }
    if (isset($payload['exp']) && $payload['exp'] < time()) {
        return null;
    }
    return $payload;
}

// ---------- Autentikasi ----------

function auth_header()
{
    if (!empty($_SERVER['HTTP_AUTHORIZATION'])) {
        return $_SERVER['HTTP_AUTHORIZATION'];
    }
    if (!empty($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
        return $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
    }
    if (function_exists('getallheaders')) {
        foreach (getallheaders() as $name => $value) {
            if (strtolower($name) === 'authorization') {
                return $value;
            }
        }
    }
    return '';
}

// Pengguna yang sedang masuk. Peran dibaca dari database agar perubahan peran
// (mis. lewat phpMyAdmin) langsung berlaku.
function current_user()
{
    $header = auth_header();
    if (stripos($header, 'Bearer ') !== 0) {
        throw new HttpError(401, 'Silakan masuk terlebih dahulu.');
    }
    $payload = jwt_decode(trim(substr($header, 7)));
    if (!$payload || !isset($payload['id'])) {
        throw new HttpError(401, 'Sesi berakhir, silakan masuk lagi.');
    }
    $user = db_one('SELECT id, name, role FROM users WHERE id = ?', [$payload['id']]);
    if (!$user) {
        throw new HttpError(401, 'Akun tidak ditemukan.');
    }
    $user['id'] = (int) $user['id'];
    return $user;
}

function public_user($u)
{
    return [
        'id'    => (int) $u['id'],
        'name'  => $u['name'],
        'email' => $u['email'],
        'role'  => $u['role'],
    ];
}

function token_for($u)
{
    $now = time();
    return jwt_encode([
        'id'   => (int) $u['id'],
        'role' => $u['role'],
        'iat'  => $now,
        'exp'  => $now + (int) cfg('jwt_ttl', 604800),
    ]);
}
