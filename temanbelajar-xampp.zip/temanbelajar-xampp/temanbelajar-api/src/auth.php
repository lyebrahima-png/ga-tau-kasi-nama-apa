<?php
// POST /auth/register, POST /auth/login, GET /auth/me

function h_register($params, $user)
{
    $b = body();
    need($b, ['name', 'email', 'password']);
    $email = strtolower(trim((string) $b['email']));
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new HttpError(400, 'Format email tidak valid.');
    }
    if (strlen((string) $b['password']) < 6) {
        throw new HttpError(400, 'Kata sandi minimal 6 karakter.');
    }
    if (db_one('SELECT id FROM users WHERE email = ?', [$email])) {
        throw new HttpError(409, 'Email sudah terdaftar.');
    }

    // Pendaftaran publik selalu berperan "user".
    db_run(
        "INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, 'user')",
        [trim((string) $b['name']), $email, password_hash((string) $b['password'], PASSWORD_BCRYPT)]
    );
    $row = db_one('SELECT * FROM users WHERE id = ?', [db_id()]);
    json_out(['token' => token_for($row), 'user' => public_user($row)], 201);
}

function h_login($params, $user)
{
    $b = body();
    need($b, ['email', 'password']);
    $row = db_one('SELECT * FROM users WHERE email = ?', [strtolower(trim((string) $b['email']))]);
    if (!$row || !password_verify((string) $b['password'], $row['password_hash'])) {
        throw new HttpError(401, 'Email atau kata sandi salah.');
    }
    json_out(['token' => token_for($row), 'user' => public_user($row)]);
}

function h_me($params, $user)
{
    $row = db_one('SELECT * FROM users WHERE id = ?', [$user['id']]);
    json_out(public_user($row));
}
