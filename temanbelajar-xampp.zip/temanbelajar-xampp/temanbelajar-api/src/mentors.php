<?php
// Mentor: pendaftaran, daftar, detail, verifikasi admin.

function mentor_sql()
{
    return 'SELECT m.id, m.user_id, m.expertise, m.education_level, m.verification_status, u.name,
                   (SELECT ROUND(AVG(r.rating), 1) FROM mentor_reviews r WHERE r.mentor_id = m.id) AS avg_rating,
                   (SELECT COUNT(*) FROM mentor_reviews r2 WHERE r2.mentor_id = m.id) AS review_count
            FROM mentor_profiles m
            JOIN users u ON u.id = m.user_id';
}

function mentor_clean($row)
{
    $row['id'] = (int) $row['id'];
    $row['user_id'] = (int) $row['user_id'];
    $row['avg_rating'] = $row['avg_rating'] === null ? null : (float) $row['avg_rating'];
    $row['review_count'] = (int) $row['review_count'];
    return $row;
}

// POST /mentors/register
function h_mentor_register($params, $user)
{
    $b = body();
    need($b, ['expertise', 'education_level']);
    if (db_one('SELECT id FROM mentor_profiles WHERE user_id = ?', [$user['id']])) {
        throw new HttpError(409, 'Kamu sudah mendaftar sebagai mentor.');
    }
    db_run(
        'INSERT INTO mentor_profiles (user_id, expertise, education_level) VALUES (?, ?, ?)',
        [$user['id'], trim((string) $b['expertise']), trim((string) $b['education_level'])]
    );
    $row = db_one(mentor_sql() . ' WHERE m.id = ?', [db_id()]);
    json_out(mentor_clean($row), 201);
}

// GET /mentors — admin melihat semua, lainnya hanya yang terverifikasi
function h_mentors_list($params, $user)
{
    $where = $user['role'] === 'admin' ? '' : " WHERE m.verification_status = 'verified'";
    $rows = db_all(mentor_sql() . $where . ' ORDER BY m.id DESC');
    json_out(array_map('mentor_clean', $rows));
}

// GET /mentors/{id}
function h_mentor_detail($params, $user)
{
    $id = to_id($params['id']);
    $row = db_one(mentor_sql() . ' WHERE m.id = ?', [$id]);
    if (!$row) {
        throw new HttpError(404, 'Mentor tidak ditemukan.');
    }
    $mentor = mentor_clean($row);
    $mentor['reviews'] = db_all(
        'SELECT r.id, r.rating, r.review, r.created_at, u.name AS reviewer
         FROM mentor_reviews r JOIN users u ON u.id = r.user_id
         WHERE r.mentor_id = ? ORDER BY r.id DESC',
        [$id]
    );
    json_out($mentor);
}

// PATCH /admin/mentors/{id}/verify  — body: { "verification_status": "verified" | "rejected" }
function h_admin_verify($params, $user)
{
    $id = to_id($params['id']);
    $b = body();
    $status = isset($b['verification_status']) ? $b['verification_status'] : 'verified';
    if (!in_array($status, ['verified', 'rejected', 'pending'], true)) {
        throw new HttpError(400, 'verification_status harus verified, rejected, atau pending.');
    }
    if (!db_one('SELECT id FROM mentor_profiles WHERE id = ?', [$id])) {
        throw new HttpError(404, 'Mentor tidak ditemukan.');
    }
    db_run('UPDATE mentor_profiles SET verification_status = ? WHERE id = ?', [$status, $id]);
    json_out(mentor_clean(db_one(mentor_sql() . ' WHERE m.id = ?', [$id])));
}
