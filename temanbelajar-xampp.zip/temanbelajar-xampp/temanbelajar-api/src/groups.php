<?php
// Kelompok belajar: buat, daftar, detail, gabung, anggota, materi.

function group_sql()
{
    return 'SELECT g.id, g.mentor_id, g.title, g.subject, g.description, g.capacity, g.created_at,
                   u.name AS mentor_name,
                   (SELECT COUNT(*) FROM group_members gm WHERE gm.group_id = g.id AND gm.status = \'active\') AS member_count
            FROM study_groups g
            LEFT JOIN mentor_profiles m ON m.id = g.mentor_id
            LEFT JOIN users u ON u.id = m.user_id';
}

function group_clean($g)
{
    $g['id'] = (int) $g['id'];
    $g['mentor_id'] = $g['mentor_id'] === null ? null : (int) $g['mentor_id'];
    $g['capacity'] = (int) $g['capacity'];
    $g['member_count'] = (int) $g['member_count'];
    return $g;
}

function find_group($id)
{
    $g = db_one(group_sql() . ' WHERE g.id = ?', [$id]);
    if (!$g) {
        throw new HttpError(404, 'Kelompok tidak ditemukan.');
    }
    return group_clean($g);
}

// POST /groups  (petugas, admin)
function h_group_create($params, $user)
{
    $b = body();
    need($b, ['title', 'subject', 'capacity']);
    $capacity = filter_var($b['capacity'], FILTER_VALIDATE_INT);
    if ($capacity === false || $capacity < 1) {
        throw new HttpError(400, 'Kapasitas harus bilangan bulat minimal 1.');
    }

    // mentor_id opsional: pakai yang dikirim, atau profil mentor milik pembuat (jika ada)
    $mentorId = null;
    if (!empty($b['mentor_id'])) {
        $mentorId = to_id($b['mentor_id'], 'mentor_id');
        if (!db_one('SELECT id FROM mentor_profiles WHERE id = ?', [$mentorId])) {
            throw new HttpError(404, 'Mentor tidak ditemukan.');
        }
    } else {
        $own = db_one('SELECT id FROM mentor_profiles WHERE user_id = ?', [$user['id']]);
        $mentorId = $own ? (int) $own['id'] : null;
    }

    db_run(
        'INSERT INTO study_groups (mentor_id, title, subject, description, capacity) VALUES (?, ?, ?, ?, ?)',
        [
            $mentorId,
            trim((string) $b['title']),
            trim((string) $b['subject']),
            isset($b['description']) ? (string) $b['description'] : '',
            $capacity,
        ]
    );
    json_out(find_group(db_id()), 201);
}

// GET /groups
function h_groups_list($params, $user)
{
    json_out(array_map('group_clean', db_all(group_sql() . ' ORDER BY g.id DESC')));
}

function session_clean($s)
{
    $s['id'] = (int) $s['id'];
    $s['group_id'] = (int) $s['group_id'];
    $s['start_time'] = substr($s['start_time'], 0, 5);
    $s['end_time'] = substr($s['end_time'], 0, 5);
    return $s;
}

// GET /groups/{id}  — detail beserta sesi
function h_group_detail($params, $user)
{
    $id = to_id($params['id']);
    $group = find_group($id);
    $sessions = db_all(
        'SELECT id, group_id, session_date, start_time, end_time, topic
         FROM study_sessions WHERE group_id = ? ORDER BY session_date, start_time',
        [$id]
    );
    $group['sessions'] = array_map('session_clean', $sessions);
    $group['is_member'] = db_one(
        "SELECT 1 AS ok FROM group_members WHERE group_id = ? AND user_id = ? AND status = 'active'",
        [$id, $user['id']]
    ) !== null;
    json_out($group);
}

// POST /groups/{id}/join
function h_group_join($params, $user)
{
    $id = to_id($params['id']);
    $group = find_group($id);
    if (db_one('SELECT id FROM group_members WHERE group_id = ? AND user_id = ?', [$id, $user['id']])) {
        throw new HttpError(409, 'Kamu sudah bergabung di kelompok ini.');
    }
    if ($group['member_count'] >= $group['capacity']) {
        throw new HttpError(409, 'Kelompok sudah penuh.');
    }
    db_run("INSERT INTO group_members (group_id, user_id, status) VALUES (?, ?, 'active')", [$id, $user['id']]);
    json_out(['message' => 'Berhasil bergabung ke kelompok.', 'group_id' => $id], 201);
}

// GET /groups/{id}/members
function h_group_members($params, $user)
{
    $id = to_id($params['id']);
    find_group($id);
    json_out(db_all(
        'SELECT gm.id, gm.group_id, gm.user_id, gm.status, u.name
         FROM group_members gm JOIN users u ON u.id = gm.user_id
         WHERE gm.group_id = ? ORDER BY gm.id',
        [$id]
    ));
}

// GET /groups/{id}/materials
function h_group_materials($params, $user)
{
    $id = to_id($params['id']);
    find_group($id);
    $rows = db_all(
        'SELECT lm.id, lm.group_id, lm.title, lm.description, lm.file_id,
                f.original_name AS file_name, f.stored_name
         FROM learning_materials lm LEFT JOIN files f ON f.id = lm.file_id
         WHERE lm.group_id = ? ORDER BY lm.id DESC',
        [$id]
    );
    foreach ($rows as &$r) {
        $r['url'] = $r['stored_name'] ? file_url($r['stored_name']) : null;
        unset($r['stored_name']);
    }
    unset($r);
    json_out($rows);
}
