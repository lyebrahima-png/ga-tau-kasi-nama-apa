<?php
// Titik masuk API TemanBelajar. Semua permintaan /api/v1/... diarahkan ke sini oleh .htaccess.

require __DIR__ . '/src/core.php';
require __DIR__ . '/src/auth.php';
require __DIR__ . '/src/mentors.php';
require __DIR__ . '/src/groups.php';
require __DIR__ . '/src/learning.php';

ini_set('display_errors', '0'); // jangan bocorkan detail error; lihat log Apache (xampp/apache/logs/error.log)

// ---------- CORS ----------
$origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';
$allowed = cfg('cors_origins', []);
if ($origin !== '' && (empty($allowed) || in_array($origin, $allowed, true))) {
    header('Access-Control-Allow-Origin: ' . $origin);
    header('Vary: Origin');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
}
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// ---------- Tabel rute: [method, pola, akses, fungsi] ----------
// akses: public = tanpa login, auth = harus login, staff = petugas/admin, admin = admin saja
$routes = [
    ['GET',   '/health',                    'public', 'h_health'],
    ['POST',  '/auth/register',             'public', 'h_register'],
    ['POST',  '/auth/login',                'public', 'h_login'],
    ['GET',   '/auth/me',                   'auth',   'h_me'],

    ['POST',  '/mentors/register',          'auth',   'h_mentor_register'],
    ['GET',   '/mentors',                   'auth',   'h_mentors_list'],
    ['GET',   '/mentors/{id}',              'auth',   'h_mentor_detail'],
    ['PATCH', '/admin/mentors/{id}/verify', 'admin',  'h_admin_verify'],

    ['POST',  '/groups',                    'staff',  'h_group_create'],
    ['GET',   '/groups',                    'auth',   'h_groups_list'],
    ['GET',   '/groups/{id}',               'auth',   'h_group_detail'],
    ['POST',  '/groups/{id}/join',          'auth',   'h_group_join'],
    ['GET',   '/groups/{id}/members',       'auth',   'h_group_members'],
    ['GET',   '/groups/{id}/materials',     'auth',   'h_group_materials'],

    ['POST',  '/sessions',                  'staff',  'h_session_create'],
    ['POST',  '/sessions/{id}/register',    'auth',   'h_session_register'],

    ['POST',  '/materials',                 'staff',  'h_material_create'],
    ['POST',  '/progress',                  'auth',   'h_progress_create'],
    ['GET',   '/progress',                  'auth',   'h_progress_list'],
    ['POST',  '/reviews',                   'auth',   'h_review_create'],
];

function h_health($params, $user)
{
    json_out(['status' => 'ok']);
}

try {
    // Ambil bagian path setelah folder API, mis. /api/v1/groups/3 -> /groups/3
    $uri = rawurldecode((string) parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
    $base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
    $path = substr($uri, strlen($base));
    if ($path === false) {
        $path = '/';
    }

    if (strpos($path, '/api/v1') !== 0) {
        json_out(['name' => 'TemanBelajar API', 'version' => 'v1', 'docs' => 'Lihat README.md', 'base' => $base . '/api/v1']);
    }
    $path = rtrim(substr($path, strlen('/api/v1')), '/');
    if ($path === '') {
        $path = '/health';
    }

    $method = $_SERVER['REQUEST_METHOD'];
    foreach ($routes as $route) {
        list($m, $pattern, $access, $handler) = $route;
        if ($m !== $method) {
            continue;
        }
        $regex = '#^' . preg_replace('#\{(\w+)\}#', '(?P<$1>[^/]+)', $pattern) . '$#';
        if (!preg_match($regex, $path, $matches)) {
            continue;
        }
        $params = array_filter($matches, 'is_string', ARRAY_FILTER_USE_KEY);

        $user = null;
        if ($access !== 'public') {
            $user = current_user();
            if ($access === 'staff' && !in_array($user['role'], ['petugas', 'admin'], true)) {
                throw new HttpError(403, 'Kamu tidak punya akses untuk aksi ini.');
            }
            if ($access === 'admin' && $user['role'] !== 'admin') {
                throw new HttpError(403, 'Kamu tidak punya akses untuk aksi ini.');
            }
        }
        $handler($params, $user);
        exit;
    }
    throw new HttpError(404, 'Endpoint tidak ditemukan.');
} catch (HttpError $e) {
    json_out(['message' => $e->getMessage()], $e->status);
} catch (PDOException $e) {
    error_log('[TemanBelajar] DB: ' . $e->getMessage());
    if ((string) $e->getCode() === '23000') {
        json_out(['message' => 'Data tidak valid atau sudah ada.'], 409);
    }
    json_out(['message' => 'Database bermasalah. Pastikan MySQL di XAMPP menyala dan database.sql sudah di-import.'], 500);
} catch (Throwable $e) {
    error_log('[TemanBelajar] ' . $e->getMessage());
    json_out(['message' => 'Terjadi kesalahan pada server.'], 500);
}
