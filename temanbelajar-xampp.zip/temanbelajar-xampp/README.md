# TemanBelajar — Inovasi Pendidikan (XAMPP: PHP + MySQL + React)

```
temanbelajar-xampp/
  temanbelajar-api/   Backend PHP (jalan di Apache XAMPP, database MySQL XAMPP)
  frontend/           Frontend React + Vite
```

## 1. Siapkan backend di XAMPP

1. Buka **XAMPP Control Panel**, klik **Start** pada **Apache** dan **MySQL**.
2. Salin folder `temanbelajar-api` ke `C:\xampp\htdocs\` sehingga menjadi
   `C:\xampp\htdocs\temanbelajar-api\`.
3. Buka `http://localhost/phpmyadmin` > tab **Import** > pilih `temanbelajar-api/database.sql` > **Import**.
   Ini membuat database `temanbelajar`, semua tabel, dan akun contoh.
4. Buka `http://localhost/temanbelajar-api/api/v1/health`. Kalau muncul `{"status":"ok"}`, API siap.
5. Buka `temanbelajar-api/config.php`:
   - Jika MySQL XAMPP kamu memakai kata sandi, isi `db.pass`.
   - Ganti `jwt_secret` dengan kalimat acak yang panjang.

Butuh PHP 7.4 atau lebih baru (XAMPP terbaru sudah PHP 8.x) dan ekstensi `pdo_mysql` (aktif bawaan).

## 2. Jalankan frontend

Butuh Node.js 18 atau lebih baru.

```bash
cd frontend
npm install
npm run dev        # buka http://localhost:5173
```

Saat `npm run dev`, Vite meneruskan `/api` ke `http://localhost/temanbelajar-api`
(ubah di `frontend/vite.config.js` bila nama folder API berbeda).

## Akun contoh

| Peran | Email | Kata sandi |
|---|---|---|
| Admin | admin@temanbelajar.id | admin123 |
| Petugas | petugas@temanbelajar.id | petugas123 |
| User | user@temanbelajar.id | user123 |
| User (mentor terverifikasi) | mentor@temanbelajar.id | mentor123 |

Pendaftaran lewat halaman Daftar selalu berperan `user`. Untuk membuat petugas atau admin baru,
buka phpMyAdmin > database `temanbelajar` > tabel `users` > ubah kolom `role`.

## Opsional: pasang frontend di htdocs (tanpa npm run dev)

```bash
cd frontend
npm run build
```

Salin isi folder `dist` (termasuk file `.htaccess`) ke `C:\xampp\htdocs\temanbelajar\`,
lalu buka `http://localhost/temanbelajar/`. Pengaturan build ada di `frontend/.env.production`
(nama folder `temanbelajar` dan `temanbelajar-api` harus sama dengan yang di htdocs).

## Fitur dan hak akses

| Fitur | Admin | Petugas | User |
|---|---|---|---|
| Daftar akun, masuk | ya | ya | ya |
| Daftar jadi mentor | ya | ya | ya |
| Verifikasi mentor | ya | - | - |
| Lihat mentor | semua | terverifikasi | terverifikasi |
| Buat kelompok, buat sesi, unggah materi | ya | ya | - |
| Cari dan bergabung ke kelompok, lihat anggota dan materi | ya | ya | ya |
| Daftar sesi (harus anggota kelompok) | ya | ya | ya |
| Catat progres, beri ulasan mentor | ya | ya | ya |

## Endpoint (Base URL `http://localhost/temanbelajar-api/api/v1`)

Semua endpoint selain `/health` dan `/auth/register|login` butuh header `Authorization: Bearer <token>`.

| Method | Endpoint | Fungsi | Akses |
|---|---|---|---|
| POST | /auth/register | Daftar akun | publik |
| POST | /auth/login | Masuk, mengembalikan `{ token, user }` | publik |
| POST | /mentors/register | Mendaftar sebagai mentor | masuk |
| GET | /mentors | Daftar mentor | masuk |
| GET | /mentors/{id} | Detail mentor + ulasan | masuk |
| PATCH | /admin/mentors/{id}/verify | Verifikasi mentor | admin |
| POST | /groups | Membuat kelompok | petugas, admin |
| GET | /groups | Melihat kelompok | masuk |
| GET | /groups/{id} | Detail kelompok + sesi | masuk |
| POST | /groups/{id}/join | Bergabung ke kelompok | masuk |
| GET | /groups/{id}/members | Melihat anggota | masuk |
| POST | /sessions | Membuat sesi belajar | petugas, admin |
| POST | /sessions/{id}/register | Mendaftar sesi | anggota kelompok |
| POST | /materials | Mengunggah materi (multipart, field `file`) | petugas, admin |
| GET | /groups/{id}/materials | Melihat materi | masuk |
| POST | /progress | Mencatat progres | masuk |
| POST | /reviews | Memberikan penilaian (rating 1–5) | masuk |

Tambahan: `GET /auth/me`, `GET /progress` (riwayat progres sendiri), `GET /health`.

## Pemecahan masalah

- **404 pada semua endpoint**: pastikan `mod_rewrite` aktif dan `AllowOverride All` untuk htdocs
  (bawaan XAMPP sudah begitu), lalu restart Apache.
- **"Database bermasalah"**: MySQL belum menyala, `database.sql` belum di-import, atau `config.php` salah.
  Detail error ada di `C:\xampp\apache\logs\error.log`.
- **Selalu 401 padahal sudah login**: header Authorization tidak sampai ke PHP. File `.htaccess` di
  `temanbelajar-api` sudah menangani ini; pastikan file itu ikut tersalin (file berawalan titik kadang tersembunyi).
- **Unggah file besar gagal**: naikkan `upload_max_filesize` dan `post_max_size` di `C:\xampp\php\php.ini`, restart Apache.
