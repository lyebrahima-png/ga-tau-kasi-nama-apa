const BASE = import.meta.env.VITE_API_URL || "/api/v1";

export const getToken = () => localStorage.getItem("tb_token");
export const setToken = (t) =>
  t ? localStorage.setItem("tb_token", t) : localStorage.removeItem("tb_token");

// Pembungkus fetch: menambahkan token, mengirim JSON atau FormData,
// dan melempar Error dengan pesan dari backend bila gagal.
export async function api(path, { method = "GET", body, auth = true } = {}) {
  const headers = {};
  const token = getToken();
  if (auth && token) headers.Authorization = `Bearer ${token}`;

  let payload;
  if (body instanceof FormData) {
    payload = body;
  } else if (body !== undefined) {
    headers["Content-Type"] = "application/json";
    payload = JSON.stringify(body);
  }

  const res = await fetch(`${BASE}${path}`, { method, headers, body: payload });
  const text = await res.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = text;
  }

  if (!res.ok) {
    const msg =
      (data && (data.message || data.error || data.detail)) ||
      `Permintaan gagal (${res.status})`;
    const err = new Error(typeof msg === "string" ? msg : JSON.stringify(msg));
    err.status = res.status;
    throw err;
  }
  return data;
}

// Backend bisa membalas array langsung atau { data: [...] }.
export const unwrap = (res) =>
  Array.isArray(res) ? res : res?.data ?? res?.items ?? [];
export const unwrapOne = (res) =>
  res && res.data && !Array.isArray(res.data) ? res.data : res;

// Mengubah "/uploads/xxx" dari backend menjadi alamat yang bisa dibuka browser.
export const fileUrl = (u) => {
  if (!u || /^https?:/.test(u)) return u;
  return BASE.startsWith("http") ? new URL(BASE).origin + u : u;
};
