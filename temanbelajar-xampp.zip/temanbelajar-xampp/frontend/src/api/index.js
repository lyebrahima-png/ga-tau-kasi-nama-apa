import { api, unwrap, unwrapOne } from "./client.js";

// ---- Auth (sesuaikan dengan endpoint login di backend kamu) ----
export const login = (email, password) =>
  api("/auth/login", { method: "POST", body: { email, password }, auth: false });

export const register = (payload) =>
  api("/auth/register", { method: "POST", body: payload, auth: false });

// ---- Mentor ----
export const registerMentor = (payload) =>
  api("/mentors/register", { method: "POST", body: payload });
export const getMentors = async () => unwrap(await api("/mentors"));
export const getMentor = async (id) => unwrapOne(await api(`/mentors/${id}`));
export const verifyMentor = (id, status = "verified") =>
  api(`/admin/mentors/${id}/verify`, {
    method: "PATCH",
    body: { verification_status: status },
  });

// ---- Kelompok belajar ----
export const createGroup = (payload) =>
  api("/groups", { method: "POST", body: payload });
export const getGroups = async () => unwrap(await api("/groups"));
export const getGroup = async (id) => unwrapOne(await api(`/groups/${id}`));
export const joinGroup = (id) => api(`/groups/${id}/join`, { method: "POST" });
export const getMembers = async (id) => unwrap(await api(`/groups/${id}/members`));

// ---- Sesi ----
export const createSession = (payload) =>
  api("/sessions", { method: "POST", body: payload });
export const registerSession = (id) =>
  api(`/sessions/${id}/register`, { method: "POST" });

// ---- Materi ----
// Jika ada file, kirim sebagai FormData (field "file"); jika tidak, JSON biasa.
export const uploadMaterial = ({ group_id, title, description, file }) => {
  if (file) {
    const fd = new FormData();
    fd.append("group_id", group_id);
    fd.append("title", title);
    fd.append("description", description || "");
    fd.append("file", file);
    return api("/materials", { method: "POST", body: fd });
  }
  return api("/materials", {
    method: "POST",
    body: { group_id, title, description },
  });
};
export const getMaterials = async (groupId) =>
  unwrap(await api(`/groups/${groupId}/materials`));

// ---- Progres & ulasan ----
export const addProgress = (payload) =>
  api("/progress", { method: "POST", body: payload });
export const addReview = (payload) =>
  api("/reviews", { method: "POST", body: payload });
