import { useState } from "react";
import { addProgress, getGroups } from "../api/index.js";
import { Field, Notice, useFetch } from "../components/ui.jsx";

const today = () => new Date().toISOString().slice(0, 10);

export default function Progress() {
  const groups = useFetch(getGroups);
  const [form, setForm] = useState({ group_id: "", progress_note: "", progress_date: today() });
  const [msg, setMsg] = useState({ type: "ok", text: "" });

  const submit = async (e) => {
    e.preventDefault();
    try {
      await addProgress({ ...form, group_id: Number(form.group_id) });
      setMsg({ type: "ok", text: "Progres tercatat." });
      setForm({ ...form, progress_note: "" });
    } catch (err) {
      setMsg({ type: "error", text: err.message });
    }
  };

  return (
    <form className="card form-card" onSubmit={submit}>
      <h1>Catat progres belajar</h1>
      <Notice type={msg.type}>{msg.text}</Notice>
      <Field label="Kelompok">
        <select
          required
          value={form.group_id}
          onChange={(e) => setForm({ ...form, group_id: e.target.value })}
        >
          <option value="">Pilih kelompok</option>
          {(groups.data || []).map((g) => (
            <option key={g.id} value={g.id}>
              {g.title}
            </option>
          ))}
        </select>
      </Field>
      <Field label="Tanggal">
        <input
          type="date"
          required
          value={form.progress_date}
          onChange={(e) => setForm({ ...form, progress_date: e.target.value })}
        />
      </Field>
      <Field label="Catatan progres">
        <textarea
          rows="4"
          required
          value={form.progress_note}
          onChange={(e) => setForm({ ...form, progress_note: e.target.value })}
        />
      </Field>
      <button className="btn btn-primary">Simpan progres</button>
    </form>
  );
}
