import { useState } from "react";
import { getMentors, verifyMentor } from "../api/index.js";
import { Badge, Notice, Status, statusTone, useFetch } from "../components/ui.jsx";
import Avatar from "../components/Avatar.jsx";

export default function AdminMentors() {
  const { data, loading, error, reload } = useFetch(getMentors);
  const [msg, setMsg] = useState({ type: "ok", text: "" });
  const list = data || [];

  const decide = async (id, status) => {
    try {
      await verifyMentor(id, status);
      setMsg({
        type: "ok",
        text: status === "verified" ? "Mentor disetujui." : "Mentor ditolak.",
      });
      reload();
    } catch (e) {
      setMsg({ type: "error", text: e.message });
    }
  };

  return (
    <>
      <div className="page-head">
        <h1>Verifikasi mentor</h1>
      </div>
      <Notice type={msg.type}>{msg.text}</Notice>
      <Status loading={loading} error={error} empty={!list.length} emptyText="Belum ada mentor." />
      <div className="stack">
        {list.map((m) => (
          <div key={m.id} className="card row-card">
            <Avatar name={m.name || m.expertise || "Mentor"} size={44} />
            <div className="grow">
              <strong>{m.name || `Mentor #${m.id}`}</strong>
              <small className="muted">
                {m.expertise} · {m.education_level}
              </small>
            </div>
            <Badge tone={statusTone(m.verification_status)}>{m.verification_status}</Badge>
            {m.verification_status !== "verified" && (
              <button className="btn btn-primary btn-sm" onClick={() => decide(m.id, "verified")}>
                Setujui
              </button>
            )}
            {m.verification_status !== "rejected" && (
              <button className="btn btn-outline btn-sm" onClick={() => decide(m.id, "rejected")}>
                Tolak
              </button>
            )}
          </div>
        ))}
      </div>
    </>
  );
}
