import { useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import { Field, Notice } from "../components/ui.jsx";
import Icon from "../components/Icon.jsx";

export default function Login() {
  const { user, login } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  if (user) return <Navigate to="/" replace />;

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      await login(form.email, form.password);
      navigate("/");
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-hero">
        <span className="brand-mark big">
          <Icon name="book" size={30} />
        </span>
        <h1>Belajar lebih mudah bersama teman dan mentor.</h1>
        <p>Gabung kelompok belajar, ikuti sesi, dan pantau perkembanganmu di satu tempat.</p>
      </div>
      <form className="card login-card" onSubmit={submit}>
        <h2>Masuk ke TemanBelajar</h2>
        <Notice type="error">{error}</Notice>
        <Field label="Email">
          <input
            type="email"
            required
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
          />
        </Field>
        <Field label="Kata sandi">
          <input
            type="password"
            required
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
          />
        </Field>
        <button className="btn btn-primary" disabled={busy}>
          {busy ? "Memproses..." : "Masuk"}
        </button>
        <p className="muted">
          Belum punya akun? <Link to="/register">Daftar sekarang</Link>
        </p>
      </form>
    </div>
  );
}
