import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { createGroup } from "../api/index.js";
import { Field, Notice } from "../components/ui.jsx";

export default function CreateGroup() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ title: "", subject: "", description: "", capacity: 10 });
  const [error, setError] = useState("");
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    try {
      const res = await createGroup({ ...form, capacity: Number(form.capacity) });
      const id = res?.data?.id ?? res?.id;
      navigate(id ? `/groups/${id}` : "/groups");
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <form className="card form-card" onSubmit={submit}>
      <h1>Buat kelompok belajar</h1>
      <Notice type="error">{error}</Notice>
      <Field label="Judul kelompok">
        <input required value={form.title} onChange={set("title")} />
      </Field>
      <Field label="Mata pelajaran">
        <input required value={form.subject} onChange={set("subject")} />
      </Field>
      <Field label="Deskripsi">
        <textarea rows="4" value={form.description} onChange={set("description")} />
      </Field>
      <Field label="Kapasitas peserta">
        <input type="number" min="1" required value={form.capacity} onChange={set("capacity")} />
      </Field>
      <button className="btn btn-primary">Simpan kelompok</button>
    </form>
  );
}
