import { useMemo, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { getGroups } from "../api/index.js";
import { useAuth } from "../context/AuthContext.jsx";
import { useFetch, Status } from "../components/ui.jsx";
import GroupCard from "../components/GroupCard.jsx";

export default function Groups() {
  const [params] = useSearchParams();
  const [q, setQ] = useState(params.get("q") || "");
  const { isStaff } = useAuth();
  const { data, loading, error } = useFetch(getGroups);

  const list = useMemo(() => {
    const term = q.toLowerCase();
    return (data || []).filter((g) =>
      `${g.title} ${g.subject} ${g.description}`.toLowerCase().includes(term)
    );
  }, [data, q]);

  return (
    <>
      <div className="page-head">
        <h1>Kelompok belajar</h1>
        {isStaff && (
          <Link to="/groups/new" className="btn btn-primary">
            Buat kelompok
          </Link>
        )}
      </div>
      <input
        className="input-wide"
        placeholder="Cari judul atau mata pelajaran"
        value={q}
        onChange={(e) => setQ(e.target.value)}
      />
      <Status
        loading={loading}
        error={error}
        empty={!list.length}
        emptyText="Tidak ada kelompok yang cocok dengan pencarianmu."
      />
      <div className="grid">
        {list.map((g) => (
          <GroupCard key={g.id} group={g} />
        ))}
      </div>
    </>
  );
}
