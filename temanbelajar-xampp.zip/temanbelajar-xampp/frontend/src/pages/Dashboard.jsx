import { Link } from "react-router-dom";
import { getGroups, getMentors } from "../api/index.js";
import { useAuth } from "../context/AuthContext.jsx";
import { useFetch, Status } from "../components/ui.jsx";
import GroupCard from "../components/GroupCard.jsx";
import Avatar from "../components/Avatar.jsx";
import Icon from "../components/Icon.jsx";

export default function Dashboard() {
  const { user } = useAuth();
  const groups = useFetch(getGroups);
  const mentors = useFetch(getMentors);
  const groupList = groups.data || [];
  const mentorList = mentors.data || [];

  return (
    <div className="dash">
      <section className="dash-main">
        <div className="hero">
          <p>Halo, {user?.name || "Teman Belajar"}</p>
          <h1>Temukan kelompok belajar yang cocok untukmu</h1>
          <Link to="/groups" className="btn btn-dark">
            Lihat kelompok
          </Link>
        </div>

        <div className="stat-row">
          <div className="card stat">
            <span className="stat-icon">
              <Icon name="group" />
            </span>
            <div>
              <strong>{groupList.length}</strong>
              <small>Kelompok tersedia</small>
            </div>
          </div>
          <div className="card stat">
            <span className="stat-icon">
              <Icon name="mentor" />
            </span>
            <div>
              <strong>{mentorList.length}</strong>
              <small>Mentor terdaftar</small>
            </div>
          </div>
          <div className="card stat">
            <span className="stat-icon">
              <Icon name="check" />
            </span>
            <div>
              <strong>
                {mentorList.filter((m) => m.verification_status === "verified").length}
              </strong>
              <small>Mentor terverifikasi</small>
            </div>
          </div>
        </div>

        <div className="section-head">
          <h2>Kelompok terbaru</h2>
          <Link to="/groups">Lihat semua</Link>
        </div>
        <Status
          loading={groups.loading}
          error={groups.error}
          empty={!groupList.length}
          emptyText="Belum ada kelompok belajar."
        />
        <div className="grid">
          {groupList.slice(0, 3).map((g) => (
            <GroupCard key={g.id} group={g} />
          ))}
        </div>
      </section>

      <aside className="card dash-side">
        <div className="section-head">
          <h2>Mentor</h2>
          <Link to="/mentors">Semua</Link>
        </div>
        <Status loading={mentors.loading} error={mentors.error} empty={!mentorList.length} />
        <ul className="mentor-list">
          {mentorList.slice(0, 5).map((m) => (
            <li key={m.id}>
              <Avatar name={m.name || m.expertise || "Mentor"} size={40} />
              <div>
                <strong>{m.name || `Mentor #${m.id}`}</strong>
                <small>{m.expertise}</small>
              </div>
              <Link to={`/mentors/${m.id}`} className="btn btn-outline btn-sm">
                Detail
              </Link>
            </li>
          ))}
        </ul>
      </aside>
    </div>
  );
}
