import { Link } from "react-router-dom";
import { getMentors } from "../api/index.js";
import { Badge, Status, statusTone, useFetch } from "../components/ui.jsx";
import Avatar from "../components/Avatar.jsx";

export default function Mentors() {
  const { data, loading, error } = useFetch(getMentors);
  const list = data || [];
  return (
    <>
      <div className="page-head">
        <h1>Daftar mentor</h1>
      </div>
      <Status loading={loading} error={error} empty={!list.length} emptyText="Belum ada mentor." />
      <div className="grid">
        {list.map((m) => (
          <Link key={m.id} to={`/mentors/${m.id}`} className="card mentor-card">
            <Avatar name={m.name || m.expertise || "Mentor"} size={56} />
            <h3>{m.name || `Mentor #${m.id}`}</h3>
            <p className="muted">{m.expertise}</p>
            <small className="muted">{m.education_level}</small>
            <Badge tone={statusTone(m.verification_status)}>{m.verification_status}</Badge>
          </Link>
        ))}
      </div>
    </>
  );
}
