import { useState } from "react";
import { useParams } from "react-router-dom";
import { addReview, getMentor } from "../api/index.js";
import { Badge, Field, Notice, Status, statusTone, useFetch } from "../components/ui.jsx";
import Avatar from "../components/Avatar.jsx";
import Icon from "../components/Icon.jsx";

export default function MentorDetail() {
  const { id } = useParams();
  const { data: m, loading, error, reload } = useFetch(() => getMentor(id), [id]);
  const [form, setForm] = useState({ rating: 5, review: "" });
  const [msg, setMsg] = useState({ type: "ok", text: "" });

  if (loading || error) return <Status loading={loading} error={error} />;

  const submit = async (e) => {
    e.preventDefault();
    try {
      await addReview({ mentor_id: Number(id), rating: Number(form.rating), review: form.review });
      setMsg({ type: "ok", text: "Ulasan terkirim. Terima kasih!" });
      setForm({ rating: 5, review: "" });
      reload();
    } catch (err) {
      setMsg({ type: "error", text: err.message });
    }
  };

  return (
    <>
      <div className="card detail-head">
        <Avatar name={m.name || m.expertise || "Mentor"} size={72} />
        <div className="grow">
          <h1>{m.name || `Mentor #${m.id}`}</h1>
          <p className="muted">
            {m.expertise} · {m.education_level}
          </p>
          <Badge tone={statusTone(m.verification_status)}>{m.verification_status}</Badge>
        </div>
      </div>

      <h2>Ulasan peserta</h2>
      {!(m.reviews || []).length && <p className="muted empty">Belum ada ulasan.</p>}
      <div className="stack">
        {(m.reviews || []).map((r) => (
          <div key={r.id} className="card row-card">
            <span className="rating">
              <Icon name="star" size={16} /> {r.rating}
            </span>
            <p className="grow">{r.review}</p>
          </div>
        ))}
      </div>

      <form className="card form-card" onSubmit={submit}>
        <h3>Beri penilaian</h3>
        <Notice type={msg.type}>{msg.text}</Notice>
        <Field label="Nilai (1–5)">
          <select value={form.rating} onChange={(e) => setForm({ ...form, rating: e.target.value })}>
            {[5, 4, 3, 2, 1].map((n) => (
              <option key={n} value={n}>
                {n}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Ulasan">
          <textarea
            rows="3"
            required
            value={form.review}
            onChange={(e) => setForm({ ...form, review: e.target.value })}
          />
        </Field>
        <button className="btn btn-primary">Kirim ulasan</button>
      </form>
    </>
  );
}
