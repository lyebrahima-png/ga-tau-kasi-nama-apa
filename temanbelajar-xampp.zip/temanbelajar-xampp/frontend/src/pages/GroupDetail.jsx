import { useState } from "react";
import { useParams } from "react-router-dom";
import {
  createSession,
  getGroup,
  getMaterials,
  getMembers,
  joinGroup,
  registerSession,
  uploadMaterial,
} from "../api/index.js";
import { fileUrl } from "../api/client.js";
import { useAuth } from "../context/AuthContext.jsx";
import { Badge, Field, Notice, Status, statusTone, useFetch } from "../components/ui.jsx";
import Avatar from "../components/Avatar.jsx";
import Icon from "../components/Icon.jsx";

export default function GroupDetail() {
  const { id } = useParams();
  const { isStaff } = useAuth();
  const [tab, setTab] = useState("sesi");
  const [msg, setMsg] = useState({ type: "ok", text: "" });

  const group = useFetch(() => getGroup(id), [id]);
  const members = useFetch(() => getMembers(id), [id]);
  const materials = useFetch(() => getMaterials(id), [id]);

  const say = (type, text) => setMsg({ type, text });
  const act = async (fn, okText, after) => {
    try {
      await fn();
      say("ok", okText);
      after?.();
    } catch (e) {
      say("error", e.message);
    }
  };

  if (group.loading || group.error)
    return <Status loading={group.loading} error={group.error} />;

  const g = group.data;
  const sessions = g.sessions || [];

  return (
    <>
      <div className="card detail-head">
        <div>
          <span className="chip">{g.subject}</span>
          <h1>{g.title}</h1>
          <p className="muted">{g.description}</p>
          <small className="muted">Kapasitas {g.capacity} peserta</small>
        </div>
        <button
          className="btn btn-primary"
          onClick={() =>
            act(() => joinGroup(id), "Kamu berhasil bergabung ke kelompok.", members.reload)
          }
        >
          Bergabung ke kelompok
        </button>
      </div>

      <Notice type={msg.type}>{msg.text}</Notice>

      <div className="tabs" role="tablist">
        {[
          ["sesi", "Sesi"],
          ["materi", "Materi"],
          ["anggota", "Anggota"],
        ].map(([k, label]) => (
          <button
            key={k}
            role="tab"
            aria-selected={tab === k}
            className={tab === k ? "tab active" : "tab"}
            onClick={() => setTab(k)}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === "sesi" && (
        <>
          {!sessions.length && <p className="muted empty">Belum ada sesi belajar.</p>}
          <div className="stack">
            {sessions.map((s) => (
              <div key={s.id} className="card row-card">
                <span className="stat-icon">
                  <Icon name="calendar" />
                </span>
                <div className="grow">
                  <strong>{s.topic}</strong>
                  <small className="muted">
                    {s.session_date} · {s.start_time} – {s.end_time}
                  </small>
                </div>
                <button
                  className="btn btn-outline btn-sm"
                  onClick={() =>
                    act(() => registerSession(s.id), "Kamu terdaftar di sesi ini.")
                  }
                >
                  Daftar sesi
                </button>
              </div>
            ))}
          </div>
          {isStaff && (
            <SessionForm
              groupId={id}
              onDone={() => {
                say("ok", "Sesi berhasil dibuat.");
                group.reload();
              }}
              onError={(t) => say("error", t)}
            />
          )}
        </>
      )}

      {tab === "materi" && (
        <>
          <Status
            loading={materials.loading}
            error={materials.error}
            empty={!(materials.data || []).length}
            emptyText="Belum ada materi untuk kelompok ini."
          />
          <div className="stack">
            {(materials.data || []).map((m) => (
              <div key={m.id} className="card row-card">
                <span className="stat-icon">
                  <Icon name="file" />
                </span>
                <div className="grow">
                  <strong>{m.title}</strong>
                  <small className="muted">{m.description}</small>
                </div>
                {m.url && (
                  <a className="btn btn-outline btn-sm" href={fileUrl(m.url)} target="_blank" rel="noreferrer">
                    Buka
                  </a>
                )}
              </div>
            ))}
          </div>
          {isStaff && (
            <MaterialForm
              groupId={id}
              onDone={() => {
                say("ok", "Materi berhasil diunggah.");
                materials.reload();
              }}
              onError={(t) => say("error", t)}
            />
          )}
        </>
      )}

      {tab === "anggota" && (
        <>
          <Status
            loading={members.loading}
            error={members.error}
            empty={!(members.data || []).length}
            emptyText="Belum ada anggota."
          />
          <div className="stack">
            {(members.data || []).map((m) => (
              <div key={m.id} className="card row-card">
                <Avatar name={m.name || `User ${m.user_id}`} size={40} />
                <div className="grow">
                  <strong>{m.name || `Pengguna #${m.user_id}`}</strong>
                </div>
                <Badge tone={statusTone(m.status)}>{m.status}</Badge>
              </div>
            ))}
          </div>
        </>
      )}
    </>
  );
}

function SessionForm({ groupId, onDone, onError }) {
  const [f, setF] = useState({ session_date: "", start_time: "", end_time: "", topic: "" });
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const submit = async (e) => {
    e.preventDefault();
    try {
      await createSession({ ...f, group_id: Number(groupId) });
      setF({ session_date: "", start_time: "", end_time: "", topic: "" });
      onDone();
    } catch (err) {
      onError(err.message);
    }
  };
  return (
    <form className="card form-card" onSubmit={submit}>
      <h3>Buat sesi belajar</h3>
      <Field label="Topik">
        <input required value={f.topic} onChange={set("topic")} />
      </Field>
      <div className="form-row">
        <Field label="Tanggal">
          <input type="date" required value={f.session_date} onChange={set("session_date")} />
        </Field>
        <Field label="Mulai">
          <input type="time" required value={f.start_time} onChange={set("start_time")} />
        </Field>
        <Field label="Selesai">
          <input type="time" required value={f.end_time} onChange={set("end_time")} />
        </Field>
      </div>
      <button className="btn btn-primary">Simpan sesi</button>
    </form>
  );
}

function MaterialForm({ groupId, onDone, onError }) {
  const [f, setF] = useState({ title: "", description: "", file: null });
  const submit = async (e) => {
    e.preventDefault();
    try {
      await uploadMaterial({ ...f, group_id: Number(groupId) });
      setF({ title: "", description: "", file: null });
      e.target.reset();
      onDone();
    } catch (err) {
      onError(err.message);
    }
  };
  return (
    <form className="card form-card" onSubmit={submit}>
      <h3>Unggah materi</h3>
      <Field label="Judul materi">
        <input required value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} />
      </Field>
      <Field label="Deskripsi">
        <textarea
          rows="3"
          value={f.description}
          onChange={(e) => setF({ ...f, description: e.target.value })}
        />
      </Field>
      <Field label="File (opsional)">
        <input type="file" onChange={(e) => setF({ ...f, file: e.target.files[0] || null })} />
      </Field>
      <button className="btn btn-primary">Unggah materi</button>
    </form>
  );
}
