import { useState } from "react";
import { registerMentor } from "../api/index.js";
import { Field, Notice } from "../components/ui.jsx";

export default function MentorRegister() {
  const [form, setForm] = useState({ expertise: "", education_level: "S1" });
  const [msg, setMsg] = useState({ type: "ok", text: "" });

  const submit = async (e) => {
    e.preventDefault();
    try {
      await registerMentor(form);
      setMsg({ type: "ok", text: "Pendaftaran terkirim. Admin akan memverifikasi profilmu." });
    } catch (err) {
      setMsg({ type: "error", text: err.message });
    }
  };

  return (
    <form className="card form-card" onSubmit={submit}>
      <h1>Daftar sebagai mentor</h1>
      <Notice type={msg.type}>{msg.text}</Notice>
      <Field label="Bidang keahlian">
        <input
          required
          value={form.expertise}
          onChange={(e) => setForm({ ...form, expertise: e.target.value })}
        />
      </Field>
      <Field label="Jenjang pendidikan">
        <select
          value={form.education_level}
          onChange={(e) => setForm({ ...form, education_level: e.target.value })}
        >
          {["SMA", "D3", "S1", "S2", "S3"].map((l) => (
            <option key={l}>{l}</option>
          ))}
        </select>
      </Field>
      <button className="btn btn-primary">Kirim pendaftaran</button>
    </form>
  );
}
