import { useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import { Field, Notice } from "../components/ui.jsx";
import Icon from "../components/Icon.jsx";

export default function Register() {
  const { user, register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  if (user) return <Navigate to="/" replace />;
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      await register(form);
      navigate("/");
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-hero">
        <span className="brand-mark big">
          <Icon name="book" size={30} />
        </span>
        <h1>Mulai belajar bersama di TemanBelajar.</h1>
        <p>Buat akun gratis, lalu gabung ke kelompok belajar yang kamu suka.</p>
      </div>
      <form className="card login-card" onSubmit={submit}>
        <h2>Buat akun baru</h2>
        <Notice type="error">{error}</Notice>
        <Field label="Nama lengkap">
          <input required value={form.name} onChange={set("name")} />
        </Field>
        <Field label="Email">
          <input type="email" required value={form.email} onChange={set("email")} />
        </Field>
        <Field label="Kata sandi (minimal 6 karakter)">
          <input type="password" minLength={6} required value={form.password} onChange={set("password")} />
        </Field>
        <button className="btn btn-primary" disabled={busy}>
          {busy ? "Memproses..." : "Daftar"}
        </button>
        <p className="muted">
          Sudah punya akun? <Link to="/login">Masuk</Link>
        </p>
      </form>
    </div>
  );
}
