import { Navigate, Route, Routes } from "react-router-dom";
import { useAuth } from "./context/AuthContext.jsx";
import Layout from "./components/Layout.jsx";
import Login from "./pages/Login.jsx";
import Register from "./pages/Register.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import Groups from "./pages/Groups.jsx";
import GroupDetail from "./pages/GroupDetail.jsx";
import CreateGroup from "./pages/CreateGroup.jsx";
import Mentors from "./pages/Mentors.jsx";
import MentorDetail from "./pages/MentorDetail.jsx";
import MentorRegister from "./pages/MentorRegister.jsx";
import AdminMentors from "./pages/AdminMentors.jsx";
import Progress from "./pages/Progress.jsx";

function Protected({ children, staff, admin }) {
  const { user, isStaff, isAdmin } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (admin && !isAdmin) return <Navigate to="/" replace />;
  if (staff && !isStaff) return <Navigate to="/" replace />;
  return children;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route
        element={
          <Protected>
            <Layout />
          </Protected>
        }
      >
        <Route index element={<Dashboard />} />
        <Route path="groups" element={<Groups />} />
        <Route
          path="groups/new"
          element={
            <Protected staff>
              <CreateGroup />
            </Protected>
          }
        />
        <Route path="groups/:id" element={<GroupDetail />} />
        <Route path="mentors" element={<Mentors />} />
        <Route path="mentors/register" element={<MentorRegister />} />
        <Route path="mentors/:id" element={<MentorDetail />} />
        <Route path="progress" element={<Progress />} />
        <Route
          path="admin/mentors"
          element={
            <Protected admin>
              <AdminMentors />
            </Protected>
          }
        />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
