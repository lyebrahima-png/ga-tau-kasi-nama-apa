import { createContext, useContext, useState } from "react";
import * as API from "../api/index.js";
import { setToken } from "../api/client.js";

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

// Peran sesuai backend: "admin", "user", "petugas"
export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("tb_user"));
    } catch {
      return null;
    }
  });

  const persist = (u) => {
    setUser(u);
    if (u) localStorage.setItem("tb_user", JSON.stringify(u));
    else localStorage.removeItem("tb_user");
  };

  const login = async (email, password) => {
    const res = await API.login(email, password);
    const data = res?.data ?? res;
    setToken(data.token || data.access_token);
    persist(data.user);
    return data.user;
  };

  const register = async (payload) => {
    const res = await API.register(payload);
    const data = res?.data ?? res;
    setToken(data.token || data.access_token);
    persist(data.user);
    return data.user;
  };

  const logout = () => {
    setToken(null);
    persist(null);
  };

  const role = user?.role || "user";
  return (
    <AuthContext.Provider
      value={{
        user,
        role,
        login,
        register,
        logout,
        isAdmin: role === "admin",
        isStaff: role === "petugas" || role === "admin",
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}
