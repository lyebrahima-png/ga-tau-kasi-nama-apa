import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import Icon from "./Icon.jsx";
import Avatar from "./Avatar.jsx";

export default function Layout() {
  const { user, role, logout, isAdmin, isStaff } = useAuth();
  const navigate = useNavigate();

  const links = [
    { to: "/", label: "Dashboard", icon: "dashboard", end: true },
    { to: "/groups", label: "Kelompok belajar", icon: "group" },
    { to: "/mentors", label: "Mentor", icon: "mentor" },
    { to: "/progress", label: "Catat progres", icon: "chart" },
  ];
  if (isStaff) links.push({ to: "/groups/new", label: "Buat kelompok", icon: "plus" });
  if (!isAdmin && role !== "petugas")
    links.push({ to: "/mentors/register", label: "Jadi mentor", icon: "book" });
  if (isAdmin) links.push({ to: "/admin/mentors", label: "Verifikasi mentor", icon: "shield" });

  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand">
          <span className="brand-mark">
            <Icon name="book" size={22} />
          </span>
          <span>TemanBelajar</span>
        </div>

        <nav className="nav" aria-label="Menu utama">
          {links.map((l) => (
            <NavLink key={l.to} to={l.to} end={l.end} className="nav-link">
              <Icon name={l.icon} />
              {l.label}
            </NavLink>
          ))}
        </nav>

        <button
          className="nav-link nav-logout"
          onClick={() => {
            logout();
            navigate("/login");
          }}
        >
          <Icon name="logout" />
          Keluar
        </button>
      </aside>

      <div className="main">
        <header className="topbar">
          <div className="search">
            <Icon name="search" size={18} />
            <input
              placeholder="Cari kelompok belajar..."
              onKeyDown={(e) => {
                if (e.key === "Enter")
                  navigate(`/groups?q=${encodeURIComponent(e.target.value)}`);
              }}
            />
          </div>
          <div className="user-chip">
            <Avatar name={user?.name || "Pengguna"} size={38} />
            <div>
              <strong>{user?.name || "Pengguna"}</strong>
              <small>{role}</small>
            </div>
          </div>
        </header>
        <main className="content">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
