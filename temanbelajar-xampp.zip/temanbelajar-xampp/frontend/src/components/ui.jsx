import { useEffect, useState } from "react";

// Hook kecil untuk mengambil data: { data, loading, error, reload }
export function useFetch(fn, deps = []) {
  const [state, setState] = useState({ data: null, loading: true, error: "" });
  const [tick, setTick] = useState(0);

  useEffect(() => {
    let alive = true;
    setState((s) => ({ ...s, loading: true, error: "" }));
    fn()
      .then((data) => alive && setState({ data, loading: false, error: "" }))
      .catch((e) => alive && setState({ data: null, loading: false, error: e.message }));
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, tick]);

  return { ...state, reload: () => setTick((t) => t + 1) };
}

export function Status({ loading, error, empty, emptyText }) {
  if (loading) return <p className="muted">Memuat data...</p>;
  if (error) return <p className="alert alert-error">{error}</p>;
  if (empty) return <p className="muted empty">{emptyText || "Belum ada data."}</p>;
  return null;
}

export function Notice({ type = "ok", children }) {
  if (!children) return null;
  return <p className={`alert alert-${type}`}>{children}</p>;
}

export function Field({ label, children }) {
  return (
    <label className="field">
      <span>{label}</span>
      {children}
    </label>
  );
}

export function Badge({ children, tone = "purple" }) {
  return <span className={`badge badge-${tone}`}>{children}</span>;
}

export const statusTone = (s) =>
  ({ verified: "green", approved: "green", active: "green", pending: "amber", rejected: "red" }[
    s
  ] || "purple");
