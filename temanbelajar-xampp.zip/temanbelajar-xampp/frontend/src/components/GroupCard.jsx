import { Link } from "react-router-dom";
import Icon from "./Icon.jsx";

const tints = ["#e9e6ff", "#e3f4ff", "#ffeede", "#e2f7ef", "#fde6f0"];

export default function GroupCard({ group }) {
  const tint = tints[(group.id || 0) % tints.length];
  return (
    <Link to={`/groups/${group.id}`} className="card group-card">
      <div className="group-cover" style={{ background: tint }}>
        <Icon name="book" size={30} />
        <span className="chip">{group.subject || "Umum"}</span>
      </div>
      <h3>{group.title}</h3>
      <p className="muted clamp">{group.description || "Belum ada deskripsi."}</p>
      <div className="group-meta">
        <span>
          <Icon name="group" size={16} /> Anggota {group.member_count ?? 0}/{group.capacity ?? "-"}
        </span>
        {group.mentor_name && <span>{group.mentor_name}</span>}
      </div>
    </Link>
  );
}
