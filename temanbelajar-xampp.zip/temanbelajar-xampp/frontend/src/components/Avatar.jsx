const colors = ["#6c5ce7", "#00a38c", "#e17055", "#0984e3", "#d63384", "#b8860b"];

export default function Avatar({ name = "?", size = 40 }) {
  const initials = name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0].toUpperCase())
    .join("");
  const color = colors[(name.charCodeAt(0) || 0) % colors.length];
  return (
    <span
      className="avatar"
      style={{ width: size, height: size, background: color, fontSize: size * 0.38 }}
    >
      {initials || "?"}
    </span>
  );
}
