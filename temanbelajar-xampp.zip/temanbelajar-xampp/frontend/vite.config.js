import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";

// Development: request /api/... diteruskan ke API PHP di XAMPP (Apache, port 80).
// Ubah XAMPP_API bila nama folder API di htdocs berbeda.
const XAMPP_API = "http://localhost/temanbelajar-api";

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), "");
  return {
    base: env.VITE_BASE || "/",
    plugins: [react()],
    server: {
      port: 5173,
      proxy: {
        "/api": { target: XAMPP_API, changeOrigin: true },
      },
    },
  };
});
