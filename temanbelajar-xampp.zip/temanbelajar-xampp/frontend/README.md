# TemanBelajar — Frontend (React + Vite)

Tampilan gaya dashboard Studypad. Backend-nya ada di folder `../temanbelajar-api` (PHP + MySQL, jalan di XAMPP).
Cara menjalankan keduanya ada di README folder induk.
