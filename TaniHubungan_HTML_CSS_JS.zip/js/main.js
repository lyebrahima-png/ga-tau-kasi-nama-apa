/* TaniHubungan – interaksi halaman landing */
(() => {
  'use strict';

  const header = document.getElementById('site-header');
  const nav = document.getElementById('main-nav');
  const toggle = document.getElementById('menu-toggle');

  /* Bayangan header saat halaman digulir */
  const onScroll = () => header.classList.toggle('is-scrolled', window.scrollY > 4);
  onScroll();
  window.addEventListener('scroll', onScroll, { passive: true });

  /* Menu seluler */
  const setMenu = (open) => {
    nav.classList.toggle('is-open', open);
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'Tutup menu' : 'Buka menu');
  };
  toggle.addEventListener('click', () => setMenu(!nav.classList.contains('is-open')));
  nav.addEventListener('click', (e) => { if (e.target.closest('a')) setMenu(false); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') setMenu(false); });
  window.matchMedia('(min-width: 1025px)').addEventListener('change', (e) => { if (e.matches) setMenu(false); });

  /* Tandai tautan navigasi sesuai bagian yang sedang terlihat */
  const links = [...nav.querySelectorAll('a[href^="#"]:not(.btn)')];
  const sections = links.map((a) => document.querySelector(a.getAttribute('href'))).filter(Boolean);
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        links.forEach((a) => a.classList.toggle('is-active', a.getAttribute('href') === '#' + entry.target.id));
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    sections.forEach((s) => observer.observe(s));
  }

  /* Filter kartu harga berdasarkan komoditas dan wilayah */
  const commodity = document.getElementById('filter-commodity');
  const region = document.getElementById('filter-region');
  const cards = [...document.querySelectorAll('#price-grid .price-card')];
  const empty = document.getElementById('price-empty');

  const applyFilters = () => {
    let visible = 0;
    cards.forEach((card) => {
      const show = (commodity.value === 'all' || card.dataset.commodity === commodity.value) && card.dataset.region === region.value;
      card.hidden = !show;
      if (show) visible += 1;
    });
    empty.hidden = visible > 0;
  };
  commodity.addEventListener('change', applyFilters);
  region.addEventListener('change', applyFilters);
  applyFilters();
})();
