/* SahabatLansia — perilaku interaktif (migrasi dari React/App.tsx ke JavaScript biasa) */
(function () {
  'use strict';

  var ATTRS = 'aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"';
  var ICONS = {
    menu:  '<svg ' + ATTRS + '><path d="M4 7h16M4 12h16M4 17h16"/></svg>',
    close: '<svg ' + ATTRS + '><path d="m6 6 12 12M18 6 6 18"/></svg>'
  };

  var root = document.getElementById('root');
  var pages = {};
  var pristine = {};
  var current = 'landing';
  var toastTimer = null;

  // Simpan kondisi awal tiap halaman agar setiap kali halaman dibuka
  // statusnya segar kembali (seperti komponen React yang di-mount ulang).
  root.querySelectorAll('.page').forEach(function (el) {
    var name = el.getAttribute('data-page');
    pages[name] = el;
    pristine[name] = el.innerHTML;
  });

  function navigate(next) {
    if (next !== current && pages[next]) {
      pages[current].hidden = true;
      pages[next].innerHTML = pristine[next];
      pages[next].hidden = false;
      current = next;
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function activePage() { return pages[current]; }

  document.addEventListener('click', function (e) {
    var t = e.target;
    if (!(t instanceof Element)) return;
    var page = activePage();
    var el;

    // Menu mobile (landing)
    if ((el = t.closest('[data-menu-toggle]'))) {
      var links = page.querySelector('.nav-links');
      var open = links.classList.toggle('open');
      el.innerHTML = open ? ICONS.close : ICONS.menu;
      return;
    }

    // Scroll halus ke bagian di landing
    if ((el = t.closest('[data-scroll]'))) {
      var target = document.getElementById(el.getAttribute('data-scroll'));
      if (target) target.scrollIntoView({ behavior: 'smooth' });
      return;
    }

    // Pilihan peran di halaman login
    if ((el = t.closest('[data-role]'))) {
      page.querySelectorAll('[data-role]').forEach(function (b) { b.classList.remove('selected'); });
      el.classList.add('selected');
      return;
    }

    // Menu profil (keluarga)
    if (t.closest('[data-profile-toggle]')) {
      var tools = page.querySelector('.header-tools');
      var menu = tools.querySelector('.profile-menu');
      if (menu) {
        menu.remove();
      } else {
        menu = document.createElement('div');
        menu.className = 'profile-menu';
        menu.innerHTML = '<button data-navigate="landing">Keluar dari akun</button>';
        tools.appendChild(menu);
      }
      return;
    }

    // Filter catatan
    if ((el = t.closest('[data-filter]'))) {
      page.querySelectorAll('[data-filter]').forEach(function (b) { b.classList.remove('active'); });
      el.classList.add('active');
      return;
    }

    // Modal: buka / tutup
    if ((el = t.closest('[data-open-modal]'))) {
      var m = page.querySelector('[data-modal="' + el.getAttribute('data-open-modal') + '"]');
      if (m) m.hidden = false;
      return;
    }
    if ((el = t.closest('[data-call]'))) {
      var call = page.querySelector('[data-modal="call"]');
      call.querySelector('[data-call-name]').textContent = el.getAttribute('data-call');
      call.hidden = false;
      return;
    }
    if (t.closest('[data-close-modal]')) {
      var box = t.closest('.modal-backdrop');
      if (box) {
        box.hidden = true;
        var f = box.querySelector('form');
        if (f) f.reset();
      }
      return;
    }

    // Toast
    if (t.closest('[data-dismiss-toast]')) {
      var ts = page.querySelector('[data-toast]');
      if (ts) ts.hidden = true;
      return;
    }

    // Navigasi antar halaman
    if ((el = t.closest('[data-navigate]'))) {
      navigate(el.getAttribute('data-navigate'));
    }
  });

  document.addEventListener('submit', function (e) {
    var form = e.target;
    e.preventDefault();

    // Login: arahkan sesuai peran yang dipilih
    if (form.hasAttribute('data-login-form')) {
      var sel = form.querySelector('[data-role].selected');
      var role = sel ? sel.getAttribute('data-role') : 'family';
      navigate(role === 'family' ? 'dashboard' : role === 'admin' ? 'admin' : 'caregiver');
      return;
    }

    // Simpan pengingat obat: tutup modal, tampilkan toast 3 detik
    if (form.hasAttribute('data-medication-form')) {
      var page = activePage();
      var box = form.closest('.modal-backdrop');
      box.hidden = true;
      form.reset();
      var toast = page.querySelector('[data-toast]');
      toast.hidden = false;
      clearTimeout(toastTimer);
      toastTimer = setTimeout(function () { toast.hidden = true; }, 3000);
    }
  });
})();
