/* ==========================================================================
   Sirkula Langsa — script.js
   Dimigrasi dari komponen React <FeatureSection /> ke JavaScript murni.

   Perilaku (identik dengan versi React):
   - Tab (desktop) dan accordion (mobile) memakai satu state "active" yang sama.
   - Fitur berganti otomatis setiap 6 detik.
   - Setelah pengguna berinteraksi (klik tab/accordion atau menyentuh section),
     rotasi otomatis berhenti dan bar progres dihapus.
   ========================================================================== */

(function () {
  'use strict';

  var ROTATE_MS = 6000;

  var section = document.getElementById('fitur-utama');
  if (!section) return;

  var desktop = section.querySelector('.desktop-features');
  var tabs = Array.prototype.slice.call(section.querySelectorAll('.feature-tab'));
  var cards = Array.prototype.slice.call(section.querySelectorAll('.accordion-card'));

  // id fitur diambil dari id tab: "tab-jadwal" -> "jadwal"
  var ids = tabs.map(function (tab) { return tab.id.replace(/^tab-/, ''); });

  var active = 0;
  var hasInteracted = false;
  var timer = null;

  /* ---------- Bar progres rotasi ---------- */

  function removeProgress() {
    var bar = desktop.querySelector('.rotation-progress');
    if (bar) bar.remove();
  }

  // Dibuat ulang setiap fitur berganti agar animasi 6 detik mulai dari awal
  function renderProgress() {
    removeProgress();
    if (hasInteracted) return;
    var bar = document.createElement('div');
    bar.className = 'rotation-progress';
    bar.appendChild(document.createElement('span'));
    desktop.appendChild(bar);
  }

  /* ---------- Render state ---------- */

  function renderTabs() {
    tabs.forEach(function (tab, i) {
      var on = i === active;
      tab.classList.toggle('active', on);
      tab.setAttribute('aria-selected', String(on));
    });
  }

  function renderAccordion() {
    cards.forEach(function (card, i) {
      var on = i === active;
      card.classList.toggle('open', on);
      card.querySelector(':scope > button').setAttribute('aria-expanded', String(on));
      card.querySelector('.accordion-body').hidden = !on;
    });
  }

  // Panel desktop dibuat ulang (bukan sekadar diubah) agar animasi masuk berjalan lagi.
  // Isinya disalin dari konten fitur yang sama di accordion, sehingga markup tidak terduplikasi di JS.
  function renderPanel() {
    var id = ids[active];
    var panel = document.createElement('div');
    panel.className = 'feature-panel';
    panel.setAttribute('role', 'tabpanel');
    panel.id = 'panel-' + id;
    panel.setAttribute('aria-labelledby', 'tab-' + id);
    panel.appendChild(cards[active].querySelector('.feature-panel-content').cloneNode(true));
    desktop.querySelector('.feature-panel').replaceWith(panel);
  }

  function render() {
    renderTabs();
    renderAccordion();
    renderPanel();
    renderProgress();
  }

  /* ---------- State ---------- */

  function setActive(index) {
    if (index === active) return;
    active = index;
    render();
  }

  function markInteracted() {
    if (hasInteracted) return;
    hasInteracted = true;
    window.clearInterval(timer);
    removeProgress();
  }

  function choose(index) {
    markInteracted();
    setActive(index);
  }

  /* ---------- Event ---------- */

  tabs.forEach(function (tab, i) {
    tab.addEventListener('click', function () { choose(i); });
  });

  cards.forEach(function (card, i) {
    card.querySelector(':scope > button').addEventListener('click', function () { choose(i); });
  });

  section.addEventListener('pointerdown', markInteracted);

  /* ---------- Rotasi otomatis ---------- */

  timer = window.setInterval(function () {
    setActive((active + 1) % ids.length);
  }, ROTATE_MS);
})();
