/* TaniHubungan – navigasi antarperan/halaman dan wizard penawaran */
(function () {
  'use strict';

  var slug = function (s) {
    return s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  };
  var fileOf = function (role, page) {
    return role === 'Publik' ? 'index.html' : slug(role) + '-' + slug(page) + '.html';
  };
  var go = function (role, page) {
    window.location.href = fileOf(role, page || 'Dashboard');
  };
  var text = function (el) { return el.textContent.replace(/\s+/g, ' ').trim(); };
  var role = document.body.getAttribute('data-role');

  document.addEventListener('click', function (e) {
    var btn = e.target.closest('button');
    if (!btn || btn.disabled) return;

    // Pratinjau peran (bilah atas)
    if (btn.closest('.role-switcher')) { go(text(btn)); return; }

    // Keluar
    if (btn.matches('.back-public, .exit')) { go('Publik'); return; }

    // Halaman publik (landing)
    if (role === 'Publik') {
      if (btn.closest('.nav-actions') || btn.closest('.closing')) { go('Petani'); return; }
      if (btn.closest('.hero-actions')) {
        go(btn.classList.contains('secondary') ? 'Pembeli' : 'Petani');
      }
      return;
    }

    // Menu samping (Admin & Petugas)
    if (btn.closest('.sidebar nav')) { go(role, text(btn.querySelector('span'))); return; }

    // Menu atas (Petani & Pembeli)
    var userNavLinks = document.querySelector('.user-nav > div:nth-child(2)');
    if (userNavLinks && userNavLinks.contains(btn)) { go(role, text(btn)); return; }

    // Wizard penawaran
    if (btn.closest('.form-actions')) { wizardAction(btn); return; }

    // Pintasan di dashboard Petani / Pembeli
    if (document.querySelector('.user-nav')) {
      if (btn.closest('.welcome') && btn.classList.contains('primary') && role === 'Petani') { go(role, 'Buat Penawaran'); return; }
      if (btn.closest('.buyer-hero') && btn.closest('label')) { go(role, 'Cari Hasil Panen'); return; }
      if (btn.classList.contains('link-btn') && btn.closest('.heading-row.compact')) {
        go(role, role === 'Pembeli' ? 'Cari Hasil Panen' : 'Informasi Harga');
      }
    }
  });

  /* ----- Wizard "Buat Penawaran" ----- */
  var step = 1;
  function renderStep() {
    var holder = document.querySelector('.form-page');
    if (!holder || !window.WIZARD || !window.WIZARD[role]) return;
    holder.outerHTML = window.WIZARD[role][step - 1];
  }
  function wizardAction(btn) {
    if (!document.querySelector('.form-page')) return;
    var isPrimary = btn.classList.contains('primary');
    if (isPrimary) { step = step < 4 ? step + 1 : 1; }
    else { step = Math.max(1, step - 1); }
    renderStep();
  }
})();
