/* Frontend chat: API key tidak pernah dikirim ke browser. */
(function(){
  'use strict';
  var form=document.getElementById('ai-form'); if(!form)return;
  var input=document.getElementById('ai-input'), list=document.getElementById('ai-messages'), send=document.getElementById('ai-send');
  var history=[];
  function addMessage(role,text){var row=document.createElement('article');row.className='ai-message '+(role==='user'?'user':'assistant');var avatar=document.createElement('div');avatar.className='ai-message-avatar';avatar.textContent=role==='user'?'👤':'🌱';var bubble=document.createElement('div');bubble.className='ai-bubble';var name=document.createElement('strong');name.textContent=role==='user'?'Kamu':'Asisten AI';var body=document.createElement('p');body.textContent=text;bubble.append(name,body);row.append(avatar,bubble);list.appendChild(row);list.scrollTop=list.scrollHeight;return row;}
  async function ask(text){addMessage('user',text);history.push({role:'user',parts:[{text:text}]});var typing=document.createElement('div');typing.className='ai-typing';typing.textContent='Asisten AI sedang mengetik…';list.appendChild(typing);list.scrollTop=list.scrollHeight;send.disabled=true;
    try{var response=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({messages:history})});var data=await response.json();if(!response.ok)throw new Error(data.error||'Tidak dapat menghubungi layanan AI.');var answer=data.reply||'Maaf, saya belum mendapatkan jawaban.';history.push({role:'model',parts:[{text:answer}]});typing.remove();addMessage('assistant',answer);}
    catch(err){typing.remove();history.pop();addMessage('assistant','Maaf, terjadi kendala: '+err.message+' Pastikan server aktif dan API Key Gemini sudah diatur di file .env.');}
    finally{send.disabled=false;input.focus();}
  }
  form.addEventListener('submit',function(e){e.preventDefault();var text=input.value.trim();if(!text||send.disabled)return;input.value='';input.style.height='auto';ask(text);});
  input.addEventListener('input',function(){input.style.height='auto';input.style.height=Math.min(input.scrollHeight,110)+'px';});
  document.querySelectorAll('[data-prompt]').forEach(function(btn){btn.addEventListener('click',function(){if(!send.disabled)ask(btn.getAttribute('data-prompt'));});});
  document.getElementById('ai-clear').addEventListener('click',function(){history=[];list.innerHTML='';addMessage('assistant','Percakapan dibersihkan. Silakan mulai pertanyaan baru!');});
})();
