/* TaniHubungan – navigasi antarperan/halaman dan wizard penawaran */
(function () {
  'use strict';

  var slug = function (s) {
    return s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  };
  var fileOf = function (role, page) {
    return role === 'Publik' ? 'index.html' : slug(role) + '-' + slug(page) + '.html';
  };
  // Peran "Petugas" sudah digabung ke "Admin"; nama menu lama diarahkan ke menu baru
  var PAGE_ALIAS = {
    'Pantau Penawaran': 'Penawaran', 'Antrean Penawaran': 'Penawaran',
    'Verifikasi Petani': 'Verifikasi Mitra',
    'Sumber Harga': 'Data Harga', 'Sumber Data Harga': 'Data Harga', 'Perbarui Data Harga': 'Data Harga',
    'Laporan Penipuan': 'Laporan Masalah', 'Laporan Data Tidak Sesuai': 'Laporan Masalah'
  };
  var go = function (role, page) {
    if (role === 'Petugas') role = 'Admin';
    page = page || 'Dashboard';
    if (role === 'Admin' && PAGE_ALIAS[page]) page = PAGE_ALIAS[page];
    window.location.href = fileOf(role, page);
  };
  var text = function (el) { return el.textContent.replace(/\s+/g, ' ').trim(); };
  var role = document.body.getAttribute('data-role');
  function downloadTable(filename, title) {
    var rows = Array.from(document.querySelectorAll('main table tr')).map(function(tr){
      return Array.from(tr.querySelectorAll('th,td')).map(function(td){
        return '"' + text(td).replace(/"/g,'""') + '"';
      }).join(',');
    });
    if (!rows.length) rows = [['"Informasi"','"Keterangan"'],['"' + title + '"','"Belum ada data tabel pada halaman ini"']].map(function(r){return r.join(',');});
    var csv = '\ufeff' + rows.join('\r\n');
    var blob = new Blob([csv], {type:'text/csv;charset=utf-8;'});
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a'); a.href=url; a.download=filename; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function(){URL.revokeObjectURL(url);},1000);
    notify(title + ' berhasil diunduh.');
  }


  document.addEventListener('click', function (e) {
    var btn = e.target.closest('button');
    if (!btn || btn.disabled) return;

    // Tombol pendaftaran berdasarkan jenis pengguna pada halaman utama.
    if (btn.hasAttribute('data-register-role')) {
      window.location.href = 'register.html?role=' + encodeURIComponent(btn.getAttribute('data-register-role'));
      return;
    }

    // Tombol Tambah Data di bagian judul halaman.
    if (/tambah data/i.test(text(btn)) && btn.closest('.welcome')) {
      var heading = btn.closest('.app-content')?.querySelector('.welcome h1');
      openDialog('Tambah data' + (heading ? ' — ' + text(heading) : ''),
        'Masukkan informasi baru. Data contoh akan disimpan secara lokal pada browser.',
        ['Nama / Komoditas','Jumlah atau nilai','Keterangan']);
      return;
    }

    // Pagination: tombol halaman dan panah dapat dipilih serta memperbarui indikator aktif.
    if (btn.closest('.pagination')) {
      var pager = btn.closest('.pagination');
      var pagerButtons = Array.from(pager.querySelectorAll('button'));
      var pageButtons = pagerButtons.filter(function(b){ return /^\\d+$/.test(text(b)); });
      if (pageButtons.length) {
        var current = pageButtons.findIndex(function(b){ return b.classList.contains('current') || b.classList.contains('active'); });
        if (current < 0) current = 0;
        var label = text(btn);
        var next = label === '‹' ? Math.max(0,current-1) :
                   label === '›' ? Math.min(pageButtons.length-1,current+1) :
                   pageButtons.indexOf(btn);
        if (next >= 0) {
          pageButtons.forEach(function(b,i){ b.classList.toggle('current',i===next); b.classList.toggle('active',i===next); });
          var summary = pager.querySelector('span');
          if (summary) summary.textContent = 'Halaman ' + text(pageButtons[next]) + ' dipilih';
          notify('Halaman ' + text(pageButtons[next]) + ' ditampilkan.');
        }
      }
      return;
    }

    var actionLabel = text(btn).toLowerCase();
    if (actionLabel.includes('unduh ringkasan')) { downloadTable('ringkasan-tanihubungan.csv','Ringkasan'); return; }
    if (actionLabel.includes('ekspor laporan')) { downloadTable('laporan-tanihubungan.csv','Ekspor laporan'); return; }
    if (actionLabel.includes('unduh riwayat')) { downloadTable('riwayat-verifikasi.csv','Riwayat verifikasi'); return; }
    if (actionLabel.includes('atur prioritas')) {
      openDialog('Atur prioritas penawaran','Pilih tingkat prioritas untuk antrean penawaran.', ['Nama penawaran','Prioritas (Tinggi / Sedang / Rendah)','Catatan']);
      return;
    }
    if (actionLabel.includes('tambah sumber')) {
      openDialog('Tambah sumber harga','Masukkan sumber data harga baru.', ['Nama sumber','URL / alamat sumber','Wilayah','Keterangan']);
      return;
    }
    if (actionLabel.includes('hubungi dukungan') || actionLabel.includes('bantuan')) {
      openDialog('Pusat Bantuan TaniHubungan','Jelaskan kendala atau pertanyaan kamu. Tim dukungan dapat dihubungi melalui email dukungan TaniHubungan.', ['Nama','Email','Pesan bantuan']);
      return;
    }

    // Akses akun dari halaman publik
    if (btn.closest('.nav-actions')) {
      var navLabel = text(btn).toLowerCase();
      if (navLabel.indexOf('masuk') >= 0) { window.location.href = 'login.html'; return; }
      if (navLabel.indexOf('daftar') >= 0) { window.location.href = 'register.html'; return; }
    }

    // Pratinjau peran (bilah atas, bila digunakan pada versi lama)
    if (btn.closest('.role-switcher')) { go(text(btn)); return; }

    // Keluar
    if (btn.matches('.back-public, .exit')) { go('Publik'); return; }

    // Halaman publik (landing)
    if (role === 'Publik') {
      if (btn.closest('.nav-actions') || btn.closest('.closing')) { go('Petani'); return; }
      if (btn.closest('.hero-actions')) {
        go(btn.classList.contains('secondary') ? 'Pembeli' : 'Petani');
      }
      return;
    }

    // Menu samping (Admin & Petugas)
    if (btn.closest('.sidebar nav')) { go(role, text(btn.querySelector('span'))); return; }

    // Pintasan di halaman Admin (gabungan Admin + Petugas)
    if (role === 'Admin') {
      var file = window.location.pathname.split('/').pop();
      var panel = btn.closest('.panel');
      var ptitle = panel && panel.querySelector('.panel-title h3');
      ptitle = ptitle ? text(ptitle) : '';
      if (btn.closest('.fraud-row')) { go(role, 'Laporan Masalah'); return; }
      if (btn.classList.contains('link-btn')) {
        if (ptitle === 'Antrean terbaru') { go(role, 'Penawaran'); return; }
        if (ptitle === 'Akun menunggu verifikasi') { go(role, 'Verifikasi Mitra'); return; }
      }
      if (btn.closest('.merge-head') && /Mulai verifikasi/.test(text(btn))) { go(role, 'Verifikasi Mitra'); return; }
      if (btn.classList.contains('table-action') && /^Periksa/.test(text(btn)) &&
          (file === 'admin-dashboard.html' || file === 'admin-penawaran.html')) { go(role, 'Verifikasi Mitra'); return; }
      return;
    }

    // Menu atas (Petani & Pembeli)
    var userNavLinks = document.querySelector('.user-nav > div:nth-child(2)');
    if (userNavLinks && userNavLinks.contains(btn)) { go(role, text(btn)); return; }

    // Wizard penawaran
    if (btn.closest('.form-actions')) { wizardAction(btn); return; }

    // Pintasan di dashboard Petani / Pembeli
    if (document.querySelector('.user-nav')) {
      if (btn.closest('.welcome') && btn.classList.contains('primary') && role === 'Petani') { go(role, 'Buat Penawaran'); return; }
      if (btn.closest('.buyer-hero') && btn.closest('label')) { go(role, 'Cari Hasil Panen'); return; }
      if (btn.classList.contains('link-btn') && btn.closest('.heading-row.compact')) {
        go(role, role === 'Pembeli' ? 'Cari Hasil Panen' : 'Informasi Harga');
      }
    }
  });

  /* ----- Wizard "Buat Penawaran" ----- */
  var step = 1;
  function renderStep() {
    var holder = document.querySelector('.form-page');
    if (!holder || !window.WIZARD || !window.WIZARD[role]) return;
    holder.outerHTML = window.WIZARD[role][step - 1];
  }
  function wizardAction(btn) {
    if (!document.querySelector('.form-page')) return;
    var isPrimary = btn.classList.contains('primary');
    if (isPrimary) { step = step < 4 ? step + 1 : 1; }
    else { step = Math.max(1, step - 1); }
    renderStep();
  }
})();


/* ===== TaniHubungan: interaksi tambahan tanpa mengubah susunan elemen asli ===== */
(function () {
  'use strict';
  var role = document.body.getAttribute('data-role') || 'Publik';
  var routeMap = {
    'dashboard':'Dashboard','informasi harga':'Informasi Harga','buat penawaran':'Buat Penawaran',
    'penawaran saya':'Penawaran Saya','calon pembeli':'Calon Pembeli','cari hasil panen':'Cari Hasil Panen',
    'negosiasi':'Negosiasi','kesepakatan':'Kesepakatan','penawaran':'Penawaran',
    'verifikasi mitra':'Verifikasi Mitra','data harga':'Data Harga','laporan masalah':'Laporan Masalah',
    'riwayat verifikasi':'Riwayat Verifikasi','kelola akun':'Kelola Akun',
    'kategori komoditas':'Kategori Komoditas','aktivitas pembeli':'Aktivitas Pembeli',
    'laporan perdagangan':'Laporan Perdagangan','status penjualan':'Status Penjualan'
  };
  function clean(s){return (s||'').replace(/\s+/g,' ').replace(/[⌄›‹→←]/g,'').trim().toLowerCase();}
  function notify(message){
    var old=document.querySelector('.th-toast'); if(old) old.remove();
    var el=document.createElement('div'); el.className='th-toast'; el.setAttribute('role','status');
    el.textContent=message; document.body.appendChild(el);
    requestAnimationFrame(function(){el.classList.add('show');});
    setTimeout(function(){el.classList.remove('show');setTimeout(function(){el.remove();},250);},2600);
  }
  function go(roleName,page){
    var r=roleName==='Petugas'?'Admin':roleName;
    var p=routeMap[clean(page)] || page;
    if(r==='Publik'){location.href='index.html';return;}
    var file=r.toLowerCase()+'-'+p.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')+'.html';
    if(r==='Admin' && clean(p)==='dashboard') file='admin-dashboard.html';
    if(r==='Petani' && clean(p)==='dashboard') file='petani-dashboard.html';
    if(r==='Pembeli' && clean(p)==='dashboard') file='pembeli-dashboard.html';
    location.href=file;
  }
  function openDialog(title, description, fields){
    var existing=document.querySelector('.th-modal-backdrop'); if(existing) existing.remove();
    var backdrop=document.createElement('div'); backdrop.className='th-modal-backdrop';
    var dialog=document.createElement('section'); dialog.className='th-modal'; dialog.setAttribute('role','dialog'); dialog.setAttribute('aria-modal','true');
    var fieldHtml=(fields||['Nama','Keterangan']).map(function(label,i){
      return '<label>'+label+'<input name="field'+i+'" placeholder="Masukkan '+label.toLowerCase()+'" '+(i===0?'required':'')+'></label>';
    }).join('');
    dialog.innerHTML='<button class="th-modal-close" type="button" aria-label="Tutup">×</button><span class="th-modal-kicker">TANIHUBUNGAN</span><h2></h2><p></p><form>'+fieldHtml+'<div class="th-modal-actions"><button type="button" class="btn secondary th-cancel">Batal</button><button type="submit" class="btn primary">Simpan</button></div></form>';
    dialog.querySelector('h2').textContent=title; dialog.querySelector('p').textContent=description||'Lengkapi informasi berikut untuk melanjutkan.';
    backdrop.appendChild(dialog); document.body.appendChild(backdrop);
    function close(){backdrop.classList.remove('visible');setTimeout(function(){backdrop.remove();},180);}
    backdrop.addEventListener('click',function(e){if(e.target===backdrop)close();});
    dialog.querySelector('.th-modal-close').addEventListener('click',close);
    dialog.querySelector('.th-cancel').addEventListener('click',close);
    dialog.querySelector('form').addEventListener('submit',function(e){
      e.preventDefault(); var values=Array.from(dialog.querySelectorAll('input')).map(function(x){return x.value.trim();});
      if(!values[0]){dialog.querySelector('input').focus();return;}
      try{var key='tanihubungan-'+location.pathname.split('/').pop()+'-drafts';var arr=JSON.parse(localStorage.getItem(key)||'[]');arr.push({values:values,createdAt:new Date().toISOString()});localStorage.setItem(key,JSON.stringify(arr));}catch(err){}
      close();notify('Data berhasil disimpan pada perangkat ini.');
    });
    requestAnimationFrame(function(){backdrop.classList.add('visible');dialog.querySelector('input')&&dialog.querySelector('input').focus();});
  }
  // Tautan yang sebelumnya hanya berupa teks atau belum memiliki tujuan.
  document.querySelectorAll('a').forEach(function(a){
    if(!a.getAttribute('href')){
      a.setAttribute('href','#');
      a.addEventListener('click',function(e){
        e.preventDefault();
        var t=clean(a.textContent);
        if(t.indexOf('pelajari selengkapnya')>=0){
          var card=a.closest('.feature-card'); var idx=card?Array.prototype.indexOf.call(card.parentElement.children,card):0;
          var targets=['#harga','#fitur','#keamanan']; var target=document.querySelector(targets[idx]||'#fitur');
          if(target) target.scrollIntoView({behavior:'smooth',block:'start'}); else notify('Informasi fitur tersedia pada bagian fitur utama.');
        } else if(t==='bantuan'||t==='tentang kami'||t==='kebijakan privasi'){
          openDialog(a.textContent.trim(),'Informasi ini dapat dihubungkan ke halaman resmi ketika kontennya tersedia.',['Nama','Pesan']);
        } else notify('Tautan '+a.textContent.trim()+' siap dihubungkan.');
      });
    }
  });

  document.addEventListener('click',function(e){
    var btn=e.target.closest('button'); if(!btn||btn.disabled)return;
    var label=clean(btn.textContent); var pageTitle=(document.querySelector('main h1')||document.querySelector('main h2')||{}).textContent||'';
    // Navigasi dan tombol peran sudah ditangani oleh navigasi asli.
    if(btn.closest('.role-switcher')||btn.closest('.user-nav > div:nth-child(2)')||btn.closest('.sidebar nav')||
       btn.matches('.exit,.back-public')||btn.closest('.hero-actions')||btn.closest('.nav-actions')||btn.closest('.closing')||
       btn.closest('.form-actions')||btn.closest('.welcome')&&btn.classList.contains('primary')) return;
    // Tombol tambah / tombol plus membuka form yang sesuai halaman.
    if(/^(tambah| tambah)/.test(label)||label.indexOf('tambah data')>=0||label.indexOf('tambah sumber')>=0||label.indexOf('buat penawaran')>=0||
       btn.querySelector('svg path[d*="M12 5v14"]') && (btn.closest('.toolbar')||btn.closest('.heading-row'))){
      var title=label.indexOf('sumber')>=0?'Tambah Sumber Harga':label.indexOf('penawaran')>=0?'Buat Penawaran': 'Tambah Data';
      openDialog(title,'Masukkan data baru. Data contoh disimpan secara lokal di browser.', ['Nama / Komoditas','Jumlah atau nilai','Keterangan']); return;
    }
    // Tombol filter bergaya dropdown.
    if(/[⌄]/.test(btn.textContent)||btn.classList.contains('filter-btn')){
      var opts=label.indexOf('status')>=0?['Semua status','Aktif','Menunggu','Selesai','Ditolak']:
        label.indexOf('wilayah')>=0?['Semua wilayah','Aceh','Sumatera Utara','Jawa Barat','Jawa Tengah','Jawa Timur']:
        label.indexOf('komoditas')>=0?['Semua komoditas','Beras','Cabai Merah','Jagung','Bawang Merah','Tomat']:
        ['7 hari terakhir','30 hari terakhir','3 bulan terakhir','1 tahun terakhir'];
      var menu=document.createElement('div');menu.className='th-dropdown';
      opts.forEach(function(o){var item=document.createElement('button');item.type='button';item.textContent=o;item.addEventListener('click',function(){btn.textContent=o+'⌄';menu.remove();filterRows(o);});menu.appendChild(item);});
      var old=btn.parentElement.querySelector('.th-dropdown');if(old)old.remove();btn.parentElement.appendChild(menu);return;
    }
    // Tombol pencarian tersimpan / pengingat.
    if(label.indexOf('simpan pencarian')>=0||label.indexOf('atur pengingat')>=0){
      notify(label.indexOf('pengingat')>=0?'Pengingat harga berhasil diaktifkan pada demo ini.':'Pencarian berhasil disimpan pada perangkat ini.');return;
    }
    if(label==='reset'){document.querySelectorAll('input').forEach(function(x){if(x.type!=='checkbox'&&x.type!=='range')x.value='';});filterRows('');notify('Filter telah direset.');return;}
    // Favorit.
    if(label==='♡'||label==='♥'){btn.classList.toggle('is-favorite');btn.textContent=btn.classList.contains('is-favorite')?'♥':'♡';notify(btn.classList.contains('is-favorite')?'Ditambahkan ke favorit.':'Dihapus dari favorit.');return;}
    // Ekspor laporan sederhana dari tabel yang tersedia.
    if(label.indexOf('ekspor')>=0||label.indexOf('unduh')>=0){
      var table=document.querySelector('main table'); if(!table){notify('Belum ada tabel untuk diekspor.');return;}
      var csv=Array.from(table.rows).map(function(row){return Array.from(row.cells).map(function(c){return '"'+c.innerText.replace(/"/g,'""').trim()+'"';}).join(',');}).join('\n');
      var blob=new Blob([csv],{type:'text/csv;charset=utf-8;'});var url=URL.createObjectURL(blob);var a=document.createElement('a');a.href=url;a.download='tanihubungan-'+(location.pathname.split('/').pop()||'data').replace('.html','.csv');a.click();URL.revokeObjectURL(url);notify('File CSV berhasil disiapkan.');return;
    }
    // Aksi pada baris data membuka detail, bukan tombol mati.
    if(btn.classList.contains('table-action')||/^(lihat|periksa|selidiki|ubah|laporkan|minta revisi|setujui penawaran)$/.test(label)){
      var row=btn.closest('tr')||btn.closest('article')||btn.closest('.fraud-row');
      var detail=row?row.innerText.replace(/\s+/g,' ').trim():'Informasi detail belum tersedia.';
      openDialog('Detail '+(pageTitle||'Data'),detail,['Catatan / tindak lanjut']);return;
    }
    // Tombol navigasi pintas "Lihat semua".
    if(label.indexOf('lihat semua')>=0){
      if(role==='Petani')go(role,btn.closest('.panel')?'Penawaran Saya':'Informasi Harga');
      else if(role==='Pembeli')go(role,'Cari Hasil Panen');
      else if(role==='Admin')go(role,'Penawaran');
      else document.querySelector('#harga')?.scrollIntoView({behavior:'smooth'});
      return;
    }
    // Tab komoditas.
    if(btn.closest('.commodity-grid')){btn.parentElement.querySelectorAll('button').forEach(function(b){b.classList.remove('selected');});btn.classList.add('selected');return;}
    // Aksi lain diberi respons yang jelas.
    if(label) notify('Aksi "'+btn.textContent.trim()+'" dipilih.');
  });

  function filterRows(query){
    var q=clean(query);
    document.querySelectorAll('main table tbody tr, main .price-card, main .feature-card, main .result-card').forEach(function(el){
      el.style.display=!q||clean(el.textContent).indexOf(q)>=0?'':'none';
    });
  }
  document.querySelectorAll('input[placeholder]').forEach(function(input){
    input.addEventListener('input',function(){var q=input.value;var target=input.closest('.app-content')||input.closest('main')||document; 
      target.querySelectorAll('tbody tr, .price-card, .result-card, .buyer-card').forEach(function(el){el.style.display=!q||clean(el.textContent).indexOf(clean(q))>=0?'':'none';});
    });
  });

  // Animasi masuk yang ringan, tanpa mengubah urutan maupun isi elemen.
  var reveal=document.querySelectorAll('main h1, main .panel, main .stat-card, main .summary-main, main .price-card, main .feature-card, main .form-card, main .table-wrap, main .result-card');
  reveal.forEach(function(el){el.classList.add('th-reveal');});
  if('IntersectionObserver' in window){
    var observer=new IntersectionObserver(function(entries){entries.forEach(function(entry){if(entry.isIntersecting){entry.target.classList.add('th-visible');observer.unobserve(entry.target);}});},{threshold:.08});
    reveal.forEach(function(el){observer.observe(el);});
  }else reveal.forEach(function(el){el.classList.add('th-visible');});
})();


/* Animasi berulang khusus halaman dashboard */
(function () {
  var file = (location.pathname.split('/').pop() || '').toLowerCase();
  if (!/^(admin|petani|pembeli)-dashboard\.html$/.test(file)) return;
  document.body.classList.add('dashboard-motion');
})();
