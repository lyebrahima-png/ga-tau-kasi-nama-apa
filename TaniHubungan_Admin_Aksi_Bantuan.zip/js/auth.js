/* Autentikasi demo TaniHubungan - penyimpanan lokal browser */
(function(){
  'use strict';
  var msg=document.getElementById('auth-message');
  function show(text,error){msg.textContent=text;msg.classList.toggle('error',!!error);msg.style.display='block';}
  function getUsers(){try{return JSON.parse(localStorage.getItem('tanihubungan-users')||'[]');}catch(e){return [];}}
  function go(role){var file=role.toLowerCase()+'-dashboard.html';if(role==='Admin')file='admin-dashboard.html';location.href=file;}
  var login=document.getElementById('login-form');
  if(login)login.addEventListener('submit',function(e){
    e.preventDefault();var data=new FormData(login),email=String(data.get('email')).trim().toLowerCase(),password=String(data.get('password')),role=String(data.get('role'));
    var user=getUsers().find(function(u){return u.email===email&&u.password===password&&u.role===role;});
    if(!user){show('Email, kata sandi, atau peran tidak sesuai. Silakan daftar terlebih dahulu.',true);return;}
    localStorage.setItem('tanihubungan-session',JSON.stringify({name:user.name,email:user.email,role:user.role}));
    go(user.role);
  });
  var register=document.getElementById('register-form');
  if(register){
    var requestedRole=new URLSearchParams(window.location.search).get('role');
    var roleSelect=register.querySelector('[name="role"]');
    if(roleSelect && ['Petani','Pembeli'].includes(requestedRole)) roleSelect.value=requestedRole;
  }
  if(register)register.addEventListener('submit',function(e){
    e.preventDefault();var data=new FormData(register),name=String(data.get('name')).trim(),email=String(data.get('email')).trim().toLowerCase(),password=String(data.get('password')),role=String(data.get('role')),users=getUsers();
    if(users.some(function(u){return u.email===email;})){show('Email sudah terdaftar. Silakan masuk.',true);return;}
    users.push({name:name,email:email,password:password,role:role,createdAt:new Date().toISOString()});
    localStorage.setItem('tanihubungan-users',JSON.stringify(users));
    show('Pendaftaran berhasil. Anda akan diarahkan ke halaman masuk.');
    register.reset();setTimeout(function(){location.href='login.html';},1000);
  });
})();