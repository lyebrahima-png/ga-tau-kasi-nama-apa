/* Pintasan Asisten AI hanya untuk halaman setelah pengguna masuk. */
(function () {
  'use strict';
  var role = document.body && document.body.getAttribute('data-role');
  if (!['Petani', 'Pembeli', 'Admin'].includes(role)) return;
  if (document.querySelector('.th-ai-shortcut')) return;

  var style = document.createElement('style');
  style.textContent = `
    .th-ai-shortcut {
      position: fixed; right: 22px; bottom: 22px; z-index: 9999;
      display: flex; align-items: center; gap: 9px; padding: 12px 17px;
      border-radius: 999px; background: #286d43; color: #fff;
      text-decoration: none; font: 700 13px Arial, sans-serif;
      box-shadow: 0 8px 24px rgba(25,75,42,.25);
      transition: transform .2s, background .2s;
    }
    .th-ai-shortcut:hover { transform: translateY(-2px); background: #1f5936; }
    .th-ai-shortcut .th-ai-sparkle { font-size: 18px; }
    @media (max-width: 600px) {
      .th-ai-shortcut { right: 14px; bottom: 14px; padding: 11px 14px; }
    }
  `;
  document.head.appendChild(style);

  var link = document.createElement('a');
  link.className = 'th-ai-shortcut';
  link.href = 'ai-assistant.html';
  link.setAttribute('aria-label', 'Buka Asisten AI TaniHubungan');
  link.innerHTML = '<span class="th-ai-sparkle" aria-hidden="true">✦</span><span>Asisten AI</span>';
  document.body.appendChild(link);
})();
