# TaniHubungan + Google Gemini AI

## Fitur
- Halaman `ai-assistant.html` dengan antarmuka chat responsif.
- Asisten berbahasa Indonesia untuk budidaya, hama/penyakit, pupuk, panen, dan pemasaran.
- Backend Express meneruskan chat ke Gemini; API Key hanya disimpan di server melalui `.env`.
- Tombol pintas Asisten AI tersedia di halaman website.

## Menjalankan di komputer
1. Pastikan Node.js 18 atau lebih baru sudah terpasang.
2. Buka folder proyek melalui terminal.
3. Jalankan `npm install`.
4. Salin `.env.example` menjadi `.env`.
5. Isi `GEMINI_API_KEY` dengan API Key BARU dari Google AI Studio. Jangan gunakan key yang pernah dibagikan di chat.
6. Jalankan `npm start`.
7. Buka `http://localhost:3000` dan klik tombol **Asisten AI**, atau buka `http://localhost:3000/ai-assistant.html`.

## Deploy
Deploy sebagai aplikasi Node.js yang mendukung environment variables. Atur `GEMINI_API_KEY` dan (opsional) `GEMINI_MODEL` pada pengaturan environment di layanan hosting. Jangan unggah `.env` ke GitHub atau folder publik. Website statis saja tidak cukup untuk menyimpan key secara aman; endpoint `/api/chat` harus berjalan di server.

## Catatan keamanan
- API Key yang sudah pernah dikirim ke chat sebaiknya segera dihapus/revoke dari Google AI Studio dan diganti.
- Jangan menempelkan key ke HTML, CSS, atau JavaScript frontend.
- Tambahkan pembatasan penggunaan/rate limit dan autentikasi sebelum aplikasi dipakai publik dalam skala besar.

## Tentang model
Model default disetel ke `gemini-3.8-flash` mengikuti contoh dokumentasi Gemini yang tersedia saat pembuatan. Jika model tidak tersedia pada project/key Anda, ubah `GEMINI_MODEL` ke model Flash yang tersedia di Google AI Studio.
