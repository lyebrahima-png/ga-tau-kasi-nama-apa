import Link from 'next/link'
import { AuthForm } from '@/components/AuthForm'
import { Brand } from '@/components/SiteHeader'
import { registerAction } from '@/app/(frontend)/actions/auth'
import { CheckCircle } from '@/components/Icons'

export default function RegisterPage() {
  return (
    <main className="grid min-h-screen bg-stone-50 lg:grid-cols-[1.05fr_0.95fr]">
      <aside className="relative hidden overflow-hidden bg-slate-950 p-16 text-white lg:flex lg:flex-col lg:justify-between">
        <Brand inverse />
        <div className="absolute left-1/2 top-1/2 size-[30rem] -translate-x-1/2 -translate-y-1/2 rounded-full border border-white/10" />
        <div className="absolute left-1/2 top-1/2 size-80 -translate-x-1/2 -translate-y-1/2 rounded-full border border-white/10" />
        <div className="relative max-w-xl">
          <p className="text-sm font-bold uppercase tracking-[0.2em] text-amber-300">Bergabung dalam pemulihan</p>
          <h2 className="mt-5 text-5xl font-extrabold leading-tight tracking-tight">Setiap laporan dapat menjadi awal pertolongan.</h2>
          <div className="mt-10 grid gap-4 text-sm text-slate-300 sm:grid-cols-2">
            <p className="flex gap-3"><CheckCircle className="mt-0.5 size-5 shrink-0 text-emerald-300" /> Laporkan kebutuhan warga</p>
            <p className="flex gap-3"><CheckCircle className="mt-0.5 size-5 shrink-0 text-emerald-300" /> Daftar sebagai relawan</p>
            <p className="flex gap-3"><CheckCircle className="mt-0.5 size-5 shrink-0 text-emerald-300" /> Catat bantuan masuk</p>
            <p className="flex gap-3"><CheckCircle className="mt-0.5 size-5 shrink-0 text-emerald-300" /> Pantau progres wilayah</p>
          </div>
        </div>
        <p className="relative text-xs text-slate-500">PulihLangsa · Kota Langsa, Aceh</p>
      </aside>
      <section className="flex items-center justify-center px-5 py-12 sm:px-8">
        <div className="w-full max-w-md">
          <div className="lg:hidden"><Brand /></div>
          <div className="mt-10 lg:mt-0">
            <p className="text-sm font-bold uppercase tracking-[0.18em] text-emerald-700">Akun baru</p>
            <h1 className="mt-3 text-4xl font-extrabold tracking-tight">Buat akun PulihLangsa</h1>
            <p className="mt-3 leading-7 text-slate-600">Akun baru akan ditinjau sebelum memperoleh akses operasional penuh.</p>
          </div>
          <AuthForm action={registerAction} mode="register" />
          <Link href="/" className="mt-8 block text-center text-sm font-semibold text-slate-500 hover:text-slate-800">Kembali ke beranda</Link>
        </div>
      </section>
    </main>
  )
}
