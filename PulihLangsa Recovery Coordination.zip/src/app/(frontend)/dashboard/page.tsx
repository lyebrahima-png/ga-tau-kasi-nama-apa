import { redirect } from 'next/navigation'
import { appAuth } from '@/lib/app-auth'
import { getPayloadClient } from '@/lib/payload'
import { logoutAction } from '@/app/(frontend)/actions/auth'
import { Brand } from '@/components/SiteHeader'
import {
  BoxIcon,
  CheckCircle,
  ChevronRight,
  ClipboardIcon,
  ClockIcon,
  MapPinIcon,
  PackageCheck,
  TrendingUp,
  UsersIcon,
} from '@/components/Icons'

const labels: Record<string, string> = {
  admin: 'Admin',
  petugas: 'Petugas lapangan',
  user: 'Warga / Mitra',
  submitted: 'Menunggu verifikasi',
  verified: 'Terverifikasi',
  partial: 'Terpenuhi sebagian',
  fulfilled: 'Terpenuhi',
  rejected: 'Ditolak',
  planned: 'Direncanakan',
  in_transit: 'Dalam perjalanan',
  delivered: 'Disalurkan',
  issue: 'Bermasalah',
  in_progress: 'Berjalan',
  completed: 'Selesai',
  blocked: 'Tertunda',
  not_started: 'Belum dimulai',
}

const relationName = (
  value: unknown,
  fields: string[],
  fallback = 'Belum ditentukan',
) => {
  if (!value || typeof value !== 'object') return fallback
  for (const field of fields) {
    if (field in value && typeof (value as Record<string, unknown>)[field] === 'string') {
      return (value as Record<string, string>)[field]
    }
  }
  return fallback
}

const statusClass = (status?: string | null) => {
  if (['verified', 'fulfilled', 'delivered', 'completed'].includes(status ?? '')) {
    return 'bg-emerald-50 text-emerald-700'
  }
  if (['critical', 'issue', 'rejected', 'blocked'].includes(status ?? '')) {
    return 'bg-rose-50 text-rose-700'
  }
  return 'bg-amber-50 text-amber-700'
}

export default async function DashboardPage() {
  const user = await appAuth.currentUser()
  if (!user) redirect('/login')

  const payload = await getPayloadClient()
  const [needs, inventory, distributions, activities, volunteers, regions] =
    await Promise.all([
      payload.find({
        collection: 'community-needs',
        limit: 6,
        sort: '-createdAt',
        depth: 1,
        user,
        overrideAccess: false,
      }),
      payload.find({
        collection: 'aid-inventory',
        limit: 6,
        sort: 'quantityAvailable',
        depth: 1,
        user,
        overrideAccess: false,
      }),
      payload.find({
        collection: 'aid-distributions',
        limit: 5,
        sort: '-distributionDate',
        depth: 1,
        user,
        overrideAccess: false,
      }),
      payload.find({
        collection: 'recovery-activities',
        limit: 5,
        sort: '-activityDate',
        depth: 1,
        user,
        overrideAccess: false,
      }),
      payload.count({
        collection: 'volunteer-profiles',
        user,
        overrideAccess: false,
      }),
      payload.find({
        collection: 'affected-regions',
        limit: 5,
        sort: '-severity',
        depth: 1,
        user,
        overrideAccess: false,
      }),
    ])

  const verifiedNeeds = needs.docs.filter((need) => need.status === 'verified').length
  const delivered = distributions.docs.filter((item) => item.status === 'delivered').length
  const averageProgress = activities.docs.length
    ? Math.round(
        activities.docs.reduce((total, item) => total + item.progressPercent, 0) /
          activities.docs.length,
      )
    : 0

  const stats = [
    { label: 'Kebutuhan aktif', value: needs.totalDocs, detail: `${verifiedNeeds} terverifikasi`, icon: ClipboardIcon, color: 'bg-amber-50 text-amber-700' },
    { label: 'Distribusi', value: distributions.totalDocs, detail: `${delivered} sudah disalurkan`, icon: PackageCheck, color: 'bg-emerald-50 text-emerald-700' },
    { label: 'Relawan terdaftar', value: volunteers.totalDocs, detail: 'Siap dikoordinasikan', icon: UsersIcon, color: 'bg-sky-50 text-sky-700' },
    { label: 'Progres pemulihan', value: `${averageProgress}%`, detail: `${activities.totalDocs} kegiatan`, icon: TrendingUp, color: 'bg-violet-50 text-violet-700' },
  ]

  return (
    <main className="min-h-screen bg-slate-100">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-72 border-r border-slate-200 bg-white p-6 lg:flex lg:flex-col">
        <Brand />
        <nav className="mt-10 space-y-1 text-sm font-semibold">
          <a href="#ringkasan" className="flex items-center gap-3 rounded-xl bg-emerald-50 px-4 py-3 text-emerald-800"><TrendingUp className="size-5" /> Ringkasan</a>
          <a href="#kebutuhan" className="flex items-center gap-3 rounded-xl px-4 py-3 text-slate-500 transition hover:bg-slate-50 hover:text-slate-900"><ClipboardIcon className="size-5" /> Papan kebutuhan</a>
          <a href="#bantuan" className="flex items-center gap-3 rounded-xl px-4 py-3 text-slate-500 transition hover:bg-slate-50 hover:text-slate-900"><BoxIcon className="size-5" /> Bantuan & stok</a>
          <a href="#pemulihan" className="flex items-center gap-3 rounded-xl px-4 py-3 text-slate-500 transition hover:bg-slate-50 hover:text-slate-900"><MapPinIcon className="size-5" /> Peta & pemulihan</a>
        </nav>
        <div className="mt-auto rounded-2xl bg-slate-950 p-5 text-white">
          <p className="text-sm font-bold">{user.name}</p>
          <p className="mt-1 text-xs text-slate-400">{labels[user.role] ?? user.role}</p>
          <form action={logoutAction}>
            <button className="mt-4 w-full rounded-lg border border-white/15 px-3 py-2 text-xs font-bold transition hover:bg-white/10">Keluar</button>
          </form>
        </div>
      </aside>

      <div className="lg:pl-72">
        <header className="sticky top-0 z-20 border-b border-slate-200 bg-white/90 backdrop-blur">
          <div className="flex h-20 items-center justify-between px-5 sm:px-8">
            <div>
              <p className="text-sm text-slate-500">Dashboard koordinasi</p>
              <h1 className="font-bold text-slate-950">Selamat datang, {user.name?.split(' ')[0]}</h1>
            </div>
            <div className="flex items-center gap-3">
              <span className="hidden rounded-full bg-amber-50 px-3 py-1.5 text-xs font-bold text-amber-700 sm:block">
                {user.accountStatus === 'active' ? 'Akun aktif' : 'Menunggu verifikasi akun'}
              </span>
              <span className="grid size-10 place-items-center rounded-full bg-emerald-700 text-sm font-black text-white">
                {user.name?.slice(0, 2).toUpperCase()}
              </span>
            </div>
          </div>
        </header>

        <div className="mx-auto max-w-[1500px] space-y-8 px-5 py-8 sm:px-8">
          <section id="ringkasan">
            <div className="flex items-end justify-between gap-4">
              <div>
                <h2 className="text-2xl font-extrabold tracking-tight">Situasi terkini</h2>
                <p className="mt-1 text-sm text-slate-500">Ringkasan data koordinasi pemulihan yang dapat Anda akses.</p>
              </div>
              <span className="hidden items-center gap-2 text-xs font-semibold text-slate-500 sm:flex"><span className="size-2 rounded-full bg-emerald-500" /> Data langsung dari Payload</span>
            </div>
            <div className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
              {stats.map(({ label, value, detail, icon: StatIcon, color }) => (
                <article key={label} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                  <div className="flex items-start justify-between">
                    <span className={`grid size-11 place-items-center rounded-xl ${color}`}><StatIcon className="size-5" /></span>
                    <span className="text-3xl font-extrabold tracking-tight">{value}</span>
                  </div>
                  <h3 className="mt-5 text-sm font-bold">{label}</h3>
                  <p className="mt-1 text-xs text-slate-500">{detail}</p>
                </article>
              ))}
            </div>
          </section>

          <div className="grid gap-6 xl:grid-cols-[1.35fr_0.65fr]">
            <section id="kebutuhan" className="rounded-2xl border border-slate-200 bg-white shadow-sm">
              <div className="flex items-center justify-between border-b border-slate-100 px-6 py-5">
                <div>
                  <h2 className="font-extrabold">Papan kebutuhan terbaru</h2>
                  <p className="mt-1 text-xs text-slate-500">Laporan warga berdasarkan akses Anda</p>
                </div>
                <span className="rounded-lg bg-slate-100 px-3 py-2 text-xs font-bold text-slate-600">{needs.totalDocs} laporan</span>
              </div>
              <div className="divide-y divide-slate-100">
                {needs.docs.length ? needs.docs.map((need) => (
                  <article key={need.id} className="flex items-start gap-4 px-6 py-5">
                    <span className={`mt-1 size-2.5 shrink-0 rounded-full ${need.urgency === 'critical' ? 'bg-rose-500' : need.urgency === 'urgent' ? 'bg-amber-500' : 'bg-emerald-500'}`} />
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <h3 className="truncate text-sm font-bold">{need.title}</h3>
                        <span className={`rounded-full px-2.5 py-1 text-[11px] font-bold ${statusClass(need.status)}`}>{labels[need.status] ?? need.status}</span>
                      </div>
                      <p className="mt-2 flex items-center gap-1.5 text-xs text-slate-500"><MapPinIcon className="size-3.5" /> {relationName(need.region, ['regionName'])}</p>
                      <p className="mt-2 line-clamp-2 text-sm leading-6 text-slate-600">{need.details}</p>
                    </div>
                  </article>
                )) : (
                  <div className="px-6 py-14 text-center">
                    <ClipboardIcon className="mx-auto size-8 text-slate-300" />
                    <p className="mt-3 text-sm font-bold">Belum ada laporan kebutuhan</p>
                    <p className="mt-1 text-xs text-slate-500">Laporan baru akan muncul setelah diajukan.</p>
                  </div>
                )}
              </div>
            </section>

            <section id="bantuan" className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="font-extrabold">Ketersediaan bantuan</h2>
                  <p className="mt-1 text-xs text-slate-500">Stok per kategori</p>
                </div>
                <BoxIcon className="size-5 text-slate-400" />
              </div>
              <div className="mt-6 space-y-5">
                {inventory.docs.length ? inventory.docs.map((stock) => {
                  const low = stock.quantityAvailable <= stock.minimumStock
                  return (
                    <div key={stock.id}>
                      <div className="flex items-center justify-between text-sm">
                        <span className="font-semibold">{relationName(stock.category, ['categoryName'])}</span>
                        <span className={low ? 'font-bold text-rose-600' : 'font-bold text-slate-900'}>{stock.quantityAvailable}</span>
                      </div>
                      <div className="mt-2 h-2 overflow-hidden rounded-full bg-slate-100">
                        <div className={`h-full rounded-full ${low ? 'w-1/5 bg-rose-500' : 'w-4/5 bg-emerald-500'}`} />
                      </div>
                      <p className="mt-1 text-[11px] text-slate-400">{stock.storageLocation}</p>
                    </div>
                  )
                }) : (
                  <div className="rounded-xl bg-slate-50 p-6 text-center">
                    <p className="text-sm font-bold">Inventaris masih kosong</p>
                    <p className="mt-1 text-xs text-slate-500">Admin atau petugas dapat menambahkan stok melalui panel.</p>
                  </div>
                )}
              </div>
            </section>
          </div>

          <div id="pemulihan" className="grid gap-6 xl:grid-cols-[0.9fr_1.1fr]">
            <section className="overflow-hidden rounded-2xl border border-slate-200 bg-emerald-950 text-white shadow-sm">
              <div className="border-b border-white/10 px-6 py-5">
                <h2 className="font-extrabold">Wilayah terdampak</h2>
                <p className="mt-1 text-xs text-emerald-100/60">Titik koordinasi kegiatan pemulihan</p>
              </div>
              <div className="relative min-h-80 p-6">
                <div className="absolute inset-0 map-grid opacity-25" />
                <div className="relative space-y-3">
                  {regions.docs.length ? regions.docs.map((region, index) => (
                    <div key={region.id} className="flex items-center gap-4 rounded-xl border border-white/10 bg-white/10 p-4 backdrop-blur">
                      <span className={`grid size-10 shrink-0 place-items-center rounded-full ${index === 0 ? 'bg-amber-400 text-slate-950' : 'bg-emerald-700 text-white'}`}><MapPinIcon className="size-5" /></span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-bold">{region.regionName}</p>
                        <p className="mt-1 text-xs text-emerald-100/60">{region.district} · Dampak {region.severity}</p>
                      </div>
                      <ChevronRight className="size-4 text-white/50" />
                    </div>
                  )) : (
                    <div className="relative rounded-xl border border-dashed border-white/20 p-8 text-center">
                      <MapPinIcon className="mx-auto size-8 text-emerald-300" />
                      <p className="mt-3 text-sm font-bold">Belum ada wilayah dipetakan</p>
                    </div>
                  )}
                </div>
              </div>
            </section>

            <section className="rounded-2xl border border-slate-200 bg-white shadow-sm">
              <div className="flex items-center justify-between border-b border-slate-100 px-6 py-5">
                <div>
                  <h2 className="font-extrabold">Progres pemulihan</h2>
                  <p className="mt-1 text-xs text-slate-500">Perkembangan kegiatan lapangan</p>
                </div>
                <span className="text-xs font-bold text-emerald-700">{averageProgress}% rata-rata</span>
              </div>
              <div className="divide-y divide-slate-100">
                {activities.docs.length ? activities.docs.map((activity) => (
                  <article key={activity.id} className="px-6 py-5">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <h3 className="text-sm font-bold">{activity.activityName}</h3>
                        <p className="mt-1 text-xs text-slate-500">{relationName(activity.region, ['regionName'])}</p>
                      </div>
                      <span className={`rounded-full px-2.5 py-1 text-[11px] font-bold ${statusClass(activity.progressStatus)}`}>{labels[activity.progressStatus] ?? activity.progressStatus}</span>
                    </div>
                    <div className="mt-4 flex items-center gap-3">
                      <div className="h-2 flex-1 overflow-hidden rounded-full bg-slate-100">
                        <div className="h-full rounded-full bg-emerald-600" style={{ width: `${activity.progressPercent}%` }} />
                      </div>
                      <span className="text-xs font-black text-slate-700">{activity.progressPercent}%</span>
                    </div>
                  </article>
                )) : (
                  <div className="px-6 py-14 text-center">
                    <ClockIcon className="mx-auto size-8 text-slate-300" />
                    <p className="mt-3 text-sm font-bold">Belum ada kegiatan pemulihan</p>
                  </div>
                )}
              </div>
            </section>
          </div>

          <section className="rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div className="flex items-center justify-between border-b border-slate-100 px-6 py-5">
              <div>
                <h2 className="font-extrabold">Distribusi terbaru</h2>
                <p className="mt-1 text-xs text-slate-500">Riwayat penyaluran bantuan</p>
              </div>
              <CheckCircle className="size-5 text-emerald-600" />
            </div>
            {distributions.docs.length ? (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[720px] text-left text-sm">
                  <thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
                    <tr><th className="px-6 py-4">Referensi</th><th className="px-6 py-4">Wilayah</th><th className="px-6 py-4">Tanggal</th><th className="px-6 py-4">Status</th></tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {distributions.docs.map((distribution) => (
                      <tr key={distribution.id}>
                        <td className="px-6 py-4 font-bold">{distribution.referenceNumber}</td>
                        <td className="px-6 py-4 text-slate-600">{relationName(distribution.region, ['regionName'])}</td>
                        <td className="px-6 py-4 text-slate-600">{new Intl.DateTimeFormat('id-ID', { dateStyle: 'medium' }).format(new Date(distribution.distributionDate))}</td>
                        <td className="px-6 py-4"><span className={`rounded-full px-2.5 py-1 text-[11px] font-bold ${statusClass(distribution.status)}`}>{labels[distribution.status] ?? distribution.status}</span></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="px-6 py-12 text-center text-sm text-slate-500">Belum ada distribusi yang dicatat.</div>
            )}
          </section>
        </div>
      </div>
    </main>
  )
}
