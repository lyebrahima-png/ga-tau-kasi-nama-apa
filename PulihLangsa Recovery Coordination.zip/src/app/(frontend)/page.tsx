import Image from 'next/image'
import Link from 'next/link'
import { ArrowUpRight, CheckCircle, ClipboardIcon, MapPinIcon, PackageCheck, ShieldCheck, UsersIcon } from '@/components/Icons'
import { Brand, SiteHeader } from '@/components/SiteHeader'

export default function HomePage() {
  return (
    <main className="overflow-hidden bg-stone-50 text-slate-950">
      <section className="relative min-h-[760px] bg-slate-950">
        <Image
          src="https://images.unsplash.com/photo-1741110539426-fce3268c3c0d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixlib=rb-4.1.0&q=85&w=1800"
          alt="Warga berkumpul di area terdampak banjir"
          fill
          priority
          sizes="100vw"
          className="object-cover opacity-50"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/85 to-slate-950/20" />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent" />
        <SiteHeader />
        <div className="relative z-10 mx-auto flex min-h-[760px] max-w-7xl items-center px-5 pb-20 pt-32 sm:px-8">
          <div className="max-w-3xl">
            <div className="mb-7 inline-flex items-center gap-2 rounded-full border border-emerald-300/30 bg-emerald-300/10 px-4 py-2 text-sm font-semibold text-emerald-100 backdrop-blur">
              <span className="size-2 rounded-full bg-emerald-300" />
              Koordinasi pemulihan pascabencana Kota Langsa
            </div>
            <h1 className="text-balance text-5xl font-extrabold leading-[1.05] tracking-tight text-white sm:text-6xl lg:text-7xl">
              Pulih bersama,<br />
              <span className="text-amber-300">lebih terarah.</span>
            </h1>
            <p className="mt-7 max-w-2xl text-lg leading-8 text-slate-200 sm:text-xl">
              Menghubungkan kebutuhan warga terdampak dengan bantuan, relawan, dan aksi pemulihan yang terverifikasi—dalam satu koordinasi terbuka.
            </p>
            <div className="mt-10 flex flex-col gap-3 sm:flex-row">
              <Link href="/register" className="inline-flex items-center justify-center gap-2 rounded-xl bg-amber-400 px-6 py-4 font-bold text-slate-950 shadow-xl shadow-black/20 transition hover:bg-amber-300">
                Laporkan kebutuhan <ArrowUpRight className="size-5" />
              </Link>
              <Link href="/dashboard" className="inline-flex items-center justify-center rounded-xl border border-white/25 bg-white/10 px-6 py-4 font-bold text-white backdrop-blur transition hover:bg-white/15">
                Lihat progres pemulihan
              </Link>
            </div>
            <div className="mt-12 flex flex-wrap gap-x-8 gap-y-3 text-sm text-slate-300">
              <span className="flex items-center gap-2"><CheckCircle className="size-4 text-emerald-300" /> Data terverifikasi</span>
              <span className="flex items-center gap-2"><CheckCircle className="size-4 text-emerald-300" /> Stok terpantau</span>
              <span className="flex items-center gap-2"><CheckCircle className="size-4 text-emerald-300" /> Distribusi terdokumentasi</span>
            </div>
          </div>
        </div>
      </section>

      <section id="fitur" className="mx-auto max-w-7xl px-5 py-24 sm:px-8">
        <div className="max-w-2xl">
          <p className="text-sm font-bold uppercase tracking-[0.2em] text-emerald-700">Satu ruang koordinasi</p>
          <h2 className="mt-4 text-4xl font-extrabold tracking-tight sm:text-5xl">Bantuan tepat, progres terlihat.</h2>
          <p className="mt-5 text-lg leading-8 text-slate-600">PulihLangsa tidak menggantikan pendataan kebencanaan. Platform ini melanjutkan pekerjaan setelah data tersedia: mengoordinasikan pemulihan masyarakat.</p>
        </div>
        <div className="mt-14 grid gap-5 lg:grid-cols-3">
          {[
            { icon: ClipboardIcon, number: '01', title: 'Papan kebutuhan', copy: 'Kebutuhan warga dan lokasi terdampak diverifikasi sebelum tampil, sehingga relawan bergerak berdasarkan informasi yang dapat dipercaya.' },
            { icon: PackageCheck, number: '02', title: 'Manajemen bantuan', copy: 'Bantuan masuk, stok gudang, penyalur, dan status distribusi tercatat utuh untuk mencegah tumpang tindih.' },
            { icon: MapPinIcon, number: '03', title: 'Peta & progres', copy: 'Aktivitas pemulihan dipetakan per wilayah dengan perkembangan yang mudah dipantau oleh seluruh pihak.' },
          ].map(({ icon: FeatureIcon, number, title, copy }) => (
            <article key={number} className="group rounded-3xl border border-slate-200 bg-white p-8 shadow-sm transition hover:-translate-y-1 hover:shadow-xl hover:shadow-slate-200/60">
              <div className="flex items-center justify-between">
                <span className="grid size-14 place-items-center rounded-2xl bg-emerald-50 text-emerald-700"><FeatureIcon className="size-7" /></span>
                <span className="font-mono text-sm font-bold text-slate-300">{number}</span>
              </div>
              <h3 className="mt-8 text-2xl font-bold">{title}</h3>
              <p className="mt-4 leading-7 text-slate-600">{copy}</p>
            </article>
          ))}
        </div>
      </section>

      <section id="cara-kerja" className="bg-emerald-950 py-24 text-white">
        <div className="mx-auto grid max-w-7xl gap-16 px-5 sm:px-8 lg:grid-cols-[0.85fr_1.15fr] lg:items-center">
          <div>
            <p className="text-sm font-bold uppercase tracking-[0.2em] text-emerald-300">Cara kerja</p>
            <h2 className="mt-4 text-4xl font-extrabold tracking-tight sm:text-5xl">Dari laporan menjadi aksi nyata.</h2>
            <p className="mt-6 text-lg leading-8 text-emerald-100/75">Setiap langkah meninggalkan jejak yang jelas—siapa yang memverifikasi, apa yang disalurkan, dan seberapa jauh pemulihan berjalan.</p>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            {[
              ['1', 'Warga melapor', 'Kebutuhan diajukan dengan lokasi, kategori, jumlah, dan tingkat urgensi.'],
              ['2', 'Petugas memverifikasi', 'Laporan diperiksa agar bantuan ditujukan pada kebutuhan yang valid.'],
              ['3', 'Bantuan ditugaskan', 'Stok dan relawan dicocokkan dengan wilayah serta kebutuhan prioritas.'],
              ['4', 'Progres diperbarui', 'Penyaluran dan kegiatan pemulihan dicatat dengan bukti lapangan.'],
            ].map(([step, title, copy]) => (
              <div key={step} className="rounded-2xl border border-white/10 bg-white/5 p-6">
                <span className="text-sm font-black text-amber-300">{step}</span>
                <h3 className="mt-3 text-lg font-bold">{title}</h3>
                <p className="mt-2 text-sm leading-6 text-emerald-100/70">{copy}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="transparansi" className="mx-auto max-w-7xl px-5 py-24 sm:px-8">
        <div className="rounded-[2rem] bg-amber-50 p-8 sm:p-12 lg:flex lg:items-center lg:justify-between lg:gap-16">
          <div className="max-w-2xl">
            <span className="grid size-14 place-items-center rounded-2xl bg-amber-400 text-slate-950"><ShieldCheck className="size-7" /></span>
            <h2 className="mt-6 text-3xl font-extrabold tracking-tight sm:text-4xl">Transparansi sejak bantuan masuk.</h2>
            <p className="mt-4 text-lg leading-8 text-slate-600">Sistem menjaga distribusi tidak melebihi stok, mencatat penanggung jawab, dan menyimpan dokumentasi penyaluran dalam satu alur.</p>
          </div>
          <div className="mt-8 grid grid-cols-2 gap-3 lg:mt-0 lg:min-w-[22rem]">
            <div className="rounded-2xl bg-white p-5"><UsersIcon className="size-6 text-emerald-700" /><p className="mt-5 text-sm font-bold">Berbasis peran</p></div>
            <div className="rounded-2xl bg-white p-5"><ShieldCheck className="size-6 text-emerald-700" /><p className="mt-5 text-sm font-bold">Terverifikasi</p></div>
            <div className="col-span-2 rounded-2xl bg-slate-950 p-5 text-white"><p className="text-sm font-bold">Siap bergerak bersama?</p><Link href="/register" className="mt-3 inline-flex items-center gap-2 text-sm font-bold text-amber-300">Buat akun PulihLangsa <ArrowUpRight className="size-4" /></Link></div>
          </div>
        </div>
      </section>

      <footer className="border-t border-slate-200 bg-white">
        <div className="mx-auto flex max-w-7xl flex-col gap-6 px-5 py-10 sm:px-8 md:flex-row md:items-center md:justify-between">
          <Brand />
          <p className="text-sm text-slate-500">Koordinasi pemulihan masyarakat Kota Langsa.</p>
        </div>
      </footer>
    </main>
  )
}
