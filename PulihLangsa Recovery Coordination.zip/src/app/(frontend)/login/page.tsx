import Link from 'next/link'
import { AuthForm } from '@/components/AuthForm'
import { Brand } from '@/components/SiteHeader'
import { loginAction } from '@/app/(frontend)/actions/auth'
import { CheckCircle } from '@/components/Icons'

export default function LoginPage() {
  return (
    <main className="grid min-h-screen bg-stone-50 lg:grid-cols-[0.9fr_1.1fr]">
      <section className="flex items-center justify-center px-5 py-12 sm:px-8">
        <div className="w-full max-w-md">
          <Brand />
          <div className="mt-14">
            <p className="text-sm font-bold uppercase tracking-[0.18em] text-emerald-700">Selamat datang kembali</p>
            <h1 className="mt-3 text-4xl font-extrabold tracking-tight">Masuk ke PulihLangsa</h1>
            <p className="mt-3 leading-7 text-slate-600">Pantau laporan, penyaluran, dan progres pemulihan dari satu dashboard.</p>
          </div>
          <AuthForm action={loginAction} mode="login" />
          <Link href="/" className="mt-8 block text-center text-sm font-semibold text-slate-500 hover:text-slate-800">Kembali ke beranda</Link>
        </div>
      </section>
      <aside className="relative hidden overflow-hidden bg-emerald-950 p-16 text-white lg:flex lg:flex-col lg:justify-end">
        <div className="absolute -right-20 -top-20 size-96 rounded-full border border-white/10" />
        <div className="absolute -right-4 -top-4 size-56 rounded-full border border-white/10" />
        <div className="relative max-w-xl">
          <p className="text-3xl font-bold leading-tight">“Pemulihan bukan pekerjaan satu pihak. Ia dimulai ketika kebutuhan yang benar bertemu bantuan yang tepat.”</p>
          <div className="mt-10 space-y-3 text-sm text-emerald-100/80">
            <p className="flex items-center gap-3"><CheckCircle className="size-5 text-amber-300" /> Akses sesuai peran pengguna</p>
            <p className="flex items-center gap-3"><CheckCircle className="size-5 text-amber-300" /> Data operasional tersimpan aman</p>
            <p className="flex items-center gap-3"><CheckCircle className="size-5 text-amber-300" /> Distribusi tercatat dan terlacak</p>
          </div>
        </div>
      </aside>
    </main>
  )
}
