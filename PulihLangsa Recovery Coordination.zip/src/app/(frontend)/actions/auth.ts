'use server'

import { redirect } from 'next/navigation'
import { appAuth } from '@/lib/app-auth'

export type AuthState = { error?: string }

const field = (formData: FormData, name: string) => {
  const value = formData.get(name)
  return typeof value === 'string' ? value.trim() : ''
}

export async function loginAction(
  _state: AuthState,
  formData: FormData,
): Promise<AuthState> {
  const email = field(formData, 'email').toLowerCase()
  const password = field(formData, 'password')

  if (!email || !password) return { error: 'Lengkapi email dan kata sandi.' }

  try {
    await appAuth.login(email, password)
  } catch {
    return { error: 'Email atau kata sandi tidak valid.' }
  }
  redirect('/dashboard')
}

export async function registerAction(
  _state: AuthState,
  formData: FormData,
): Promise<AuthState> {
  const name = field(formData, 'name')
  const email = field(formData, 'email').toLowerCase()
  const phone = field(formData, 'phone')
  const password = field(formData, 'password')

  if (name.length < 3) return { error: 'Nama harus terdiri dari minimal 3 karakter.' }
  if (!email.includes('@')) return { error: 'Masukkan alamat email yang valid.' }
  if (password.length < 8) return { error: 'Kata sandi minimal 8 karakter.' }

  try {
    await appAuth.register({ name, email, phone: phone || undefined, password })
  } catch {
    return { error: 'Akun tidak dapat dibuat. Email mungkin sudah digunakan.' }
  }
  redirect('/dashboard')
}

export async function logoutAction() {
  await appAuth.logout()
  redirect('/')
}
