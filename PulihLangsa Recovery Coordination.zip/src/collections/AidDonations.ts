import type { CollectionConfig } from 'payload'
import { hasAppRole, isCMSAdmin, userID } from './access'

export const AidDonations: CollectionConfig = {
  slug: 'aid-donations',
  admin: {
    group: 'Bantuan',
    useAsTitle: 'donorName',
    defaultColumns: ['donorName', 'category', 'quantity', 'donationDate', 'status'],
  },
  access: {
    create: ({ req }) => Boolean(req.user?.collection === 'users' || isCMSAdmin(req.user)),
    delete: ({ req }) => isCMSAdmin(req.user) || hasAppRole(req.user, ['admin']),
    read: ({ req }) => {
      if (isCMSAdmin(req.user) || hasAppRole(req.user, ['admin', 'petugas'])) return true
      const id = userID(req.user)
      return id ? { donor: { equals: id } } : false
    },
    update: ({ req }) =>
      isCMSAdmin(req.user) || hasAppRole(req.user, ['admin', 'petugas']),
  },
  hooks: {
    beforeChange: [
      ({ data, req, operation }) =>
        operation === 'create' && req.user?.collection === 'users'
          ? { ...data, donor: req.user.id, status: 'recorded' }
          : data,
    ],
  },
  fields: [
    { name: 'donor', type: 'relationship', relationTo: 'users' },
    { name: 'donorName', type: 'text', required: true, maxLength: 120 },
    { name: 'event', type: 'relationship', relationTo: 'disaster-events', required: true },
    { name: 'category', type: 'relationship', relationTo: 'aid-categories', required: true },
    { name: 'quantity', type: 'number', required: true, min: 1 },
    { name: 'donationDate', type: 'date', required: true },
    {
      name: 'status',
      type: 'select',
      required: true,
      defaultValue: 'recorded',
      options: [
        { label: 'Tercatat', value: 'recorded' },
        { label: 'Diterima', value: 'received' },
        { label: 'Ditolak', value: 'rejected' },
      ],
    },
  ],
}
