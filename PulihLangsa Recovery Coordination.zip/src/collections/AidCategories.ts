import type { CollectionConfig } from 'payload'
import { isAdmin } from './access'

export const AidCategories: CollectionConfig = {
  slug: 'aid-categories',
  admin: {
    group: 'Bantuan',
    useAsTitle: 'categoryName',
  },
  access: {
    create: isAdmin,
    delete: isAdmin,
    read: () => true,
    update: isAdmin,
  },
  fields: [
    { name: 'categoryName', type: 'text', required: true, unique: true, maxLength: 100 },
    { name: 'unit', type: 'text', required: true, maxLength: 40 },
    {
      name: 'icon',
      type: 'select',
      required: true,
      defaultValue: 'package',
      options: ['package', 'food', 'water', 'health', 'shelter', 'tools'],
    },
  ],
}
