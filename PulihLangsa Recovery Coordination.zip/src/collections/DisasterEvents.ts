import type { CollectionConfig } from 'payload'
import { isAdmin } from './access'

export const DisasterEvents: CollectionConfig = {
  slug: 'disaster-events',
  admin: {
    group: 'Kejadian & Wilayah',
    useAsTitle: 'eventName',
    defaultColumns: ['eventName', 'disasterType', 'startDate', 'status'],
  },
  access: {
    create: isAdmin,
    delete: isAdmin,
    read: () => true,
    update: isAdmin,
  },
  fields: [
    { name: 'eventName', type: 'text', required: true, maxLength: 140 },
    {
      name: 'disasterType',
      type: 'select',
      required: true,
      options: [
        { label: 'Banjir', value: 'banjir' },
        { label: 'Longsor', value: 'longsor' },
        { label: 'Gempa', value: 'gempa' },
        { label: 'Kebakaran', value: 'kebakaran' },
        { label: 'Lainnya', value: 'lainnya' },
      ],
    },
    { name: 'startDate', type: 'date', required: true },
    {
      name: 'status',
      type: 'select',
      required: true,
      defaultValue: 'active',
      options: [
        { label: 'Tanggap', value: 'active' },
        { label: 'Pemulihan', value: 'recovery' },
        { label: 'Selesai', value: 'closed' },
      ],
    },
    { name: 'summary', type: 'textarea', required: true, maxLength: 800 },
  ],
}
