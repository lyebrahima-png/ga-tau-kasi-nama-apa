import type { CollectionConfig } from 'payload'
import { adminFieldAccess, isAdmin, isCMSAdmin, userID } from './access'

export const Users: CollectionConfig = {
  slug: 'users',
  auth: {
    tokenExpiration: 60 * 60 * 24 * 7,
  },
  admin: {
    group: 'Akses & Relawan',
    useAsTitle: 'name',
  },
  access: {
    admin: ({ req }) => isCMSAdmin(req.user),
    create: () => true,
    delete: isAdmin,
    read: ({ req }) => {
      if (isCMSAdmin(req.user) || (req.user?.collection === 'users' && req.user.role === 'admin')) {
        return true
      }
      const id = userID(req.user)
      return id ? { id: { equals: id } } : false
    },
    update: ({ req }) => {
      if (isCMSAdmin(req.user) || (req.user?.collection === 'users' && req.user.role === 'admin')) {
        return true
      }
      const id = userID(req.user)
      return id ? { id: { equals: id } } : false
    },
  },
  fields: [
    {
      name: 'name',
      type: 'text',
      required: true,
      maxLength: 100,
    },
    {
      name: 'role',
      type: 'select',
      required: true,
      defaultValue: 'user',
      options: [
        { label: 'Warga / Mitra', value: 'user' },
        { label: 'Petugas', value: 'petugas' },
        { label: 'Admin', value: 'admin' },
      ],
      access: {
        create: adminFieldAccess,
        update: adminFieldAccess,
      },
    },
    {
      name: 'accountStatus',
      type: 'select',
      required: true,
      defaultValue: 'pending',
      options: [
        { label: 'Menunggu verifikasi', value: 'pending' },
        { label: 'Aktif', value: 'active' },
        { label: 'Ditangguhkan', value: 'suspended' },
      ],
      access: {
        create: adminFieldAccess,
        update: adminFieldAccess,
      },
    },
    {
      name: 'phone',
      type: 'text',
      maxLength: 24,
    },
    {
      name: 'organization',
      type: 'text',
      maxLength: 120,
    },
  ],
}
