import type { CollectionConfig } from 'payload'
import { isStaff } from './access'

export const RecoveryActivities: CollectionConfig = {
  slug: 'recovery-activities',
  admin: {
    group: 'Distribusi & Pemulihan',
    useAsTitle: 'activityName',
    defaultColumns: ['activityName', 'region', 'progressStatus', 'progressPercent'],
  },
  access: {
    create: isStaff,
    delete: isStaff,
    read: () => true,
    update: isStaff,
  },
  fields: [
    { name: 'event', type: 'relationship', relationTo: 'disaster-events', required: true },
    { name: 'region', type: 'relationship', relationTo: 'affected-regions', required: true },
    { name: 'activityName', type: 'text', required: true, maxLength: 140 },
    { name: 'description', type: 'textarea', required: true, maxLength: 1000 },
    {
      name: 'progressStatus',
      type: 'select',
      required: true,
      options: [
        { label: 'Belum dimulai', value: 'not_started' },
        { label: 'Berjalan', value: 'in_progress' },
        { label: 'Selesai', value: 'completed' },
        { label: 'Tertunda', value: 'blocked' },
      ],
    },
    { name: 'progressPercent', type: 'number', required: true, min: 0, max: 100 },
    { name: 'activityDate', type: 'date', required: true },
    { name: 'documentation', type: 'upload', relationTo: 'media' },
  ],
}
