import type { CollectionConfig } from 'payload'
import { hasAppRole, isCMSAdmin, staffFieldAccess, userID } from './access'

export const CommunityNeeds: CollectionConfig = {
  slug: 'community-needs',
  admin: {
    group: 'Kebutuhan',
    useAsTitle: 'title',
    defaultColumns: ['title', 'region', 'needCategory', 'quantity', 'status'],
  },
  access: {
    create: ({ req }) =>
      Boolean(req.user?.collection === 'users' || isCMSAdmin(req.user)),
    delete: ({ req }) => isCMSAdmin(req.user) || hasAppRole(req.user, ['admin']),
    read: ({ req }) => {
      if (isCMSAdmin(req.user) || hasAppRole(req.user, ['admin', 'petugas'])) return true
      const id = userID(req.user)
      return id
        ? { or: [{ status: { equals: 'verified' } }, { requester: { equals: id } }] }
        : { status: { equals: 'verified' } }
    },
    update: ({ req }) => {
      if (isCMSAdmin(req.user) || hasAppRole(req.user, ['admin', 'petugas'])) return true
      const id = userID(req.user)
      return id
        ? { and: [{ requester: { equals: id } }, { status: { equals: 'submitted' } }] }
        : false
    },
  },
  hooks: {
    beforeChange: [
      ({ data, req, operation }) => {
        if (operation === 'create' && req.user?.collection === 'users') {
          return { ...data, requester: req.user.id, status: 'submitted' }
        }
        return data
      },
    ],
  },
  fields: [
    { name: 'event', type: 'relationship', relationTo: 'disaster-events', required: true },
    { name: 'requester', type: 'relationship', relationTo: 'users', required: true },
    { name: 'region', type: 'relationship', relationTo: 'affected-regions', required: true },
    { name: 'title', type: 'text', required: true, maxLength: 140 },
    { name: 'needCategory', type: 'relationship', relationTo: 'aid-categories', required: true },
    { name: 'quantity', type: 'number', required: true, min: 1 },
    { name: 'details', type: 'textarea', required: true, maxLength: 1000 },
    {
      name: 'urgency',
      type: 'select',
      required: true,
      options: [
        { label: 'Normal', value: 'normal' },
        { label: 'Mendesak', value: 'urgent' },
        { label: 'Kritis', value: 'critical' },
      ],
    },
    {
      name: 'status',
      type: 'select',
      required: true,
      defaultValue: 'submitted',
      options: [
        { label: 'Diajukan', value: 'submitted' },
        { label: 'Terverifikasi', value: 'verified' },
        { label: 'Dipenuhi sebagian', value: 'partial' },
        { label: 'Terpenuhi', value: 'fulfilled' },
        { label: 'Ditolak', value: 'rejected' },
      ],
      access: { create: staffFieldAccess, update: staffFieldAccess },
    },
  ],
}
