import type { CollectionConfig } from 'payload'
import { hasAppRole, isCMSAdmin, userID } from './access'

export const VolunteerProfiles: CollectionConfig = {
  slug: 'volunteer-profiles',
  admin: { group: 'Akses & Relawan', useAsTitle: 'displayName' },
  access: {
    create: ({ req }) => Boolean(req.user?.collection === 'users' || isCMSAdmin(req.user)),
    delete: ({ req }) => isCMSAdmin(req.user) || hasAppRole(req.user, ['admin']),
    read: ({ req }) => {
      if (isCMSAdmin(req.user) || hasAppRole(req.user, ['admin', 'petugas'])) return true
      const id = userID(req.user)
      return id ? { user: { equals: id } } : false
    },
    update: ({ req }) => {
      if (isCMSAdmin(req.user) || hasAppRole(req.user, ['admin', 'petugas'])) return true
      const id = userID(req.user)
      return id ? { user: { equals: id } } : false
    },
  },
  hooks: {
    beforeChange: [
      ({ data, req, operation }) =>
        operation === 'create' && req.user?.collection === 'users'
          ? { ...data, user: req.user.id, displayName: req.user.name }
          : data,
    ],
  },
  fields: [
    { name: 'user', type: 'relationship', relationTo: 'users', required: true, unique: true },
    { name: 'displayName', type: 'text', required: true, maxLength: 100 },
    { name: 'skills', type: 'text', hasMany: true, required: true },
    {
      name: 'availability',
      type: 'select',
      required: true,
      options: [
        { label: 'Tersedia', value: 'available' },
        { label: 'Terbatas', value: 'limited' },
        { label: 'Tidak tersedia', value: 'unavailable' },
      ],
    },
    { name: 'assignedRegion', type: 'relationship', relationTo: 'affected-regions' },
  ],
}
