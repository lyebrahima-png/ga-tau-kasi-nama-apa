import type { CollectionBeforeChangeHook, CollectionConfig } from 'payload'
import { hasAppRole, isCMSAdmin } from './access'

const relationshipID = (value: unknown): number | string =>
  typeof value === 'object' && value && 'id' in value
    ? (value.id as number | string)
    : (value as number | string)

const reserveInventory: CollectionBeforeChangeHook = async ({
  data,
  operation,
  originalDoc,
  req,
}) => {
  const becomingDelivered =
    data.status === 'delivered' &&
    (operation === 'create' || originalDoc?.status !== 'delivered')

  if (!becomingDelivered) return data

  const eventID = relationshipID(data.event)
  const items = Array.isArray(data.items) ? data.items : []

  for (const item of items) {
    const categoryID = relationshipID(item.category)
    const requested = Number(item.quantity)
    const inventory = await req.payload.find({
      collection: 'aid-inventory',
      where: {
        and: [
          { event: { equals: eventID } },
          { category: { equals: categoryID } },
        ],
      },
      limit: 1,
      overrideAccess: true,
      req,
    })
    const stock = inventory.docs[0]
    if (!stock || stock.quantityAvailable < requested) {
      throw new Error('Jumlah bantuan yang disalurkan melebihi stok tersedia.')
    }

    const updated = await req.payload.update({
      collection: 'aid-inventory',
      where: {
        and: [
          { id: { equals: stock.id } },
          { updatedAt: { equals: stock.updatedAt } },
          { quantityAvailable: { greater_than_equal: requested } },
        ],
      },
      data: { quantityAvailable: stock.quantityAvailable - requested },
      limit: 1,
      overrideAccess: true,
      req,
    })
    if (updated.docs.length !== 1) {
      throw new Error('Stok berubah saat distribusi diproses. Silakan coba kembali.')
    }
  }

  return data
}

export const AidDistributions: CollectionConfig = {
  slug: 'aid-distributions',
  admin: {
    group: 'Distribusi & Pemulihan',
    useAsTitle: 'referenceNumber',
    defaultColumns: ['referenceNumber', 'region', 'distributionDate', 'status'],
  },
  access: {
    create: ({ req }) => isCMSAdmin(req.user) || hasAppRole(req.user, ['admin', 'petugas']),
    delete: ({ req }) => isCMSAdmin(req.user) || hasAppRole(req.user, ['admin']),
    read: () => true,
    update: ({ req }) => isCMSAdmin(req.user) || hasAppRole(req.user, ['admin', 'petugas']),
  },
  hooks: {
    beforeChange: [reserveInventory],
  },
  fields: [
    { name: 'referenceNumber', type: 'text', required: true, unique: true, maxLength: 40 },
    { name: 'event', type: 'relationship', relationTo: 'disaster-events', required: true },
    { name: 'region', type: 'relationship', relationTo: 'affected-regions', required: true },
    { name: 'staff', type: 'relationship', relationTo: 'users', required: true },
    { name: 'distributionDate', type: 'date', required: true },
    {
      name: 'status',
      type: 'select',
      required: true,
      defaultValue: 'planned',
      options: [
        { label: 'Direncanakan', value: 'planned' },
        { label: 'Dalam perjalanan', value: 'in_transit' },
        { label: 'Disalurkan', value: 'delivered' },
        { label: 'Bermasalah', value: 'issue' },
      ],
    },
    {
      name: 'items',
      type: 'array',
      required: true,
      minRows: 1,
      fields: [
        { name: 'category', type: 'relationship', relationTo: 'aid-categories', required: true },
        { name: 'quantity', type: 'number', required: true, min: 1 },
      ],
    },
    { name: 'documentation', type: 'upload', relationTo: 'media' },
    { name: 'notes', type: 'textarea', maxLength: 1000 },
  ],
}
