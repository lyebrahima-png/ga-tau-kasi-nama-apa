import type { CollectionConfig } from 'payload'
import { isStaff } from './access'

export const AffectedRegions: CollectionConfig = {
  slug: 'affected-regions',
  admin: {
    group: 'Kejadian & Wilayah',
    useAsTitle: 'regionName',
    defaultColumns: ['regionName', 'district', 'event', 'severity'],
  },
  access: {
    create: isStaff,
    delete: isStaff,
    read: () => true,
    update: isStaff,
  },
  fields: [
    { name: 'event', type: 'relationship', relationTo: 'disaster-events', required: true },
    { name: 'regionName', type: 'text', required: true, maxLength: 120 },
    { name: 'district', type: 'text', required: true, maxLength: 120 },
    { name: 'description', type: 'textarea', required: true, maxLength: 600 },
    {
      name: 'severity',
      type: 'select',
      required: true,
      options: [
        { label: 'Rendah', value: 'low' },
        { label: 'Sedang', value: 'medium' },
        { label: 'Tinggi', value: 'high' },
      ],
    },
    { name: 'latitude', type: 'number', min: -90, max: 90 },
    { name: 'longitude', type: 'number', min: -180, max: 180 },
  ],
}
