import type { Access, FieldAccess } from 'payload'

type AppRole = 'admin' | 'petugas' | 'user'

export const isCMSAdmin = (user: unknown): boolean =>
  Boolean(
    user &&
      typeof user === 'object' &&
      'collection' in user &&
      user.collection === 'admins',
  )

export const hasAppRole = (user: unknown, roles: AppRole[]): boolean =>
  Boolean(
    user &&
      typeof user === 'object' &&
      'collection' in user &&
      user.collection === 'users' &&
      'role' in user &&
      roles.includes(user.role as AppRole),
  )

export const isAdmin: Access = ({ req }) =>
  isCMSAdmin(req.user) || hasAppRole(req.user, ['admin'])

export const isStaff: Access = ({ req }) =>
  isCMSAdmin(req.user) || hasAppRole(req.user, ['admin', 'petugas'])

export const isAuthenticated: Access = ({ req }) =>
  isCMSAdmin(req.user) ||
  Boolean(req.user && 'collection' in req.user && req.user.collection === 'users')

export const staffFieldAccess: FieldAccess = ({ req }) =>
  isCMSAdmin(req.user) || hasAppRole(req.user, ['admin', 'petugas'])

export const adminFieldAccess: FieldAccess = ({ req }) =>
  isCMSAdmin(req.user) || hasAppRole(req.user, ['admin'])

export const userID = (user: unknown): number | string | null => {
  if (
    user &&
    typeof user === 'object' &&
    'collection' in user &&
    user.collection === 'users' &&
    'id' in user
  ) {
    return user.id as number | string
  }
  return null
}
