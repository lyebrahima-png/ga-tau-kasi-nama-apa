import type { CollectionConfig } from 'payload'
import { isStaff } from './access'

export const AidInventory: CollectionConfig = {
  slug: 'aid-inventory',
  admin: {
    group: 'Bantuan',
    useAsTitle: 'storageLocation',
    defaultColumns: ['event', 'category', 'quantityAvailable', 'storageLocation'],
  },
  access: {
    create: isStaff,
    delete: isStaff,
    read: () => true,
    update: isStaff,
  },
  fields: [
    { name: 'event', type: 'relationship', relationTo: 'disaster-events', required: true },
    { name: 'category', type: 'relationship', relationTo: 'aid-categories', required: true },
    { name: 'quantityAvailable', type: 'number', required: true, min: 0 },
    { name: 'storageLocation', type: 'text', required: true, maxLength: 160 },
    { name: 'minimumStock', type: 'number', required: true, defaultValue: 0, min: 0 },
  ],
}
