import type { CollectionConfig } from 'payload'
import { isStaff } from './access'

export const NeedVerifications: CollectionConfig = {
  slug: 'need-verifications',
  admin: { group: 'Kebutuhan', useAsTitle: 'verificationStatus' },
  access: {
    create: isStaff,
    delete: isStaff,
    read: isStaff,
    update: isStaff,
  },
  fields: [
    { name: 'need', type: 'relationship', relationTo: 'community-needs', required: true },
    { name: 'staff', type: 'relationship', relationTo: 'users', required: true },
    {
      name: 'verificationStatus',
      type: 'select',
      required: true,
      options: [
        { label: 'Valid', value: 'verified' },
        { label: 'Perlu revisi', value: 'revision' },
        { label: 'Tidak valid', value: 'rejected' },
      ],
    },
    { name: 'notes', type: 'textarea', required: true, maxLength: 1000 },
    { name: 'verifiedAt', type: 'date', required: true },
  ],
}
