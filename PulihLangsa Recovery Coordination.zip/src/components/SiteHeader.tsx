import Link from 'next/link'
import { HeartHand } from './Icons'

export function Brand({ inverse = false }: { inverse?: boolean }) {
  return (
    <Link href="/" className="flex items-center gap-3" aria-label="PulihLangsa beranda">
      <span className={`grid size-10 place-items-center rounded-xl ${inverse ? 'bg-white/15 text-white' : 'bg-emerald-700 text-white'}`}>
        <HeartHand className="size-5" />
      </span>
      <span className={`text-lg font-bold tracking-tight ${inverse ? 'text-white' : 'text-slate-950'}`}>
        Pulih<span className={inverse ? 'text-emerald-200' : 'text-emerald-700'}>Langsa</span>
      </span>
    </Link>
  )
}

export function SiteHeader() {
  return (
    <header className="absolute inset-x-0 top-0 z-30 border-b border-white/15">
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-5 sm:px-8">
        <Brand inverse />
        <nav className="hidden items-center gap-8 text-sm font-medium text-white/80 md:flex" aria-label="Navigasi utama">
          <Link href="#fitur" className="transition hover:text-white">Fitur</Link>
          <Link href="#cara-kerja" className="transition hover:text-white">Cara kerja</Link>
          <Link href="#transparansi" className="transition hover:text-white">Transparansi</Link>
        </nav>
        <div className="flex items-center gap-2">
          <Link href="/login" className="hidden rounded-lg px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-white/10 sm:block">
            Masuk
          </Link>
          <Link href="/register" className="rounded-lg bg-amber-400 px-4 py-2.5 text-sm font-bold text-slate-950 shadow-lg shadow-amber-950/15 transition hover:bg-amber-300">
            Gabung sekarang
          </Link>
        </div>
      </div>
    </header>
  )
}
