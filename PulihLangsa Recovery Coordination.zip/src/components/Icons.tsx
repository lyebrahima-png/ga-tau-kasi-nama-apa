import type { SVGProps } from 'react'

type IconProps = SVGProps<SVGSVGElement>

const Icon = ({ children, ...props }: IconProps) => (
  <svg
    aria-hidden="true"
    fill="none"
    viewBox="0 0 24 24"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    {children}
  </svg>
)

export const ArrowUpRight = (props: IconProps) => (
  <Icon {...props}><path d="M7 17 17 7M7 7h10v10" /></Icon>
)
export const BoxIcon = (props: IconProps) => (
  <Icon {...props}><path d="m21 8-9 5-9-5 9-5 9 5Z" /><path d="m3 8 9 5 9-5M12 13v9" /></Icon>
)
export const CheckCircle = (props: IconProps) => (
  <Icon {...props}><circle cx="12" cy="12" r="9" /><path d="m8 12 2.5 2.5L16 9" /></Icon>
)
export const ChevronRight = (props: IconProps) => (
  <Icon {...props}><path d="m9 18 6-6-6-6" /></Icon>
)
export const ClipboardIcon = (props: IconProps) => (
  <Icon {...props}><rect x="5" y="4" width="14" height="17" rx="2" /><path d="M9 4.5V3h6v1.5M9 9h6M9 13h6M9 17h4" /></Icon>
)
export const ClockIcon = (props: IconProps) => (
  <Icon {...props}><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></Icon>
)
export const HeartHand = (props: IconProps) => (
  <Icon {...props}><path d="M7.5 4.5C5.6 3 2.5 4.3 2.5 7c0 3.3 4.6 6 9.5 9 4.9-3 9.5-5.7 9.5-9 0-2.7-3.1-4-5-2.5C15.3 5.4 14.4 7 12 9c-2.4-2-3.3-3.6-4.5-4.5Z" /><path d="M3 20h8c2.5 0 3-2 5-2h5" /></Icon>
)
export const MapPinIcon = (props: IconProps) => (
  <Icon {...props}><path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z" /><circle cx="12" cy="10" r="2.5" /></Icon>
)
export const MenuIcon = (props: IconProps) => (
  <Icon {...props}><path d="M4 7h16M4 12h16M4 17h16" /></Icon>
)
export const PackageCheck = (props: IconProps) => (
  <Icon {...props}><path d="m21 8-9 5-9-5 9-5 9 5Z" /><path d="m3 8 9 5 9-5M12 13v9M7 17l2 2 4-4" /></Icon>
)
export const ShieldCheck = (props: IconProps) => (
  <Icon {...props}><path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z" /><path d="m8.5 11.5 2 2 5-5" /></Icon>
)
export const TrendingUp = (props: IconProps) => (
  <Icon {...props}><path d="m3 17 6-6 4 4 7-8" /><path d="M14 7h6v6" /></Icon>
)
export const UsersIcon = (props: IconProps) => (
  <Icon {...props}><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8" /></Icon>
)
