'use client'

import { useActionState } from 'react'
import Link from 'next/link'
import type { AuthState } from '@/app/(frontend)/actions/auth'

type AuthAction = (state: AuthState, formData: FormData) => Promise<AuthState>

export function AuthForm({
  action,
  mode,
}: {
  action: AuthAction
  mode: 'login' | 'register'
}) {
  const [state, formAction, pending] = useActionState(action, {})
  const register = mode === 'register'

  return (
    <form action={formAction} className="mt-8 space-y-5">
      {register && (
        <>
          <label className="block">
            <span className="mb-2 block text-sm font-semibold text-slate-700">Nama lengkap</span>
            <input name="name" autoComplete="name" required className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3.5 text-slate-950 outline-none transition placeholder:text-slate-400 focus:border-emerald-600 focus:ring-4 focus:ring-emerald-600/10" placeholder="Nama Anda" />
          </label>
          <label className="block">
            <span className="mb-2 block text-sm font-semibold text-slate-700">Nomor WhatsApp</span>
            <input name="phone" autoComplete="tel" className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3.5 text-slate-950 outline-none transition placeholder:text-slate-400 focus:border-emerald-600 focus:ring-4 focus:ring-emerald-600/10" placeholder="08xx xxxx xxxx" />
          </label>
        </>
      )}
      <label className="block">
        <span className="mb-2 block text-sm font-semibold text-slate-700">Email</span>
        <input name="email" type="email" autoComplete="email" required className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3.5 text-slate-950 outline-none transition placeholder:text-slate-400 focus:border-emerald-600 focus:ring-4 focus:ring-emerald-600/10" placeholder="nama@email.com" />
      </label>
      <label className="block">
        <span className="mb-2 block text-sm font-semibold text-slate-700">Kata sandi</span>
        <input name="password" type="password" minLength={8} autoComplete={register ? 'new-password' : 'current-password'} required className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3.5 text-slate-950 outline-none transition placeholder:text-slate-400 focus:border-emerald-600 focus:ring-4 focus:ring-emerald-600/10" placeholder="Minimal 8 karakter" />
      </label>
      {state.error && (
        <p role="alert" className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm font-medium text-rose-700">
          {state.error}
        </p>
      )}
      <button disabled={pending} className="w-full rounded-xl bg-emerald-700 px-5 py-3.5 font-bold text-white shadow-lg shadow-emerald-900/15 transition hover:bg-emerald-800 disabled:cursor-wait disabled:opacity-60">
        {pending ? 'Memproses…' : register ? 'Buat akun' : 'Masuk ke dashboard'}
      </button>
      <p className="text-center text-sm text-slate-500">
        {register ? 'Sudah punya akun?' : 'Belum punya akun?'}{' '}
        <Link href={register ? '/login' : '/register'} className="font-bold text-emerald-700 hover:text-emerald-800">
          {register ? 'Masuk' : 'Daftar'}
        </Link>
      </p>
    </form>
  )
}
