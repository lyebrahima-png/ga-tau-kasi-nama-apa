import 'server-only'

import { cookies } from 'next/headers'
import { getPayloadClient } from '@/lib/payload'

const SESSION_COOKIE = 'app-session'

export function createAppAuth(collection: 'users') {
  return {
    async currentUser() {
      const token = (await cookies()).get(SESSION_COOKIE)?.value
      if (!token) return null

      const payload = await getPayloadClient()
      const authHeaders = new Headers({ Authorization: `JWT ${token}` })
      const { user } = await payload.auth({ headers: authHeaders })

      if (!user || user.collection !== collection) return null
      return user
    },

    async login(email: string, password: string) {
      const payload = await getPayloadClient()
      const result = await payload.login({
        collection,
        data: { email, password },
        overrideAccess: false,
      })
      if (!result.token || !result.user) {
        throw new Error('Email atau kata sandi tidak valid.')
      }

      const cookieStore = await cookies()
      cookieStore.set(SESSION_COOKIE, result.token, {
        httpOnly: true,
        sameSite: 'lax',
        secure: process.env.NODE_ENV === 'production',
        path: '/',
        maxAge: 60 * 60 * 24 * 7,
      })
      return result.user
    },

    async register(data: {
      email: string
      name: string
      password: string
      phone?: string
    }) {
      const payload = await getPayloadClient()
      await payload.create({
        collection,
        data: {
          email: data.email,
          name: data.name,
          password: data.password,
          phone: data.phone,
        },
        overrideAccess: false,
      })
      return this.login(data.email, data.password)
    },

    async logout() {
      const cookieStore = await cookies()
      cookieStore.delete(SESSION_COOKIE)
    },
  }
}

export const appAuth = createAppAuth('users')
