/* SehatAkses — perilaku interaktif (migrasi dari React/App.tsx ke JavaScript biasa) */
(function () {
  'use strict';

  var ATTRS = 'width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"';
  var ICONS = {
    menu:  '<svg ' + ATTRS + '><path d="M4 7h16M4 12h16M4 17h16" /></svg>',
    close: '<svg ' + ATTRS + '><path d="m6 6 12 12M18 6 6 18" /></svg>',
    check: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m5 12 4 4L19 6" /></svg>'
  };

  var shell = document.querySelector('.app-shell');
  var nav = document.querySelector('.navigation');
  var menuBtn = document.querySelector('[data-menu-toggle]');
  var backdrop = document.querySelector('[data-login-backdrop]');
  var toastTimer = null;

  /* ---------- Menu mobile ---------- */
  menuBtn.addEventListener('click', function () {
    var open = nav.classList.toggle('navigation--open');
    menuBtn.setAttribute('aria-label', open ? 'Tutup menu' : 'Buka menu');
    menuBtn.setAttribute('aria-expanded', String(open));
    menuBtn.innerHTML = open ? ICONS.close : ICONS.menu;
  });

  /* ---------- Toast pencarian ---------- */
  function showToast(message) {
    var toast = shell.querySelector('.toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.className = 'toast';
      toast.setAttribute('role', 'status');
      shell.appendChild(toast);
    }
    toast.innerHTML = '<span>' + ICONS.check + '</span>';
    toast.appendChild(document.createTextNode(message));
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () {
      if (toast.parentNode) toast.parentNode.removeChild(toast);
    }, 3200);
  }

  document.querySelector('[data-search-form]').addEventListener('submit', function (e) {
    e.preventDefault();
    var term = this.querySelector('input').value;
    showToast(term
      ? 'Menampilkan hasil untuk \u201C' + term + '\u201D'
      : 'Masukkan nama layanan atau fasilitas');
  });

  /* ---------- Modal login ---------- */
  var roleButtons = backdrop.querySelectorAll('[data-role]');
  var submitLabel = backdrop.querySelector('[data-login-submit] span');

  function setRole(role) {
    roleButtons.forEach(function (b) {
      b.classList.toggle('active', b.getAttribute('data-role') === role);
    });
    submitLabel.textContent = 'Masuk sebagai ' + role;
  }

  function openLogin() {
    // setiap dibuka, kondisi kembali segar (seperti komponen React yang di-mount ulang)
    setRole('Pengguna');
    backdrop.querySelectorAll('input').forEach(function (i) { i.value = ''; });
    backdrop.hidden = false;
  }
  function closeLogin() { backdrop.hidden = true; }

  document.querySelector('[data-open-login]').addEventListener('click', openLogin);
  backdrop.querySelector('[data-close-login]').addEventListener('click', closeLogin);
  roleButtons.forEach(function (b) {
    b.addEventListener('click', function () { setRole(b.getAttribute('data-role')); });
  });
  // klik/tekan di area gelap (bukan di dalam kotak modal) menutup modal
  backdrop.addEventListener('mousedown', function (e) {
    if (e.target === backdrop) closeLogin();
  });
})();
