/* =====================================================================
   DATA GAMBAR & PRODUK  —  COFFE ALOSKI
   ---------------------------------------------------------------------
   Untuk memakai gambar sendiri:
   1. Taruh file gambar di folder  images/
   2. Ganti alamat URL di bawah dengan path lokal, contoh:
        hero: 'images/hero.jpg'
        image: 'images/aren-cloud-latte.jpg'
   ===================================================================== */

const images = {
  hero: 'https://images.unsplash.com/photo-1680381792123-676305af82d8?auto=format&fit=crop&w=1400&q=88',
  cafe: 'https://images.unsplash.com/photo-1685718913827-4321d75a19cd?auto=format&fit=crop&w=1200&q=85',
  barista: 'https://images.unsplash.com/photo-1775991072530-9a8e3148830f?auto=format&fit=crop&w=900&q=85',
  pastry: 'https://images.unsplash.com/photo-1548538931-b47653628cdc?auto=format&fit=crop&w=900&q=85',
};

const products = [
  { id: 1, name: 'Aren Cloud Latte', category: 'Coffee', price: 28000, description: 'Espresso Gayo, susu segar, dan gula aren organik yang lembut.', image: 'https://images.unsplash.com/photo-1764416002220-976a7ed6b455?auto=format&fit=crop&w=700&q=85', badge: 'Best seller' },
  { id: 2, name: 'Kopi Aloski', category: 'Coffee', price: 24000, description: 'Signature long black dengan biji pilihan Toraja yang berkarakter.', image: 'https://images.unsplash.com/photo-1759259639485-5e11d60b81af?auto=format&fit=crop&w=700&q=85', badge: 'Signature' },
  { id: 3, name: 'Sea Salt Caramel', category: 'Coffee', price: 30000, description: 'Latte creamy, karamel buatan sendiri, dan sentuhan sea salt.', image: 'https://images.unsplash.com/photo-1749105862023-daa3512f32eb?auto=format&fit=crop&w=700&q=85' },
  { id: 4, name: 'Matcha Pandan', category: 'Non-Coffee', price: 29000, description: 'Matcha premium dengan aroma pandan dan susu oat yang ringan.', image: 'https://images.unsplash.com/photo-1556881286-fc6915169721?auto=format&fit=crop&w=700&q=85', badge: 'New' },
  { id: 5, name: 'Cocoa Cream', category: 'Non-Coffee', price: 27000, description: 'Cokelat pekat, fresh milk, dan vanilla cream yang seimbang.', image: 'https://images.unsplash.com/photo-1572490122747-3968b75cc699?auto=format&fit=crop&w=700&q=85' },
  { id: 6, name: 'Rosella Tea', category: 'Non-Coffee', price: 22000, description: 'Seduhan rosella segar dengan madu dan irisan lemon.', image: 'https://images.unsplash.com/photo-1556679343-c7306c1976bc?auto=format&fit=crop&w=700&q=85' },
  { id: 7, name: 'Butter Croissant', category: 'Snack', price: 22000, description: 'Croissant renyah berlapis dengan butter premium.', image: images.pastry, badge: 'Fresh daily' },
  { id: 8, name: 'Kaya Toast', category: 'Snack', price: 26000, description: 'Roti panggang hangat, selai srikaya, dan salted butter.', image: 'https://images.unsplash.com/photo-1584776296944-ab6fb57b0bdd?auto=format&fit=crop&w=700&q=85' },
  { id: 9, name: 'Cinnamon Roll', category: 'Snack', price: 24000, description: 'Roti kayu manis lembut dengan glaze cream cheese.', image: 'https://images.unsplash.com/photo-1509365465985-25d11c17e812?auto=format&fit=crop&w=700&q=85' },
];
