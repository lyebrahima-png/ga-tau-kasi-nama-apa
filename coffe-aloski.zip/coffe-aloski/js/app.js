/* =====================================================================
   COFFE ALOSKI — logika aplikasi (JavaScript murni, tanpa framework)
   Struktur HTML & nama class sama persis dengan versi React aslinya.
   ===================================================================== */

/* ---------- State ---------- */
const state = {
  page: 'home',          // home | menu | about | contact | cart
  selected: null,        // produk yang sedang dibuka (halaman detail)
  cart: [],
  menuOpen: false,       // menu navigasi mobile
};
const menuState = { category: 'Semua', search: '' };
const detailState = { size: 'Regular', sugar: 'Normal', ice: 'Normal', quantity: 1 };
let lastView = null;

/* ---------- Helper ---------- */
const formatPrice = (value) => `Rp ${value.toLocaleString('id-ID')}`;
const cartCountLabel = (cart) => cart.map((i) => `${i.quantity}x ${i.name}`).join(', ');
const cartCount = () => state.cart.reduce((sum, i) => sum + i.quantity, 0);
const findProduct = (id) => products.find((p) => p.id === Number(id));

/* ---------- Ikon ---------- */
const iconPaths = {
  arrow: '<path d="M5 12h14M13 6l6 6-6 6" />',
  bag: '<path d="M6 8h12l1 12H5L6 8Z" /><path d="M9 9V6a3 3 0 0 1 6 0v3" />',
  search: '<circle cx="11" cy="11" r="7" /><path d="m16 16 4 4" />',
  menu: '<path d="M4 7h16M4 12h16M4 17h16" />',
  close: '<path d="m6 6 12 12M18 6 6 18" />',
  plus: '<path d="M12 5v14M5 12h14" />',
  minus: '<path d="M5 12h14" />',
  trash: '<path d="M4 7h16M9 7V4h6v3M7 7l1 13h8l1-13" />',
  map: '<path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z" /><circle cx="12" cy="10" r="2.5" />',
  clock: '<circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" />',
  phone: '<path d="M7 3H4a1 1 0 0 0-1 1c0 9.4 7.6 17 17 17a1 1 0 0 0 1-1v-3l-4-1-1.5 2a15 15 0 0 1-9.5-9.5L8 7 7 3Z" />',
  instagram: '<rect x="3" y="3" width="18" height="18" rx="5" /><circle cx="12" cy="12" r="4" /><path d="M17.5 6.5h.01" />',
  leaf: '<path d="M20 4C11 4 5 8 5 15c0 2 1 4 3 5 0-5 4-9 9-12-4 3-7 7-8 12" />',
  coffee: '<path d="M4 8h13v6a6 6 0 0 1-6 6H10a6 6 0 0 1-6-6V8Z" /><path d="M17 10h1a3 3 0 0 1 0 6h-2M8 4v2M12 3v3" />',
};
const Icon = (name, size = 20) =>
  `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${iconPaths[name]}</svg>`;

/* ---------- Komponen kecil ---------- */
const Logo = (light = false) => `
  <button class="logo ${light ? 'logo-light' : ''}" data-action="logo" aria-label="COFFE ALOSKI">
    <span class="logo-mark">${Icon('coffee', 19)}</span>
    <span><b>COFFE</b><small>ALOSKI</small></span>
  </button>`;

const Button = (content, { variant = 'primary', action = '', attrs = '', className = '' } = {}) =>
  `<button type="button" class="btn btn-${variant} ${className}" ${action ? `data-action="${action}"` : ''} ${attrs}>${content}</button>`;

const NavBtn = (content, page, opts = {}) => Button(content, { ...opts, action: 'nav', attrs: `data-page="${page}" ${opts.attrs || ''}` });

const SectionTitle = (eyebrow, title, text, centered = false) =>
  `<div class="section-title ${centered ? 'centered' : ''}"><span class="eyebrow">${eyebrow}</span><h2>${title}</h2>${text ? `<p>${text}</p>` : ''}</div>`;

/* ---------- Header ---------- */
function Header() {
  const { page, menuOpen } = state;
  const count = cartCount();
  const link = (label, p, anchor) =>
    `<button class="${!anchor && page === p ? 'active' : ''}" data-action="nav" data-page="${p}" ${anchor ? `data-anchor="${anchor}"` : ''}>${label}</button>`;
  return `
    <header class="header">
      <div class="nav-shell">
        ${Logo()}
        <button class="mobile-toggle" data-action="toggle-nav" aria-label="Buka navigasi">${Icon(menuOpen ? 'close' : 'menu')}</button>
        <nav class="${menuOpen ? 'nav-links open' : 'nav-links'}">
          ${link('Home', 'home')}
          ${link('Menu', 'menu')}
          ${link('Tentang Kami', 'about')}
          ${link('Promo', 'home', 'promo')}
          ${link('Kontak', 'contact')}
        </nav>
        <div class="nav-actions">
          <button class="cart-button" data-action="nav" data-page="cart" aria-label="Keranjang, ${count} item">${Icon('bag')}${count > 0 ? `<span>${count}</span>` : ''}</button>
          ${NavBtn(`Pesan Sekarang ${Icon('arrow', 17)}`, 'menu')}
        </div>
      </div>
    </header>`;
}

/* ---------- Kartu produk ---------- */
const ProductCard = (p) => `
  <article class="product-card">
    <button class="product-image" data-action="detail" data-id="${p.id}" aria-label="Lihat ${p.name}">
      <img src="${p.image}" alt="${p.name}" />
      ${p.badge ? `<span class="badge">${p.badge}</span>` : ''}
    </button>
    <div class="product-copy">
      <span class="product-category">${p.category}</span>
      <h3>${p.name}</h3>
      <p>${p.description}</p>
      <div class="product-bottom"><strong>${formatPrice(p.price)}</strong><button class="add-icon" data-action="add" data-id="${p.id}" aria-label="Tambah ${p.name}">${Icon('plus')}</button></div>
    </div>
  </article>`;

/* ---------- Halaman Home ---------- */
function Home() {
  const categories = [
    ['Coffee', 'Kopi Nusantara dengan karakter yang kaya.', products[1].image, '01'],
    ['Non-Coffee', 'Segar, creamy, dan cocok untuk semua.', products[4].image, '02'],
    ['Snack', 'Teman sempurna untuk setiap cangkirmu.', images.pastry, '03'],
  ];
  const testimonials = [
    ['“Kopi arennya balance banget, nggak terlalu manis. Suasana kedainya juga bikin betah kerja berjam-jam.”', 'Nadia P.', 'Content Designer'],
    ['“Akhirnya nemu kopi Toraja yang karakternya keluar tapi tetap nyaman diminum setiap hari.”', 'Raka W.', 'Local Guide'],
    ['“Pelayanan ramah, pastry selalu fresh. Kaya toast dan Aloski Latte adalah kombinasi wajib!”', 'Dinda A.', 'Entrepreneur'],
  ];
  return `
    <main>
      <section class="hero">
        <div class="hero-copy">
          <span class="eyebrow">Kopi lokal, diracik dengan hati</span>
          <h1>Temukan <em>Kehangatan</em> dalam Setiap Tegukan.</h1>
          <p>Ruang pulang untuk menikmati kopi Nusantara pilihan, cerita hangat, dan jeda yang berarti di tengah kesibukanmu.</p>
          <div class="hero-actions">
            ${NavBtn(`Lihat Menu ${Icon('arrow', 18)}`, 'menu')}
            ${NavBtn('Pesan Sekarang', 'menu', { variant: 'secondary' })}
          </div>
          <div class="hero-proof">
            <div class="avatars"><span>NA</span><span>RA</span><span>DI</span></div>
            <div><b>4.9 / 5.0</b><small>Disukai 1.200+ penikmat kopi</small></div>
          </div>
        </div>
        <div class="hero-visual">
          <div class="hero-image"><img src="${images.hero}" alt="Secangkir latte hangat COFFE ALOSKI" /></div>
          <div class="floating-note"><span>${Icon('leaf')}</span><div><b>100% Lokal</b><small>Biji kopi pilihan Nusantara</small></div></div>
          <div class="hero-number"><b>08</b><span>tahun<br />meracik cerita</span></div>
        </div>
      </section>

      <section class="ticker" aria-label="Keunggulan COFFE ALOSKI"><span>Arabika Gayo</span><i>•</i><span>Roasted Fresh</span><i>•</i><span>Local Farmers</span><i>•</i><span>Made with Heart</span><i>•</i><span>Arabika Toraja</span></section>

      <section class="section best-seller">
        <div class="section-head">
          ${SectionTitle('Favorit Aloski', 'Pilihan yang Selalu Dirindukan', 'Rasa terbaik yang paling sering menemani cerita pelanggan kami.')}
          ${NavBtn(`Lihat Semua Menu ${Icon('arrow', 18)}`, 'menu', { variant: 'ghost' })}
        </div>
        <div class="product-grid">${products.slice(0, 3).map(ProductCard).join('')}</div>
      </section>

      <section class="section categories">
        ${SectionTitle('Temukan Favoritmu', 'Satu Tempat, Banyak Cerita Rasa', undefined, true)}
        <div class="category-grid">
          ${categories.map(([name, copy, image, no]) => `
            <button class="category-card" data-action="nav" data-page="menu">
              <img src="${image}" alt="${name}" /><span class="category-overlay"></span><span class="category-no">${no}</span>
              <span class="category-copy"><b>${name}</b><small>${copy}</small><i>${Icon('arrow')}</i></span>
            </button>`).join('')}
        </div>
      </section>

      <section class="story-section">
        <div class="story-collage">
          <img class="story-main" src="${images.cafe}" alt="Suasana hangat kedai COFFE ALOSKI" />
          <img class="story-small" src="${images.barista}" alt="Barista sedang meracik kopi" />
          <div class="story-stamp">${Icon('coffee', 25)}<span>Sejak<br /><b>2017</b></span></div>
        </div>
        <div class="story-copy">
          ${SectionTitle('Tentang Kami', 'Bukan Sekadar Kopi, Ini Tentang Cerita.')}
          <p>COFFE ALOSKI lahir dari mimpi sederhana: membawa kekayaan rasa kopi Indonesia lebih dekat dengan keseharian. Kami bermitra langsung dengan petani lokal dan meracik setiap cangkir dengan penuh perhatian.</p>
          <div class="values">
            <div>${Icon('leaf')}<span><b>Biji Lokal Pilihan</b><small>Dari petani terbaik Nusantara</small></span></div>
            <div>${Icon('coffee')}<span><b>Diracik Sepenuh Hati</b><small>Presisi dalam setiap sajian</small></span></div>
          </div>
          ${NavBtn(`Cerita Selengkapnya ${Icon('arrow', 18)}`, 'about', { variant: 'secondary' })}
        </div>
      </section>

      <section class="promo-section" id="promo">
        <div class="promo-copy"><span class="promo-label">Promo bulan ini</span><h2>Teman Ngopi,<br />Harga Lebih Happy.</h2><p>Beli 2 minuman favorit, dapatkan diskon 20% setiap Senin–Kamis.</p>${NavBtn(`Klaim Promo ${Icon('arrow', 18)}`, 'menu', { variant: 'light' })}</div>
        <div class="promo-art"><span class="discount">20%<small>OFF</small></span><img src="${products[0].image}" alt="Promo minuman COFFE ALOSKI" /></div>
      </section>

      <section class="section testimonials">
        ${SectionTitle('Kata Mereka', 'Cerita Hangat dari Pelanggan', undefined, true)}
        <div class="testimonial-grid">
          ${testimonials.map(([quote, name, role], i) => `<article class="testimonial-card"><div class="stars">★★★★★</div><p>${quote}</p><div class="reviewer"><span>${name.split(' ').map((x) => x[0]).join('')}</span><div><b>${name}</b><small>${role}</small></div><i>0${i + 1}</i></div></article>`).join('')}
        </div>
      </section>
    </main>`;
}

/* ---------- Halaman Menu ---------- */
const CATEGORIES = ['Semua', 'Coffee', 'Non-Coffee', 'Snack'];

function MenuPage() {
  return `
    <main>
      <section class="page-hero menu-hero"><span class="eyebrow">Menu Kami</span><h1>Rasa yang Dibuat<br />untuk <em>Setiap Suasana.</em></h1><p>Dari kopi yang berani hingga minuman yang menenangkan. Temukan teman terbaik untuk harimu.</p></section>
      <section class="section menu-content">
        <div class="menu-tools">
          <div class="filter-row" id="filterRow"></div>
          <label class="search-box">${Icon('search')}<input id="searchInput" value="" placeholder="Cari menu favorit..." /></label>
        </div>
        <div class="menu-result"><span id="menuCount"></span><span>Harga sudah termasuk pajak</span></div>
        <div class="product-grid full" id="menuGrid"></div>
        <div id="menuEmpty"></div>
      </section>
    </main>`;
}

function updateMenu() {
  const { category, search } = menuState;
  const filtered = products.filter((p) => (category === 'Semua' || p.category === category) && p.name.toLowerCase().includes(search.toLowerCase()));
  document.getElementById('filterRow').innerHTML = CATEGORIES.map((c) => `<button class="${category === c ? 'selected' : ''}" data-action="filter" data-cat="${c}">${c}</button>`).join('');
  document.getElementById('menuCount').textContent = `${filtered.length} menu ditemukan`;
  document.getElementById('menuGrid').innerHTML = filtered.map(ProductCard).join('');
  document.getElementById('menuEmpty').innerHTML = filtered.length === 0
    ? `<div class="empty-state">${Icon('search', 36)}<h3>Menu belum ditemukan</h3><p>Coba kata kunci atau kategori lain.</p></div>` : '';
}

/* ---------- Halaman Detail Produk ---------- */
const Option = (title, values, selected, group) =>
  `<div class="option-group"><b>${title}</b><div>${values.map((v) => `<button class="${selected === v ? 'active' : ''}" data-action="option" data-group="${group}" data-value="${v}">${v}<span></span></button>`).join('')}</div></div>`;

function ProductDetail() {
  const product = state.selected;
  const { size, sugar, ice, quantity } = detailState;
  const extra = size === 'Large' ? 5000 : 0;
  return `
    <main class="detail-page">
      <button class="back-link" data-action="back">← Kembali ke menu</button>
      <div class="detail-grid">
        <div class="detail-image"><img src="${product.image}" alt="${product.name}" />${product.badge ? `<span class="badge">${product.badge}</span>` : ''}</div>
        <div class="detail-copy">
          <span class="eyebrow">${product.category} · Aloski Signature</span>
          <h1>${product.name}</h1>
          <p>${product.description} Dibuat dari bahan berkualitas dan diracik langsung saat pesananmu diterima.</p>
          <strong class="detail-price">${formatPrice(product.price + extra)}</strong>
          ${Option('Pilih ukuran', ['Regular', 'Large +5k'], size === 'Large' ? 'Large +5k' : size, 'size')}
          ${product.category !== 'Snack' ? Option('Tingkat gula', ['Tanpa Gula', 'Less', 'Normal'], sugar, 'sugar') + Option('Tingkat es', ['Tanpa Es', 'Less', 'Normal'], ice, 'ice') : ''}
          <div class="detail-action">
            <div class="quantity"><button data-action="qty-dec">${Icon('minus')}</button><span>${quantity}</span><button data-action="qty-inc">${Icon('plus')}</button></div>
            ${Button(`Tambah · ${formatPrice((product.price + extra) * quantity)} ${Icon('bag')}`, { action: 'add-configured' })}
          </div>
        </div>
      </div>
    </main>`;
}

/* ---------- Halaman Keranjang ---------- */
function CartPage() {
  const subtotal = state.cart.reduce((sum, i) => sum + i.price * i.quantity, 0);
  const body = state.cart.length === 0
    ? `<div class="empty-cart"><span>${Icon('bag', 42)}</span><h2>Keranjangmu masih kosong</h2><p>Yuk, pilih minuman atau camilan favoritmu.</p>${NavBtn(`Jelajahi Menu ${Icon('arrow')}`, 'menu')}</div>`
    : `<div class="cart-layout">
        <div class="cart-items">
          ${state.cart.map((item, i) => `<article class="cart-item"><img src="${item.image}" alt="${item.name}" /><div class="cart-item-copy"><span>${item.category}</span><h3>${item.name}</h3><p>${item.size} · ${item.sugar} sugar · ${item.ice} ice</p><strong>${formatPrice(item.price)}</strong></div><div class="cart-item-actions"><button class="remove" data-action="cart-remove" data-index="${i}">${Icon('trash')}</button><div class="quantity"><button data-action="cart-dec" data-index="${i}">${Icon('minus')}</button><span>${item.quantity}</span><button data-action="cart-inc" data-index="${i}">${Icon('plus')}</button></div></div></article>`).join('')}
          ${NavBtn('+ Tambah menu lain', 'menu', { variant: 'ghost' })}
        </div>
        <aside class="summary"><h3>Ringkasan Pesanan</h3><div><span>Subtotal</span><b>${formatPrice(subtotal)}</b></div><div><span>Biaya layanan</span><b>Rp 2.000</b></div><div class="summary-total"><span>Total</span><strong>${formatPrice(subtotal + 2000)}</strong></div>${Button(`Lanjut Checkout ${Icon('arrow')}`, { action: 'checkout', className: 'checkout' })}<small>Checkout aman melalui WhatsApp COFFE ALOSKI</small></aside>
      </div>`;
  return `<main class="cart-page">${SectionTitle('Pesananmu', 'Keranjang Belanja', 'Periksa kembali pesanan sebelum melanjutkan.')}${body}</main>`;
}

/* ---------- Halaman Tentang Kami ---------- */
function AboutPage() {
  const mission = [['01', 'Jujur pada Rasa', 'Mempertahankan karakter asli setiap biji kopi tanpa kompromi.'], ['02', 'Bersama Petani', 'Kemitraan yang adil dan berkelanjutan dengan petani lokal.'], ['03', 'Hangat Melayani', 'Membuat setiap orang merasa diterima dan punya tempat untuk pulang.']];
  return `<main>
    <section class="page-hero about-hero"><span class="eyebrow">Cerita Aloski</span><h1>Dari Tanah Nusantara,<br />untuk <em>Cerita Kita.</em></h1></section>
    <section class="about-intro section"><div><img src="${images.cafe}" alt="Interior COFFE ALOSKI" /></div><div>${SectionTitle('Berawal di 2017', 'Mimpi Sederhana yang Tumbuh Bersama.')}<p>Berawal dari kedai kecil dan kecintaan pada kopi lokal, COFFE ALOSKI tumbuh sebagai ruang yang mempertemukan rasa, manusia, dan cerita. Nama “Aloski” kami maknai sebagai sapaan hangat—sebuah undangan untuk singgah dan merasa pulang.</p><p>Kami percaya secangkir kopi yang baik dimulai dari hubungan yang baik. Karena itu, kami mengenal petani kami, menghargai setiap proses, dan menjaga kualitas dari kebun hingga cangkir.</p>${NavBtn(`Kunjungi Kedai Kami ${Icon('arrow')}`, 'contact', { variant: 'secondary' })}</div></section>
    <section class="mission">${SectionTitle('Yang Kami Percaya', 'Tumbuh dengan Nilai yang Baik', undefined, true)}<div class="mission-grid">${mission.map(([no, title, copy]) => `<article><span>${no}</span><h3>${title}</h3><p>${copy}</p></article>`).join('')}</div></section>
    <section class="about-banner"><img src="${images.barista}" alt="Barista COFFE ALOSKI" /><div><span class="eyebrow">Visi Kami</span><h2>Menjadikan kopi lokal kebanggaan dalam setiap keseharian.</h2><p>Menyajikan kualitas, menjaga keberlanjutan, dan menciptakan dampak baik bagi rantai kopi Indonesia.</p></div></section>
  </main>`;
}

/* ---------- Halaman Kontak ---------- */
const ContactCard = (icon, title, copy) =>
  `<article class="contact-card"><span>${Icon(icon)}</span><div><h3>${title}</h3>${copy.split('\n').map((line) => `<p>${line}</p>`).join('')}</div></article>`;

function ContactPage() {
  return `<main>
    <section class="page-hero contact-hero"><span class="eyebrow">Mari Terhubung</span><h1>Ada Cerita yang Ingin<br />Kamu <em>Bagikan?</em></h1><p>Kami selalu senang mendengar darimu. Hubungi atau langsung singgah ke kedai.</p></section>
    <section class="contact-layout section">
      <div class="contact-cards">
        ${ContactCard('map', 'Alamat Kedai', 'Jl. Raden Saleh No. 18, Cikini, Jakarta Pusat 10330')}
        ${ContactCard('phone', 'WhatsApp', '+62 812 3456 7890')}
        ${ContactCard('instagram', 'Instagram', '@coffealoski')}
        ${ContactCard('clock', 'Jam Operasional', 'Senin–Jumat 07.00–22.00\nSabtu–Minggu 08.00–23.00')}
      </div>
      <div class="map-card">
        <div class="map-pattern"><span class="map-pin">${Icon('map', 34)}</span><span class="road road-one"></span><span class="road road-two"></span><span class="road road-three"></span></div>
        <div class="map-footer"><div><b>COFFE ALOSKI — Cikini</b><small>Jakarta Pusat · Buka hingga 22.00</small></div>${Button(`Buka di Google Maps ${Icon('arrow')}`, { action: 'maps' })}</div>
      </div>
    </section>
    <section class="contact-cta"><span class="eyebrow">Untuk Kolaborasi & Acara</span><h2>Bawa Kehangatan Aloski ke Acaramu.</h2><p>Coffee catering, private event, atau kolaborasi kreatif—mari ciptakan sesuatu bersama.</p>${Button(`Hubungi Tim Kami ${Icon('arrow')}`, { variant: 'light' })}</section>
  </main>`;
}

/* ---------- Footer ---------- */
const Footer = () => `
  <footer><div class="footer-top"><div class="footer-brand">${Logo(true)}<p>Kopi lokal yang diracik dengan hati untuk menemani setiap cerita.</p><div class="socials"><button aria-label="Instagram">${Icon('instagram')}</button><button aria-label="Lokasi">${Icon('map')}</button></div></div>
  <div><b>Jelajahi</b><button data-action="nav" data-page="home">Home</button><button data-action="nav" data-page="menu">Menu</button><button data-action="nav" data-page="about">Tentang Kami</button><button data-action="nav" data-page="home" data-anchor="promo">Promo</button></div>
  <div><b>Hubungi Kami</b><span>Jl. Raden Saleh No. 18<br />Cikini, Jakarta Pusat</span><span>+62 812 3456 7890</span><span>hello@coffealoski.id</span></div>
  <div><b>Jam Operasional</b><span>Senin–Jumat<br /><strong>07.00–22.00</strong></span><span>Sabtu–Minggu<br /><strong>08.00–23.00</strong></span></div></div>
  <div class="footer-bottom"><span>© 2025 COFFE ALOSKI. Dibuat dengan hangat di Jakarta.</span><span>Privasi &nbsp; · &nbsp; Ketentuan</span></div></footer>`;

/* ---------- Render ---------- */
function renderHeader() {
  document.querySelector('.header').outerHTML = Header();
}

function renderView() {
  const view = document.getElementById('view');
  let key, html;
  if (state.selected) { key = 'detail'; html = ProductDetail(); }
  else {
    key = state.page;
    html = { home: Home, menu: MenuPage, about: AboutPage, contact: ContactPage, cart: CartPage }[state.page]();
  }
  // state menu direset hanya saat halaman menu dibuka kembali dari halaman lain
  if (key === 'menu' && lastView !== 'menu') { menuState.category = 'Semua'; menuState.search = ''; }
  view.innerHTML = html;
  if (key === 'menu') updateMenu();
  lastView = key;
}

function renderAll() { renderHeader(); renderView(); }

/* ---------- Aksi ---------- */
function navigate(next, anchor) {
  state.selected = null;
  state.page = next;
  state.menuOpen = false;
  renderAll();
  setTimeout(() => anchor
    ? document.getElementById(anchor)?.scrollIntoView({ behavior: 'smooth' })
    : window.scrollTo({ top: 0, behavior: 'smooth' }), 0);
}

function quickAdd(product) {
  state.cart.push({ ...product, quantity: 1, size: 'Regular', sugar: 'Normal', ice: 'Normal' });
  renderHeader();
}

function selectProduct(product) {
  state.selected = product;
  Object.assign(detailState, { size: 'Regular', sugar: 'Normal', ice: 'Normal', quantity: 1 });
  renderView();
  window.scrollTo(0, 0);
}

function addConfigured() {
  const p = state.selected;
  const extra = detailState.size === 'Large' ? 5000 : 0;
  state.cart.push({ ...p, price: p.price + extra, quantity: detailState.quantity, size: detailState.size, sugar: detailState.sugar, ice: detailState.ice });
  state.selected = null;
  state.page = 'cart';
  renderAll();
  window.scrollTo(0, 0);
}

function checkout() {
  const subtotal = state.cart.reduce((sum, i) => sum + i.price * i.quantity, 0);
  const text = `Halo COFFE ALOSKI, saya ingin memesan ${cartCountLabel(state.cart)}. Total ${formatPrice(subtotal + 2000)}.`;
  window.open(`https://wa.me/6281234567890?text=${encodeURIComponent(text)}`, '_blank', 'noopener,noreferrer');
}

/* ---------- Event (delegasi) ---------- */
document.addEventListener('click', (e) => {
  const el = e.target.closest('[data-action]');
  if (!el) return;
  const d = el.dataset;
  switch (d.action) {
    case 'logo': window.scrollTo(0, 0); break;
    case 'toggle-nav': state.menuOpen = !state.menuOpen; renderHeader(); break;
    case 'nav': navigate(d.page, d.anchor); break;
    case 'detail': selectProduct(findProduct(d.id)); break;
    case 'add': quickAdd(findProduct(d.id)); break;
    case 'back': state.selected = null; renderView(); break;
    case 'filter': menuState.category = d.cat; updateMenu(); break;
    case 'option':
      detailState[d.group] = d.group === 'size' ? (d.value.startsWith('Large') ? 'Large' : d.value) : d.value;
      renderView(); break;
    case 'qty-dec': detailState.quantity = Math.max(1, detailState.quantity - 1); renderView(); break;
    case 'qty-inc': detailState.quantity += 1; renderView(); break;
    case 'add-configured': addConfigured(); break;
    case 'cart-dec': { const it = state.cart[d.index]; it.quantity = Math.max(1, it.quantity - 1); renderAll(); break; }
    case 'cart-inc': state.cart[d.index].quantity += 1; renderAll(); break;
    case 'cart-remove': state.cart.splice(Number(d.index), 1); renderAll(); break;
    case 'checkout': checkout(); break;
    case 'maps': window.open('https://www.google.com/maps/search/?api=1&query=Jl.+Raden+Saleh+No.+18+Cikini+Jakarta', '_blank', 'noopener,noreferrer'); break;
  }
});

document.addEventListener('input', (e) => {
  if (e.target.id === 'searchInput') { menuState.search = e.target.value; updateMenu(); }
});

/* ---------- Mulai ---------- */
document.getElementById('root').innerHTML =
  `<div class="app">${Header()}<div id="view"></div>${Footer()}</div>`;
renderView();
