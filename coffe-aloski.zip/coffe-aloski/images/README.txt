Taruh gambar milik Anda di folder ini (contoh: hero.jpg, kopi-aloski.jpg).
Lalu buka js/data.js dan ganti URL gambar dengan path lokal, misalnya:
  hero: 'images/hero.jpg'
