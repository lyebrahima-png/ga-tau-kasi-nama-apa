# FasilitasKita — Prototype HTML, CSS, JavaScript + PHP API + MySQL

## Menjalankan di XAMPP
1. Salin folder `FasilitasKita` ke `C:\xampp\htdocs\`.
2. Jalankan Apache dan MySQL.
3. Buka `http://localhost/phpmyadmin`, pilih menu **Import**, lalu impor `database.sql`.
4. Buka `http://localhost/FasilitasKita/`.
5. Jika MySQL kamu memakai password, sesuaikan `config/database.php`.

## Akun demo
- Admin: `admin@fasilitaskita.test`
- Petugas: `petugas@fasilitaskita.test`
- Password keduanya: `password`

## Fitur prototype
- Landing page dan statistik dari database.
- Direktori fasilitas dengan pencarian dan filter.
- Tampilan peta Leaflet/OpenStreetMap.
- Form laporan kerusakan dan unggah foto.
- Pelacakan laporan menggunakan nomor tiket dan timeline.
- Login admin/petugas dan dashboard untuk melihat laporan serta mengubah status.
- Struktur tabel dasar untuk users, wilayah/fasilitas, reports, inspeksi, pemeliharaan, jadwal, notifikasi, dan foto.

## Penting
Frontend menggunakan HTML, CSS, dan JavaScript. PHP hanya menjadi API penghubung ke MySQL karena browser tidak boleh mengakses database secara langsung. Semua data fasilitas di SQL adalah data contoh/demo, bukan data resmi. Sebelum produksi, tambahkan CSRF protection, pembatasan percobaan login, validasi file lebih ketat, audit log, dan HTTPS.
