<?php
require 'common.php';
$q=trim($_GET['q']??''); $cat=trim($_GET['category']??''); $district=trim($_GET['district']??''); $condition=trim($_GET['condition']??'');
$sql="SELECT * FROM facilities WHERE 1=1"; $args=[];
if($q!==''){$sql.=" AND name LIKE ?";$args[]="%$q%";}
if($cat!==''){$sql.=" AND category=?";$args[]=$cat;}
if($district!==''){$sql.=" AND district=?";$args[]=$district;}
if($condition!==''){$sql.=" AND condition_status=?";$args[]=$condition;}
$sql.=" ORDER BY id DESC";
$s=$pdo->prepare($sql);$s->execute($args);out($s->fetchAll());
