<?php require 'common.php';
$f=(int)$pdo->query("SELECT COUNT(*) FROM facilities")->fetchColumn();
$g=(int)$pdo->query("SELECT COUNT(*) FROM facilities WHERE condition_status='Baik'")->fetchColumn();
$r=(int)$pdo->query("SELECT COUNT(*) FROM reports")->fetchColumn();
$d=(int)$pdo->query("SELECT COUNT(*) FROM reports WHERE status='Perbaikan Selesai'")->fetchColumn();
$bad=(int)$pdo->query("SELECT COUNT(*) FROM facilities WHERE condition_status<>'Baik'")->fetchColumn();
out(['facilities'=>$f,'good'=>$g,'reports'=>$r,'completed'=>$d,'damaged'=>$bad]);
