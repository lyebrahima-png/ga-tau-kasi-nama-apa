<?php
require 'common.php';
$method=$_SERVER['REQUEST_METHOD'];
if($method==='POST'){
 $reporter=trim($_POST['reporter']??'');$facility=trim($_POST['facility_name']??'');$category=trim($_POST['category']??'');$severity=trim($_POST['severity']??'');$district=trim($_POST['district']??'');$village=trim($_POST['village']??'');$location=trim($_POST['location']??'');$description=trim($_POST['description']??'');
 if(!$reporter||!$facility||!$category||!$severity||!$district||!$village||!$location||!$description)out(['error'=>'Semua kolom wajib harus diisi.'],422);
 $photo=null;
 if(isset($_FILES['photo'])&&$_FILES['photo']['error']===UPLOAD_ERR_OK){
  if($_FILES['photo']['size']>5*1024*1024)out(['error'=>'Ukuran foto maksimal 5 MB.'],422);
  $mime=mime_content_type($_FILES['photo']['tmp_name']);$ext=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'][$mime]??null;
  if(!$ext)out(['error'=>'Format foto harus JPG, PNG, atau WEBP.'],422);
  if(!is_dir(__DIR__.'/../uploads'))mkdir(__DIR__.'/../uploads',0775,true);
  $filename=bin2hex(random_bytes(12)).'.'.$ext;
  move_uploaded_file($_FILES['photo']['tmp_name'],__DIR__.'/../uploads/'.$filename);$photo='uploads/'.$filename;
 }
 $ticket='FK-'.date('ymd').'-'.strtoupper(bin2hex(random_bytes(3)));
 $s=$pdo->prepare("INSERT INTO reports(ticket,reporter,facility_name,category,severity,district,village,location,description,photo,status,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,NOW())");
 $s->execute([$ticket,$reporter,$facility,$category,$severity,$district,$village,$location,$description,$photo,'Laporan Diterima']);
 out(['success'=>true,'ticket'=>$ticket]);
}
if($method==='GET'){
 if(isset($_GET['ticket'])){
  $s=$pdo->prepare("SELECT * FROM reports WHERE ticket=?");$s->execute([trim($_GET['ticket'])]);$r=$s->fetch();if(!$r)out(['error'=>'Nomor tiket tidak ditemukan.'],404);
  $h=$pdo->prepare("SELECT status,note,created_at FROM report_updates WHERE report_id=? ORDER BY id");$h->execute([$r['id']]);$r['history']=$h->fetchAll();out($r);
 }
 if(!logged())out(['error'=>'Silakan masuk terlebih dahulu.'],401);
 $s=$pdo->query("SELECT * FROM reports ORDER BY created_at DESC");out($s->fetchAll());
}
if($method==='PATCH'){
 if(!logged()||!in_array(logged()['role'],['admin','petugas']))out(['error'=>'Akses ditolak.'],403);
 $body=json_decode(file_get_contents('php://input'),true);$id=(int)($body['id']??0);$status=$body['status']??'';
 $allowed=['Laporan Diterima','Sedang Diverifikasi','Menunggu Penugasan Petugas','Dalam Proses Perbaikan','Perbaikan Selesai','Ditolak'];
 if(!in_array($status,$allowed,true))out(['error'=>'Status tidak valid.'],422);
 $pdo->beginTransaction();$s=$pdo->prepare("UPDATE reports SET status=? WHERE id=?");$s->execute([$status,$id]);$u=$pdo->prepare("INSERT INTO report_updates(report_id,status,note,created_at) VALUES(?,?,?,NOW())");$u->execute([$id,$status,'Status diperbarui oleh '.logged()['name']]);$pdo->commit();out(['success'=>true]);
}
out(['error'=>'Metode tidak didukung.'],405);
