<?php
require 'common.php';
if($_SERVER['REQUEST_METHOD']==='GET'){if(!logged())out(['user'=>null]);out(['user'=>logged()]);}
$body=json_decode(file_get_contents('php://input'),true)??[];$email=trim($body['email']??'');$password=$body['password']??'';
$s=$pdo->prepare("SELECT id,name,email,password,role FROM users WHERE email=?");$s->execute([$email]);$u=$s->fetch();
if(!$u||!password_verify($password,$u['password']))out(['error'=>'Email atau password salah.'],401);
unset($u['password']);$_SESSION['user']=$u;out(['success'=>true,'user'=>$u]);
