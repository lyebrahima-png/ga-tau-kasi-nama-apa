/* LangsaTrip — perilaku interaktif (migrasi dari React/App.tsx ke JavaScript biasa) */
(function () {
  'use strict';

  var ICON_ATTRS = 'viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"';
  var ICONS = {
    menu:  '<svg width="22" height="22" ' + ICON_ATTRS + '><path d="M4 7h16M4 12h16M4 17h16" /></svg>',
    close: '<svg width="22" height="22" ' + ICON_ATTRS + '><path d="m6 6 12 12M18 6 6 18" /></svg>',
    check34: '<svg width="34" height="34" ' + ICON_ATTRS + '><path d="m5 12 4 4L19 6" /></svg>'
  };

  var root = document.getElementById('root');
  var pages = {};
  var pristine = {};
  var current = 'landing';

  // Simpan kondisi awal tiap halaman agar setiap kali halaman dibuka
  // statusnya segar kembali (seperti komponen React yang di-mount ulang).
  root.querySelectorAll('.page').forEach(function (el) {
    var name = el.getAttribute('data-page');
    pages[name] = el;
    pristine[name] = el.innerHTML;
  });

  function navigate(next) {
    if (next !== current && pages[next]) {
      pages[current].hidden = true;
      pages[next].innerHTML = pristine[next];
      pages[next].hidden = false;
      current = next;
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function scrollToSection(id) {
    var nav = document.querySelector('.nav-links');
    var btn = document.querySelector('.menu-button');
    if (nav) nav.classList.remove('open');
    if (btn) btn.innerHTML = ICONS.menu;
    var target = document.getElementById(id);
    if (target) target.scrollIntoView({ behavior: 'smooth' });
  }

  function toggleMenu() {
    var nav = document.querySelector('.nav-links');
    var btn = document.querySelector('.menu-button');
    var open = nav.classList.toggle('open');
    btn.innerHTML = open ? ICONS.close : ICONS.menu;
  }

  document.addEventListener('click', function (e) {
    var t = e.target;
    if (!(t instanceof Element)) return;

    var menu = t.closest('[data-menu-toggle]');
    if (menu) { toggleMenu(); return; }

    var scroller = t.closest('[data-scroll]');
    if (scroller) { scrollToSection(scroller.getAttribute('data-scroll')); return; }

    var arrow = t.closest('[data-carousel]');
    if (arrow) {
      var track = arrow.closest('.container').querySelector('.destination-carousel');
      if (track) track.scrollBy({ left: Number(arrow.getAttribute('data-carousel')), behavior: 'smooth' });
      return;
    }

    var nav = t.closest('[data-navigate]');
    if (nav) {
      e.preventDefault(); // mencegah tombol di dalam <form> ikut men-submit
      navigate(nav.getAttribute('data-navigate'));
    }
  });

  document.addEventListener('submit', function (e) {
    var form = e.target;
    e.preventDefault();

    if (form.closest('#page-itinerary')) {
      form.innerHTML =
        '<div class="success-state"><span>' + ICONS.check34 + '</span>' +
        '<h2>Itinerary siap!</h2>' +
        '<p>Rencana 2 hari di Langsa sudah berhasil disusun.</p>' +
        '<button class="btn btn-primary" data-navigate="user">Lihat di beranda</button></div>';
      return;
    }

    if (form.closest('#page-budget')) {
      var result = document.querySelector('#page-budget .budget-result');
      result.classList.add('visible');
      result.querySelector('h2').textContent = 'Rp325.000';
      var values = ['Rp180.000', 'Rp25.000', 'Rp120.000'];
      result.querySelectorAll('.budget-breakdown strong').forEach(function (el, i) {
        el.textContent = values[i];
      });
    }
  });
})();
