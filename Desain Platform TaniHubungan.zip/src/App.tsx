import { useState } from 'react';

type Role = 'Publik' | 'Petani' | 'Pembeli' | 'Petugas' | 'Admin';
type IconName =
  | 'leaf' | 'search' | 'bell' | 'user' | 'home' | 'tag' | 'basket' | 'file'
  | 'shield' | 'chart' | 'users' | 'settings' | 'check' | 'clock' | 'map'
  | 'arrow' | 'menu' | 'plus' | 'filter' | 'warning' | 'message' | 'rice';

const heroPhoto = 'https://images.unsplash.com/photo-1520052203542-d3095f1b6cf0?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=88&w=1400';
const farmPhoto = 'https://images.unsplash.com/photo-1530507629858-e4977d30e9e0?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=900';

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  const paths: Record<IconName, React.ReactNode> = {
    leaf: <><path d="M20 4C12 4 5 8 5 15c0 3 2 5 5 5 7 0 10-8 10-16Z"/><path d="M4 21c3-6 7-9 12-12"/></>,
    search: <><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></>,
    bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9Z"/><path d="M10 21h4"/></>,
    user: <><circle cx="12" cy="8" r="4"/><path d="M4 21c0-5 3-8 8-8s8 3 8 8"/></>,
    home: <><path d="m3 11 9-8 9 8"/><path d="M5 10v11h14V10M9 21v-7h6v7"/></>,
    tag: <><path d="M20 13 13 20 4 11V4h7l9 9Z"/><circle cx="8.5" cy="8.5" r="1"/></>,
    basket: <><path d="m4 10 2 10h12l2-10H4Z"/><path d="m9 10 3-6 3 6M3 10h18"/></>,
    file: <><path d="M6 3h9l4 4v14H6V3Z"/><path d="M14 3v5h5M9 13h6M9 17h6"/></>,
    shield: <><path d="M12 22s8-3 8-10V5l-8-3-8 3v7c0 7 8 10 8 10Z"/><path d="m9 12 2 2 4-5"/></>,
    chart: <><path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/></>,
    users: <><path d="M16 21v-2c0-3-2-5-5-5H6c-3 0-5 2-5 5v2"/><circle cx="8.5" cy="7" r="4"/><path d="M18 9a3 3 0 1 0-2-5M20 21v-2c0-2-1-4-3-4"/></>,
    settings: <><circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.1-1l2-1-2-4-2 1a8 8 0 0 0-2-1l-.3-3h-5l-.3 3a8 8 0 0 0-2 1l-2-1-2 4 2 1a7 7 0 0 0 0 2l-2 1 2 4 2-1a8 8 0 0 0 2 1l.3 3h5l.3-3a8 8 0 0 0 2-1l2 1 2-4-2-1a7 7 0 0 0 .1-1Z"/></>,
    check: <path d="m5 12 4 4L19 6"/>,
    clock: <><circle cx="12" cy="12" r="9"/><path d="M12 7v6l4 2"/></>,
    map: <><path d="M20 10c0 5-8 12-8 12S4 15 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2"/></>,
    arrow: <><path d="M5 12h14M14 7l5 5-5 5"/></>,
    menu: <><path d="M4 6h16M4 12h16M4 18h16"/></>,
    plus: <><path d="M12 5v14M5 12h14"/></>,
    filter: <path d="M3 5h18l-7 8v6l-4 2v-8L3 5Z"/>,
    warning: <><path d="M12 3 2 21h20L12 3Z"/><path d="M12 9v5M12 18h.01"/></>,
    message: <><path d="M21 15a4 4 0 0 1-4 4H8l-5 3 1-6a8 8 0 0 1-1-4V8a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4v7Z"/><path d="M8 10h8M8 14h5"/></>,
    rice: <><path d="M12 21V4M12 7c-4 0-5-3-5-4 4 0 5 3 5 4ZM12 11c4 0 5-3 5-4-4 0-5 3-5 4ZM12 15c-4 0-5-3-5-4 4 0 5 3 5 4Z"/></>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden>{paths[name]}</svg>;
}

function Logo({ light = false }: { light?: boolean }) {
  return <div className={`logo ${light ? 'light' : ''}`}><span className="logo-mark"><Icon name="leaf" size={24}/></span><span>Tani<span>Hubungan</span></span></div>;
}

function Badge({ children, tone = 'green' }: { children: React.ReactNode; tone?: 'green'|'yellow'|'gray'|'red' }) {
  return <span className={`badge ${tone}`}>{tone === 'green' && <Icon name="check" size={13}/>} {children}</span>;
}

const prices = [
  { crop: 'Beras Medium', price: 'Rp13.200', unit: '/ kg', market: 'Pasar Induk Cipinang, Jakarta', source: 'PIBC Jakarta', date: '18 Juni 2025', status: 'Terbaru', tone: 'green' as const, icon: 'rice' as IconName },
  { crop: 'Cabai Merah', price: 'Rp46.500', unit: '/ kg', market: 'Pasar Caringin, Bandung', source: 'Dinas Pangan Jabar', date: '17 Juni 2025', status: 'Terbaru', tone: 'green' as const, icon: 'leaf' as IconName },
  { crop: 'Jagung Pipil', price: 'Rp5.800', unit: '/ kg', market: 'Pasar Wates, Yogyakarta', source: 'Petugas Lapangan', date: '14 Juni 2025', status: 'Perlu diperbarui', tone: 'yellow' as const, icon: 'rice' as IconName },
  { crop: 'Bawang Merah', price: 'Rp34.000', unit: '/ kg', market: 'Pasar Brebes, Jawa Tengah', source: 'Bapanas', date: '8 Juni 2025', status: 'Data lama', tone: 'gray' as const, icon: 'leaf' as IconName },
];

function PriceCard({ item, compact = false }: { item: typeof prices[number]; compact?: boolean }) {
  return <article className={`price-card ${compact ? 'compact' : ''}`}>
    <div className="price-head"><span className="crop-icon"><Icon name={item.icon}/></span><Badge tone={item.tone}>{item.status}</Badge></div>
    <h3>{item.crop}</h3><div className="price"><strong>{item.price}</strong> <span>{item.unit}</span></div>
    <div className="meta"><span><Icon name="map" size={15}/>{item.market}</span><span><Icon name="shield" size={15}/>{item.source}</span><span><Icon name="clock" size={15}/>Dicatat {item.date}</span></div>
    {item.tone === 'gray' && <div className="stale"><Icon name="warning" size={15}/> Bukan harga terkini</div>}
  </article>;
}

function RoleSwitcher({ role, setRole }: { role: Role; setRole: (r: Role) => void }) {
  return <div className="role-switcher"><span>Pratinjau peran</span>{(['Publik','Petani','Pembeli','Petugas','Admin'] as Role[]).map(r => <button className={role === r ? 'active' : ''} onClick={() => setRole(r)} key={r}>{r}</button>)}</div>;
}

function Landing({ setRole }: { setRole: (r: Role) => void }) {
  return <div className="landing">
    <nav className="public-nav"><Logo/><div className="nav-links"><a href="#harga">Harga Komoditas</a><a href="#fitur">Cara Kerja</a><a href="#keamanan">Keamanan</a></div><div className="nav-actions"><button className="btn text" onClick={() => setRole('Petani')}>Masuk</button><button className="btn primary" onClick={() => setRole('Petani')}>Daftar Sekarang</button></div></nav>
    <main>
      <section className="hero">
        <div className="hero-copy"><div className="eyebrow"><span></span> Tumbuh dan terhubung bersama</div><h1>Harga Transparan,<br/>Panen Terhubung <em>ke Pembeli</em></h1><p>Akses informasi harga pasar yang terpercaya dan temukan pembeli lokal untuk hasil panen Anda, tanpa perantara yang rumit.</p><div className="hero-actions"><button className="btn primary large" onClick={() => setRole('Petani')}><Icon name="leaf"/> Daftar sebagai Petani</button><button className="btn secondary large" onClick={() => setRole('Pembeli')}><Icon name="basket"/> Daftar sebagai Pembeli</button></div><div className="trust-row"><span><Icon name="check" size={16}/> Gratis untuk bergabung</span><span><Icon name="check" size={16}/> Data terverifikasi</span></div></div>
        <div className="hero-visual"><img src={heroPhoto} alt="Petani merawat sawah di Indonesia"/><div className="floating-price"><div><span>Harga hari ini</span><Badge>Terbaru</Badge></div><strong>Beras Medium</strong><b>Rp13.200 <small>/ kg</small></b><span>Pasar Induk Cipinang</span></div><div className="verified-chip"><span><Icon name="shield"/></span><div><b>Petani terverifikasi</b><small>Aman untuk bertransaksi</small></div></div></div>
      </section>

      <section className="stats-strip"><div><b>12.480+</b><span>Petani terhubung</span></div><div><b>3.240+</b><span>Pembeli aktif</span></div><div><b>28</b><span>Provinsi terjangkau</span></div><div><b>96%</b><span>Data harga terverifikasi</span></div></section>

      <section id="fitur" className="section"><div className="section-heading"><span className="kicker">FITUR UTAMA</span><h2>Satu tempat untuk panen yang lebih menguntungkan</h2><p>Informasi yang jelas dan koneksi yang tepat untuk membantu keputusan usaha tani Anda.</p></div>
        <div className="feature-grid">{[
          ['tag','Informasi Harga Komoditas','Bandingkan harga berdasarkan komoditas, pasar, tanggal, dan sumber data yang jelas.'],
          ['rice','Papan Penawaran Hasil Panen','Catat komoditas, jumlah, dan perkiraan waktu panen agar mudah ditemukan pembeli.'],
          ['message','Direktori Pembeli & Negosiasi','Temukan calon pembeli, terima atau tolak penawaran, lalu negosiasi aman di aplikasi.']
        ].map((f,i)=><article className="feature-card" key={f[1]}><span className="feature-no">0{i+1}</span><div className="feature-icon"><Icon name={f[0] as IconName} size={28}/></div><h3>{f[1]}</h3><p>{f[2]}</p><a>Pelajari selengkapnya <Icon name="arrow" size={17}/></a></article>)}</div>
      </section>

      <section id="harga" className="section prices-section"><div className="heading-row"><div><span className="kicker">HARGA PASAR TERKINI</span><h2>Pantau harga sebelum menjual</h2></div><button className="btn secondary">Lihat semua harga <Icon name="arrow" size={17}/></button></div><div className="price-grid">{prices.map(p=><PriceCard item={p} key={p.crop}/>)}</div></section>

      <section className="section how"><div className="how-image"><img src={farmPhoto} alt="Petani memanen padi"/><div className="photo-note"><b>Panen lebih pasti</b><span>Dengan pembeli yang sudah terhubung</span></div></div><div className="how-copy"><span className="kicker">CARA KERJA</span><h2>Dari lahan hingga pembeli, semudah 1—2—3</h2>{[['1','Daftar dan lengkapi profil','Pilih peran sebagai petani atau pembeli, lalu verifikasi profil Anda.'],['2','Pasang atau cari penawaran','Petani mencatat hasil panen. Pembeli mencari sesuai kebutuhan.'],['3','Sepakati transaksi','Negosiasi aman di aplikasi dan selesaikan transaksi dengan jelas.']].map(x=><div className="step" key={x[0]}><span>{x[0]}</span><div><h3>{x[1]}</h3><p>{x[2]}</p></div></div>)}</div></section>

      <section id="keamanan" className="security"><div><span className="kicker light">KEPERCAYAAN & KEAMANAN</span><h2>Bertransaksi dengan lebih tenang</h2><p>Identitas mitra diverifikasi, sumber harga selalu ditampilkan, dan percakapan tersimpan aman tanpa membagikan nomor pribadi.</p></div><div className="security-list"><span><Icon name="shield"/> Verifikasi identitas mitra</span><span><Icon name="clock"/> Penanda usia data harga</span><span><Icon name="message"/> Negosiasi aman di aplikasi</span></div></section>
      <section className="closing"><span className="crop-icon"><Icon name="rice"/></span><h2>Siap menghubungkan panen Anda?</h2><p>Bergabung dengan ribuan pelaku pertanian Indonesia yang tumbuh bersama.</p><button className="btn white large" onClick={() => setRole('Petani')}>Mulai sekarang <Icon name="arrow"/></button></section>
    </main>
    <footer><Logo light/><p>Menghubungkan petani dan pembeli lokal melalui informasi yang transparan.</p><div><a>Tentang Kami</a><a>Bantuan</a><a>Kebijakan Privasi</a></div><small>© 2025 TaniHubungan. Dibuat untuk pertanian Indonesia.</small></footer>
  </div>;
}

const navs: Record<Exclude<Role,'Publik'>, string[]> = {
  Petani: ['Dashboard','Informasi Harga','Buat Penawaran','Penawaran Saya','Calon Pembeli','Status Penjualan'],
  Pembeli: ['Dashboard','Informasi Harga','Cari Hasil Panen','Penawaran Saya','Negosiasi','Kesepakatan'],
  Petugas: ['Dashboard','Antrean Penawaran','Verifikasi Petani','Sumber Data Harga','Perbarui Data Harga','Laporan Data Tidak Sesuai','Riwayat Verifikasi'],
  Admin: ['Dashboard','Kelola Akun','Verifikasi Mitra','Kategori Komoditas','Sumber Harga','Pantau Penawaran','Aktivitas Pembeli','Laporan Penipuan','Laporan Perdagangan'],
};

const navIcon = (n: string): IconName => n.includes('Harga') ? 'tag' : n.includes('Penawaran') ? 'basket' : n.includes('Verifikasi') ? 'shield' : n.includes('Laporan') ? 'file' : n.includes('Akun') || n.includes('Petani') ? 'users' : n === 'Dashboard' ? 'home' : n.includes('Negosiasi') ? 'message' : 'chart';

function TopHeader({ role, setRole, page }: { role: Role; setRole:(r:Role)=>void; page:string }) {
  return <header className="app-header"><div><span className="breadcrumb">{role} / {page}</span><h2>{page}</h2></div><div className="header-actions"><label className="search"><Icon name="search"/><input placeholder="Cari di TaniHubungan..."/></label><button className="icon-btn"><Icon name="bell"/><i/></button><button className="profile"><span>{role === 'Admin' ? 'AR' : role === 'Petugas' ? 'DW' : role === 'Pembeli' ? 'SM' : 'BS'}</span><div><b>{role === 'Admin' ? 'Arif Rahman' : role === 'Petugas' ? 'Dewi Wulandari' : role === 'Pembeli' ? 'Sari Makmur' : 'Budi Santoso'}</b><small>{role}</small></div><Icon name="menu" size={17}/></button><button className="back-public" onClick={()=>setRole('Publik')}>Keluar</button></div></header>;
}

function Sidebar({ role, page, setPage }: { role: 'Petugas'|'Admin'; page:string; setPage:(p:string)=>void }) {
  return <aside className="sidebar"><Logo light/><div className="side-role">{role === 'Admin' ? 'Pusat kendali platform' : 'Verifikator data pertanian'}</div><nav>{navs[role].map(n=><button key={n} className={page===n?'active':''} onClick={()=>setPage(n)}><Icon name={navIcon(n)}/><span>{n}</span>{n === 'Antrean Penawaran' && <b>12</b>}</button>)}</nav><div className="side-help"><Icon name="message"/><b>Butuh bantuan?</b><span>Hubungi pusat dukungan</span><button>Hubungi dukungan</button></div></aside>;
}

function UserNav({ role, page, setPage, setRole }: { role:'Petani'|'Pembeli'; page:string; setPage:(p:string)=>void; setRole:(r:Role)=>void }) {
  return <><nav className="user-nav"><Logo/><div>{navs[role].slice(0,5).map(n=><button className={page===n?'active':''} key={n} onClick={()=>setPage(n)}>{n}</button>)}</div><div className="user-nav-actions"><button className="icon-btn"><Icon name="bell"/><i/></button><button className="avatar">{role==='Petani'?'BS':'SM'}</button><button className="exit" onClick={()=>setRole('Publik')}>Keluar</button></div></nav></>;
}

function StatCard({ icon, label, value, note, tone='green' }: {icon:IconName;label:string;value:string;note:string;tone?:string}) {
  return <article className="stat-card"><div className={`stat-icon ${tone}`}><Icon name={icon}/></div><div className="stat-label">{label}</div><b>{value}</b><span>{note}</span></article>;
}

function BarChart() {
  const vals=[42,58,47,72,64,84,76];
  return <div className="bar-chart"><div className="axis"><span>80</span><span>60</span><span>40</span><span>20</span><span>0</span></div><div className="bars">{vals.map((v,i)=><div key={i}><span style={{height:`${v}%`}}></span><small>{['Sen','Sel','Rab','Kam','Jum','Sab','Min'][i]}</small></div>)}</div></div>;
}

function Table({ type='offer' }: { type?:'offer'|'account'|'verify'|'price'|'report' }) {
  const maps = {
    offer: { heads:['Komoditas','Petani','Wilayah','Jumlah','Tanggal panen','Status','Aksi'], rows:[['Cabai Merah','Mulyono','Garut, Jawa Barat','2,5 ton','25 Jun 2025','Menunggu','Periksa'],['Jagung Pipil','Sutrisno','Bantul, DIY','4 ton','28 Jun 2025','Perlu Revisi','Periksa'],['Bawang Merah','Sri Wahyuni','Brebes, Jateng','1,8 ton','2 Jul 2025','Menunggu','Periksa'],['Beras Medium','H. Ridwan','Subang, Jabar','8 ton','5 Jul 2025','Disetujui','Lihat']]},
    account: { heads:['Nama pengguna','Peran','Wilayah','Terdaftar','Status','Aksi'], rows:[['Budi Santoso','Petani','Garut, Jawa Barat','18 Jun 2025','Aktif','Lihat'],['CV Sari Makmur','Pembeli','Bandung, Jawa Barat','17 Jun 2025','Menunggu','Periksa'],['Sri Wahyuni','Petani','Brebes, Jawa Tengah','16 Jun 2025','Aktif','Lihat'],['UD Pangan Jaya','Pembeli','Jakarta Timur','14 Jun 2025','Diblokir','Lihat']]},
    verify: { heads:['ID Verifikasi','Objek','Petugas','Tanggal','Hasil','Catatan'], rows:[['VRF-250618-42','Cabai Merah — Mulyono','Dewi Wulandari','18 Jun 2025','Disetujui','Data lengkap'],['VRF-250618-41','Beras Medium — H. Ridwan','Agus Pratama','18 Jun 2025','Disetujui','Sesuai foto'],['VRF-250617-39','Jagung — Sutrisno','Dewi Wulandari','17 Jun 2025','Perlu Revisi','Satuan belum jelas'],['VRF-250617-38','Bawang — Sri Wahyuni','Agus Pratama','17 Jun 2025','Terkirim','Ke admin']]},
    price: { heads:['Komoditas','Pasar / Lokasi','Harga','Sumber','Pencatatan','Status','Aksi'], rows:[['Beras Medium','Pasar Induk Cipinang','Rp13.200 / kg','PIBC Jakarta','18 Jun 2025','Terbaru','Ubah'],['Cabai Merah','Pasar Caringin','Rp46.500 / kg','Dinas Pangan Jabar','17 Jun 2025','Terbaru','Ubah'],['Jagung Pipil','Pasar Wates','Rp5.800 / kg','Petugas Lapangan','14 Jun 2025','Perlu diperbarui','Ubah'],['Bawang Merah','Pasar Brebes','Rp34.000 / kg','Bapanas','8 Jun 2025','Data lama','Ubah']]},
    report: { heads:['ID Laporan','Pelapor','Objek','Jenis masalah','Tanggal','Status','Aksi'], rows:[['LPR-1028','CV Tani Sejahtera','Akun M. Yusuf','Dugaan penipuan','18 Jun 2025','Prioritas','Selidiki'],['LPR-1027','Sari Makmur','Penawaran #2194','Data tidak sesuai','17 Jun 2025','Diproses','Lihat'],['LPR-1026','Budi Santoso','Akun UD Karya','Penyalahgunaan','16 Jun 2025','Baru','Selidiki'],['LPR-1025','Dewi Wulandari','Harga Cabai','Sumber tidak valid','15 Jun 2025','Selesai','Lihat']]},
  };
  const d=maps[type];
  const tone=(s:string)=>s.includes('Disetujui')||s==='Aktif'||s==='Terbaru'||s==='Selesai'||s==='Terkirim'?'green':s.includes('Blok')||s==='Prioritas'?'red':s.includes('Revisi')||s.includes('diperbarui')||s==='Diproses'?'yellow':'gray';
  return <div className="table-wrap"><table><thead><tr>{d.heads.map(h=><th key={h}>{h}</th>)}</tr></thead><tbody>{d.rows.map((r,i)=><tr key={i}>{r.map((c,j)=><td key={j}>{j===d.heads.length-2?<Badge tone={tone(c) as any}>{c}</Badge>:j===d.heads.length-1?<button className="table-action">{c} <Icon name="arrow" size={14}/></button>:j===0?<b>{c}</b>:c}</td>)}</tr>)}</tbody></table><div className="pagination"><span>Menampilkan 1–4 dari 24 data</span><div><button>‹</button><button className="current">1</button><button>2</button><button>3</button><button>›</button></div></div></div>;
}

function Filters({ price=false }: {price?:boolean}) {
  return <div className="filters"><label><Icon name="search"/><input placeholder={price?'Cari komoditas atau pasar...':'Cari nama, komoditas, atau ID...'}/></label><button><Icon name="filter"/> Semua {price?'komoditas':'status'}⌄</button><button><Icon name="map"/> Semua wilayah⌄</button><button><Icon name="clock"/> 30 hari terakhir⌄</button></div>;
}

function AdminDashboard() {
  return <><div className="welcome"><div><span>Rabu, 18 Juni 2025</span><h1>Selamat pagi, Arif</h1><p>Pantau aktivitas dan kesehatan platform TaniHubungan hari ini.</p></div><button className="btn primary"><Icon name="file"/> Unduh ringkasan</button></div><div className="stats-grid"><StatCard icon="leaf" label="Total Petani" value="12.480" note="↑ 8,2% bulan ini"/><StatCard icon="basket" label="Total Pembeli" value="3.240" note="↑ 5,4% bulan ini"/><StatCard icon="tag" label="Penawaran Aktif" value="1.864" note="142 baru minggu ini"/><StatCard icon="chart" label="Transaksi Bulan Ini" value="Rp2,8 M" note="↑ 12,6% dari Mei"/></div><div className="dash-grid"><section className="panel activity"><div className="panel-title"><div><h3>Aktivitas perdagangan</h3><p>Nilai transaksi 7 hari terakhir</p></div><select><option>7 hari terakhir</option></select></div><BarChart/></section><section className="panel fraud"><div className="panel-title"><div><h3>Laporan penipuan terbaru</h3><p>Perlu ditindaklanjuti</p></div><Badge tone="red">3 prioritas</Badge></div>{['Dugaan pembayaran palsu','Komoditas tidak sesuai','Akun mencurigakan'].map((x,i)=><div className="fraud-row" key={x}><span className="alert-icon"><Icon name="warning"/></span><div><b>{x}</b><small>{['LPR-1028 • 12 menit lalu','LPR-1027 • 2 jam lalu','LPR-1026 • kemarin'][i]}</small></div><button><Icon name="arrow"/></button></div>)}</section></div><section className="panel"><div className="panel-title"><div><h3>Akun menunggu verifikasi</h3><p>Periksa kelengkapan mitra baru sebelum menyetujui</p></div><button className="link-btn">Lihat semua <Icon name="arrow" size={16}/></button></div><Table type="account"/></section></>;
}

function OfficerDashboard() {
  return <><div className="welcome"><div><span>Rabu, 18 Juni 2025</span><h1>Selamat pagi, Dewi</h1><p>Berikut ringkasan tugas verifikasi data pertanian Anda.</p></div><button className="btn primary"><Icon name="check"/> Mulai verifikasi</button></div><div className="stats-grid"><StatCard icon="clock" label="Perlu Diperiksa" value="24" note="12 prioritas hari ini" tone="yellow"/><StatCard icon="check" label="Diverifikasi Hari Ini" value="18" note="Target harian: 25"/><StatCard icon="tag" label="Harga Perlu Diperbarui" value="7" note="2 data kedaluwarsa" tone="yellow"/><StatCard icon="warning" label="Dilaporkan Tidak Sesuai" value="3" note="Perlu tindak lanjut" tone="red"/></div><div className="dash-grid"><section className="panel"><div className="panel-title"><div><h3>Verifikasi 7 hari terakhir</h3><p>Jumlah data yang selesai diperiksa</p></div><Badge>126 selesai</Badge></div><BarChart/></section><section className="panel expiry"><div className="panel-title"><div><h3>Harga kedaluwarsa</h3><p>Segera perbarui sumber data</p></div></div>{prices.slice(2).map(p=><PriceCard item={p} compact key={p.crop}/>)}</section></div><section className="panel"><div className="panel-title"><div><h3>Antrean terbaru</h3><p>Penawaran yang menunggu pemeriksaan</p></div><button className="link-btn">Lihat semua <Icon name="arrow" size={16}/></button></div><Table/></section></>;
}

function PricePage() {
  return <><div className="welcome"><div><span>DATA HARGA TERPERCAYA</span><h1>Informasi Harga Komoditas</h1><p>Bandingkan harga terbaru dari pasar dan sumber yang terverifikasi.</p></div><button className="btn secondary"><Icon name="bell"/> Atur pengingat harga</button></div><Filters price/><div className="price-grid app-prices">{prices.map(p=><PriceCard item={p} key={p.crop}/>)}</div><section className="panel history"><div className="panel-title"><div><h3>Riwayat harga — Beras Medium</h3><p>Pasar Induk Cipinang • Harga per kg • 30 hari</p></div><div className="tabs"><button className="active">30 hari</button><button>3 bulan</button><button>1 tahun</button></div></div><div className="line-chart"><div className="chart-labels"><span>Rp14 rb</span><span>Rp13 rb</span><span>Rp12 rb</span><span>Rp11 rb</span></div><svg viewBox="0 0 900 210" preserveAspectRatio="none"><path className="area" d="M0 180 C80 175 100 120 170 130 S270 80 350 105 S480 55 560 80 S680 30 760 60 S850 30 900 20 L900 210 L0 210Z"/><path className="line" d="M0 180 C80 175 100 120 170 130 S270 80 350 105 S480 55 560 80 S680 30 760 60 S850 30 900 20"/></svg></div></section></>;
}

function OfferWizard({ role }: {role:'Petani'|'Pembeli'}) {
  const [step,setStep]=useState(1); const isBuyer=role==='Pembeli';
  return <div className="form-page"><div className="form-intro"><span>{isBuyer?'PENAWARAN PEMBELIAN':'LANGKAH MUDAH'}</span><h1>{isBuyer?'Ajukan Penawaran Pembelian':'Buat Penawaran Hasil Panen'}</h1><p>{isBuyer?'Ajukan jumlah dan harga yang wajar kepada petani.':'Isi informasi hasil panen Anda agar mudah ditemukan pembeli.'}</p></div><div className="stepper">{['Komoditas','Jumlah & satuan','Waktu & harga','Foto & tinjau'].map((x,i)=><div className={`${step===i+1?'active':''} ${step>i+1?'done':''}`} key={x}><span>{step>i+1?<Icon name="check" size={16}/>:i+1}</span><b>{x}</b></div>)}</div><section className="form-card"><div className="form-card-head"><span>Langkah {step} dari 4</span><h2>{['Pilih komoditas hasil panen','Tentukan jumlah hasil panen','Atur waktu panen dan harga','Unggah foto dan tinjau'][step-1]}</h2><p>{['Pilih jenis komoditas yang akan Anda tawarkan.','Masukkan perkiraan jumlah yang tersedia.','Berikan jadwal dan harga harapan yang jelas.','Foto yang baik membantu pembeli lebih percaya.'][step-1]}</p></div>{step===1&&<div className="commodity-grid">{['Cabai Merah','Beras','Jagung','Bawang Merah','Tomat','Kentang'].map((x,i)=><button className={i===0?'selected':''} key={x}><span><Icon name={i<2?'rice':'leaf'}/></span><b>{x}</b>{i===0&&<i><Icon name="check" size={14}/></i>}</button>)}</div>}{step===2&&<div className="fields"><label>Jumlah hasil panen<input defaultValue="2.500"/></label><label>Satuan<select><option>Kilogram (kg)</option><option>Ton</option><option>Ikat</option></select></label><div className="hint"><Icon name="shield"/> Masukkan perkiraan jumlah. Anda dapat memperbaruinya nanti.</div></div>}{step===3&&<div className="fields"><label>Perkiraan tanggal panen<input type="date" defaultValue="2025-06-28"/></label><label>Harga yang diharapkan<input defaultValue="Rp 44.000 / kg"/></label><div className="hint yellow"><Icon name="tag"/> Harga pasar terbaru Cabai Merah di Garut: <b>Rp42.000–Rp47.500 / kg</b></div></div>}{step===4&&<div className="upload"><div><Icon name="plus" size={32}/><b>Unggah foto hasil panen</b><span>PNG atau JPG, maksimal 5 MB</span><button className="btn secondary">Pilih foto</button></div><aside><img src={farmPhoto} alt="Pratinjau panen"/><b>Cabai Merah • 2.500 kg</b><span>Panen 28 Juni 2025</span></aside></div>}<div className="form-actions"><button className="btn secondary" disabled={step===1} onClick={()=>setStep(Math.max(1,step-1))}>Kembali</button><span>Draf tersimpan otomatis</span><button className="btn primary" onClick={()=>step<4?setStep(step+1):setStep(1)}>{step===4?'Kirim untuk diverifikasi':'Lanjutkan'} <Icon name="arrow"/></button></div></section></div>;
}

function HarvestSearch() {
  const cards=[['Cabai Merah Segar','Mulyono','Garut, Jawa Barat','2,5 ton','25 Jun 2025'],['Beras IR64','H. Ridwan','Subang, Jawa Barat','8 ton','5 Jul 2025'],['Bawang Merah','Sri Wahyuni','Brebes, Jawa Tengah','1,8 ton','2 Jul 2025'],['Jagung Pipil Kering','Sutrisno','Bantul, DIY','4 ton','28 Jun 2025']];
  return <><div className="welcome"><div><span>PAPAN HASIL PANEN</span><h1>Temukan Panen Berkualitas</h1><p>Terhubung langsung dengan petani terverifikasi di sekitar Anda.</p></div><button className="btn secondary"><Icon name="bell"/> Simpan pencarian</button></div><div className="search-layout"><aside className="filter-side"><div><h3>Filter pencarian</h3><button>Reset</button></div>{['Komoditas','Lokasi panen','Jumlah tersedia','Waktu panen'].map((x,i)=><label key={x}>{x}{i<2?<select><option>{i?'Semua wilayah':'Semua komoditas'}</option></select>:<><input type="range"/><small>{i?'7 hari — 3 bulan':'100 kg — 10 ton'}</small></>}</label>)}</aside><section className="results"><div className="result-head"><b>126 penawaran ditemukan</b><select><option>Terbaru</option></select></div><div className="offer-grid">{cards.map((c,i)=><article className="offer-card" key={c[0]}><div className="offer-image" style={{backgroundImage:`linear-gradient(0deg,rgba(27,94,32,.35),transparent),url(${i%2?heroPhoto:farmPhoto})`}}><Badge>Aktif</Badge><button>♡</button></div><div className="offer-body"><div><span>{i%2?'Biji-bijian':'Sayuran'}</span><h3>{c[0]}</h3></div><p><Icon name="map" size={15}/>{c[2]}</p><div className="offer-stats"><span><small>Jumlah</small><b>{c[3]}</b></span><span><small>Panen</small><b>{c[4]}</b></span></div><div className="farmer"><span>{c[1].split(' ').map(x=>x[0]).join('').slice(0,2)}</span><div><b>{c[1]}</b><small><Icon name="shield" size={13}/> Terverifikasi</small></div><button><Icon name="arrow"/></button></div></div></article>)}</div></section></div></>;
}

function VerificationDetail() {
  return <><div className="welcome"><div><span>Antrean Penawaran / #TH-24018</span><h1>Verifikasi Penawaran Panen</h1><p>Periksa seluruh informasi sebelum memberikan keputusan.</p></div><Badge tone="yellow">Menunggu pemeriksaan</Badge></div><div className="verify-layout"><section className="panel"><div className="detail-cover" style={{backgroundImage:`url(${farmPhoto})`}}><span>3 foto</span></div><div className="detail-title"><span>Sayuran</span><h2>Cabai Merah Segar</h2><p><Icon name="map"/> Garut, Jawa Barat</p></div><div className="detail-data"><div><small>Jumlah panen</small><b>2.500 kg</b></div><div><small>Perkiraan panen</small><b>25 Juni 2025</b></div><div><small>Harga diharapkan</small><b>Rp44.000 / kg</b></div><div><small>Nama petani</small><b>Mulyono <Badge>Terverifikasi</Badge></b></div></div></section><section className="panel checklist-panel"><div className="panel-title"><div><h3>Checklist pemeriksaan</h3><p>Centang setelah data dipastikan sesuai</p></div><span>4/7 selesai</span></div>{[['Kelengkapan data komoditas',['Nama dan jenis komoditas sesuai','Jumlah dan satuan telah diisi','Foto panen tampak jelas']],['Informasi petani',['Identitas petani terverifikasi','Lokasi lahan dapat dikonfirmasi']],['Sumber harga',['Harga wajar terhadap harga pasar','Tanggal pencatatan masih berlaku']]].map((g,gi)=><div className="check-group" key={g[0]}><b>{g[0]}</b>{g[1].map((x,i)=><label key={x}><input type="checkbox" defaultChecked={gi===0||i===0}/><span><Icon name="check" size={14}/></span>{x}</label>)}</div>)}</section></div><div className="decision-bar"><div><b>Keputusan verifikasi</b><span>Pastikan semua pemeriksaan selesai</span></div><button className="btn danger-outline"><Icon name="warning"/> Laporkan</button><button className="btn warning">Minta Revisi</button><button className="btn primary"><Icon name="check"/> Setujui Penawaran</button></div></>;
}

function GenericPage({ page, role }: {page:string;role:Role}) {
  const isReport=page.includes('Penipuan')||page.includes('Tidak Sesuai');
  const isAccount=page.includes('Akun')||page.includes('Mitra')||page.includes('Petani');
  const isPrice=page.includes('Harga')||page.includes('Sumber');
  return <><div className="welcome"><div><span>{role.toUpperCase()} / PENGELOLAAN DATA</span><h1>{page}</h1><p>Kelola, periksa, dan pantau data TaniHubungan dengan informasi yang transparan.</p></div><button className="btn primary"><Icon name="plus"/> {page.includes('Laporan')?'Ekspor laporan':page.includes('Riwayat')?'Unduh riwayat':isPrice?'Tambah sumber':'Tambah data'}</button></div><section className="panel"><div className="panel-title"><div><h3>Daftar {page.toLowerCase()}</h3><p>Data diperbarui secara berkala oleh sistem dan petugas</p></div><Badge>{isReport?'4 perlu tindakan':'Data tersinkron'}</Badge></div><Filters price={isPrice}/><Table type={isReport?'report':isAccount?'account':isPrice?'price':page.includes('Riwayat')?'verify':'offer'}/></section></>;
}

function UserDashboard({ role, setPage }: {role:'Petani'|'Pembeli';setPage:(p:string)=>void}) {
  if(role==='Pembeli') return <><div className="buyer-hero"><div><span>Selamat pagi, Sari Makmur</span><h1>Panen berkualitas,<br/>langsung dari petani.</h1><p>Cari komoditas berdasarkan lokasi, jumlah, dan waktu panen.</p><label><Icon name="search"/><input placeholder="Cari cabai, beras, jagung..."/><button onClick={()=>setPage('Cari Hasil Panen')}>Cari panen</button></label></div><div className="buyer-art"><Icon name="basket" size={100}/></div></div><div className="category-row">{[['rice','Beras & Padi'],['leaf','Sayuran'],['rice','Jagung'],['leaf','Rempah'],['basket','Lainnya']].map(x=><button key={x[1]}><span><Icon name={x[0] as IconName}/></span>{x[1]}<b>›</b></button>)}</div><div className="heading-row compact"><div><h2>Penawaran terbaru</h2><p>Hasil panen yang baru ditambahkan di sekitar Anda</p></div><button className="link-btn" onClick={()=>setPage('Cari Hasil Panen')}>Lihat semua <Icon name="arrow"/></button></div><HarvestSearch/></>;
  return <><div className="welcome"><div><span>Rabu, 18 Juni 2025</span><h1>Selamat pagi, Pak Budi</h1><p>Semoga panen hari ini membawa hasil terbaik.</p></div><button className="btn primary" onClick={()=>setPage('Buat Penawaran')}><Icon name="plus"/> Buat penawaran</button></div><div className="user-summary"><article className="summary-main"><div><span>Nilai penawaran aktif</span><b>Rp38.750.000</b><small>2 penawaran sedang ditayangkan</small></div><Icon name="rice" size={72}/></article><StatCard icon="message" label="Calon Pembeli Baru" value="4" note="2 belum dibaca"/><StatCard icon="basket" label="Panen Terjual" value="12,5 ton" note="Dalam 3 transaksi"/></div><div className="heading-row compact"><div><h2>Harga komoditas favorit</h2><p>Diperbarui berdasarkan wilayah Anda</p></div><button className="link-btn" onClick={()=>setPage('Informasi Harga')}>Lihat semua <Icon name="arrow"/></button></div><div className="price-grid app-prices">{prices.slice(0,3).map(p=><PriceCard item={p} key={p.crop}/>)}</div><section className="panel"><div className="panel-title"><div><h3>Penawaran saya</h3><p>Pantau perkembangan hasil panen yang ditawarkan</p></div><button className="link-btn">Lihat semua <Icon name="arrow"/></button></div><Table/></section></>;
}

function Workspace({ role, setRole }: {role:Exclude<Role,'Publik'>;setRole:(r:Role)=>void}) {
  const [page,setPage]=useState('Dashboard');
  const staff=role==='Admin'||role==='Petugas';
  let content:React.ReactNode;
  if(page==='Dashboard') content=role==='Admin'?<AdminDashboard/>:role==='Petugas'?<OfficerDashboard/>:<UserDashboard role={role as 'Petani'|'Pembeli'} setPage={setPage}/>;
  else if(page==='Informasi Harga') content=<PricePage/>;
  else if(page==='Buat Penawaran'||page==='Penawaran Saya'&&role==='Pembeli') content=<OfferWizard role={role as 'Petani'|'Pembeli'}/>;
  else if(page==='Cari Hasil Panen') content=<HarvestSearch/>;
  else if(page==='Antrean Penawaran') content=<><div className="welcome"><div><span>VERIFIKASI DATA</span><h1>Antrean Penawaran</h1><p>24 penawaran menunggu pemeriksaan kelengkapan data.</p></div><button className="btn secondary"><Icon name="filter"/> Atur prioritas</button></div><section className="panel"><Filters/><Table/></section></>;
  else if(page==='Verifikasi Petani') content=<VerificationDetail/>;
  else content=<GenericPage page={page} role={role}/>;
  return <div className={`workspace ${staff?'staff':'user'}`}>{staff&&<Sidebar role={role as 'Admin'|'Petugas'} page={page} setPage={setPage}/>}<div className="app-shell">{staff?<TopHeader role={role} setRole={setRole} page={page}/>:<UserNav role={role as 'Petani'|'Pembeli'} page={page} setPage={setPage} setRole={setRole}/>}<main className="app-content">{content}</main></div></div>;
}

export default function App() {
  const [role,setRole]=useState<Role>('Publik');
  return <><RoleSwitcher role={role} setRole={setRole}/>{role==='Publik'?<Landing setRole={setRole}/>:<Workspace key={role} role={role} setRole={setRole}/>}</>;
}
