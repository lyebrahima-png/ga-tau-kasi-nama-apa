/* AksesKita – logika antarmuka (JavaScript murni, tanpa framework)
 * Menggantikan komponen React pada src/App.tsx:
 *  - navigasi antarhalaman (state "page")
 *  - kontrol aksesibilitas: ukuran teks & kontras tinggi
 *  - menu seluler, peta (pilih fasilitas / Peta-Daftar), formulir laporan 3 langkah, login per peran
 * Markup tiap halaman ada di index.html pada elemen <template id="tpl-...">.
 */
(() => {
  'use strict';

  /* ---------- Data & util ---------- */
  const ICONS = {
      "shield": "<path d=\"M12 3 4.5 6v5.5c0 4.5 3 7.7 7.5 9.5 4.5-1.8 7.5-5 7.5-9.5V6z\"/><path d=\"m8.5 12 2 2 5-5\"/>",
      "clock": "<circle cx=\"12\" cy=\"12\" r=\"9\"/><path d=\"M12 7v5l3 2\"/>",
      "check": "<path d=\"m5 12 4 4L19 6\"/>",
      "menu": "<path d=\"M4 7h16M4 12h16M4 17h16\"/>",
      "x": "<path d=\"m6 6 12 12M18 6 6 18\"/>"
  };

  const icon = (name, size = 24) =>
    `<svg class="icon" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name]}</svg>`;

  const STATUS = {
    verified: { label: 'Terverifikasi', icon: 'shield', className: 'verified' },
    pending: { label: 'Menunggu verifikasi', icon: 'clock', className: 'pending' },
  };

  const statusBadge = (status, compact = false) => {
    const item = STATUS[status];
    return `<span class="status-badge ${item.className}">${icon(item.icon, compact ? 16 : 18)}${item.label}</span>`;
  };

  const FACILITIES = [
    { name: 'Puskesmas Langsa Kota', status: 'verified', distance: '1,2 km' },
    { name: 'Taman Kota Langsa', status: 'verified', distance: '2,4 km' },
    { name: 'Pasar Harmoni Langsa', status: 'pending', distance: '3,1 km' },
  ];

  const TEXT_SIZE_LABELS = ['Normal', 'Besar', 'Sangat besar'];
  const STEP_LABELS = ['Pilih fasilitas', 'Isi kondisi', 'Tinjau & kirim'];
  const NON_PUBLIC_PAGES = ['login', 'admin', 'officer'];

  /* ---------- State aplikasi ---------- */
  const state = { page: 'home', highContrast: false, textSize: 0, menuOpen: false };

  const app = document.getElementById('app');
  const header = document.getElementById('site-header');
  const footer = document.getElementById('site-footer');
  const tabs = document.getElementById('mobile-tabs');
  const mainNav = header.querySelector('.main-nav');
  const textSizeBtn = document.getElementById('text-size-btn');
  const contrastBtn = document.getElementById('contrast-btn');
  const mobileMenuBtn = document.getElementById('mobile-menu-btn');

  const cloneTemplate = (id) => document.getElementById('tpl-' + id).content.firstElementChild.cloneNode(true);

  /* ---------- Render kerangka (header, footer, tab seluler) ---------- */
  function syncShell() {
    const isPublic = !NON_PUBLIC_PAGES.includes(state.page);
    // Header ikut "dilepas" pada halaman non-publik, sehingga menu seluler kembali tertutup
    if (!isPublic) state.menuOpen = false;

    header.hidden = footer.hidden = tabs.hidden = !isPublic;

    app.className = `app${state.highContrast ? ' high-contrast' : ''} text-size-${state.textSize}`;

    header.querySelectorAll('[data-nav]').forEach((b) => b.classList.toggle('active', b.dataset.go === state.page));
    mainNav.classList.toggle('open', state.menuOpen);

    textSizeBtn.querySelector('small').textContent = TEXT_SIZE_LABELS[state.textSize];
    contrastBtn.classList.toggle('selected', state.highContrast);
    contrastBtn.setAttribute('aria-pressed', String(state.highContrast));

    mobileMenuBtn.setAttribute('aria-label', state.menuOpen ? 'Tutup menu' : 'Buka menu');
    mobileMenuBtn.innerHTML = icon(state.menuOpen ? 'x' : 'menu');

    tabs.querySelectorAll('[data-tab]').forEach((b) => b.classList.toggle('active', b.dataset.go === state.page));
  }

  /* ---------- Pemasangan halaman ---------- */
  function mountMain(templateId, init) {
    const current = app.querySelector(':scope > main');
    if (current) current.remove();
    const main = cloneTemplate(templateId);
    footer.before(main);
    if (init) init(main);
  }

  const PAGES = {
    home: () => mountMain('home'),
    map: () => mountMain('map', initMapPage),
    detail: () => mountMain('detail'),
    report: () => mountMain('report', initReportPage),
    reports: () => mountMain('reports'),
    login: () => mountMain('login', initLoginPage),
    admin: () => mountMain('admin'),
    officer: () => mountMain('officer'),
  };

  function go(next) {
    if (next !== state.page) {
      state.page = next;
      syncShell();
      PAGES[next]();
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  /* ---------- Halaman Peta ---------- */
  function initMapPage(main) {
    let selected = 0;
    let view = 'map';

    const layout = main.querySelector('.map-layout');
    const toggles = [...main.querySelectorAll('[data-view]')];
    const cards = [...main.querySelectorAll('.result-card')];
    const pins = [...main.querySelectorAll('.real-pin')];
    const selectedInfo = main.querySelector('.selected-map-card > div');

    function render() {
      layout.classList.toggle('list-only', view === 'list');
      toggles.forEach((b) => b.classList.toggle('active', b.dataset.view === view));
      cards.forEach((c, i) => c.classList.toggle('selected', i === selected));
      pins.forEach((p, i) => p.classList.toggle('selected', i === selected));
      const f = FACILITIES[selected];
      selectedInfo.innerHTML = `${statusBadge(f.status, true)}<strong>${f.name}</strong><span>${f.distance} dari Anda</span>`;
    }

    main.addEventListener('click', (e) => {
      const toggle = e.target.closest('[data-view]');
      if (toggle) { view = toggle.dataset.view; return render(); }
      const pin = e.target.closest('.real-pin');
      if (pin) { selected = Number(pin.dataset.index); return render(); }
      const card = e.target.closest('.result-card');
      if (card) { selected = Number(card.dataset.index); render(); }
    });
  }

  /* ---------- Halaman Laporan (formulir 3 langkah) ---------- */
  function initReportPage(main) {
    let step = 1;
    let condition = '';

    const form = main.querySelector('form');
    const stepper = main.querySelector('.stepper');
    const backLink = main.querySelector('.back-link');

    function renderStepper() {
      stepper.setAttribute('aria-label', `Langkah ${step} dari 3`);
      stepper.innerHTML = STEP_LABELS.map((label, i) => {
        const cls = [step === i + 1 ? 'current' : '', step > i + 1 ? 'done' : ''].filter(Boolean).join(' ');
        return `<div${cls ? ` class="${cls}"` : ''}><span>${step > i + 1 ? icon('check', 17) : i + 1}</span><strong>${label.replace('&', '&amp;')}</strong></div>`;
      }).join('');
    }

    function syncCondition() {
      form.querySelectorAll('.radio-row label').forEach((label) => {
        const input = label.querySelector('input');
        input.checked = input.value === condition;
        label.classList.toggle('checked', input.value === condition);
      });
      if (condition) {
        const hint = form.querySelector('.field-hint');
        if (hint) hint.remove();
      }
    }

    function renderStep() {
      renderStepper();
      form.replaceChildren(cloneTemplate('report-step-' + step));
      if (step === 2) syncCondition();
      if (step === 3) form.querySelector('[data-condition]').textContent = condition || 'Sebagian';
    }

    function showSuccess() {
      mountMain('report-success');
    }

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      if (step < 3) { step += 1; renderStep(); } else { showSuccess(); }
    });

    form.addEventListener('change', (e) => {
      if (e.target.matches('input[type="radio"][name="condition"]')) {
        condition = e.target.value;
        syncCondition();
      }
    });

    form.addEventListener('click', (e) => {
      const target = e.target.closest('[data-step]');
      if (target) { step = Number(target.dataset.step); renderStep(); }
    });

    backLink.addEventListener('click', () => {
      if (step > 1) { step -= 1; renderStep(); } else { go('detail'); }
    });

    renderStep();
  }

  /* ---------- Halaman Login ---------- */
  function initLoginPage(main) {
    let role = 'Pengguna';

    const tabButtons = [...main.querySelectorAll('[data-role]')];
    const submitLabel = main.querySelector('form .btn-primary > span');

    function render() {
      tabButtons.forEach((b) => {
        const active = b.dataset.role === role;
        b.classList.toggle('active', active);
        b.setAttribute('aria-selected', String(active));
      });
      submitLabel.textContent = `Masuk sebagai ${role}`;
    }

    tabButtons.forEach((b) => b.addEventListener('click', () => { role = b.dataset.role; render(); }));

    main.querySelector('form').addEventListener('submit', (e) => {
      e.preventDefault();
      go(role === 'Admin' ? 'admin' : role === 'Petugas' ? 'officer' : 'home');
    });
  }

  /* ---------- Event global ---------- */
  document.addEventListener('click', (e) => {
    const target = e.target.closest('[data-go]');
    if (!target) return;
    // Pada navigasi utama, menu seluler ditutup setelah memilih tujuan
    if (target.matches('[data-nav]')) state.menuOpen = false;
    go(target.dataset.go);
  });

  textSizeBtn.addEventListener('click', () => {
    state.textSize = state.textSize === 2 ? 0 : state.textSize + 1;
    syncShell();
  });

  contrastBtn.addEventListener('click', () => {
    state.highContrast = !state.highContrast;
    syncShell();
  });

  mobileMenuBtn.addEventListener('click', () => {
    state.menuOpen = !state.menuOpen;
    syncShell();
  });

  /* ---------- Mulai ---------- */
  syncShell();
  PAGES[state.page]();
})();
