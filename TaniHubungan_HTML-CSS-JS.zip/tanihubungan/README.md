# TaniHubungan (HTML + CSS + JavaScript)

Hasil migrasi dari proyek React/Vite/Tailwind. Tanpa build, tanpa dependensi: buka `index.html` di browser.

- `css/style.css` — seluruh gaya (termasuk reset pengganti Tailwind Preflight)
- `js/icons.js`, `js/data.js` — ikon SVG dan data contoh
- `js/components.js`, `js/views.js` — komponen & halaman (fungsi yang mengembalikan string HTML)
- `js/app.js` — state (`role`, `page`, `step`), render, dan penanganan klik
