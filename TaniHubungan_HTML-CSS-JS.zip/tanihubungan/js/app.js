/* State & render: pengganti useState + ReactDOM */
const state = { role: 'Publik', page: 'Dashboard', step: 1 };

function render() {
  const { role, page, step } = state;
  document.getElementById('root').innerHTML =
    roleSwitcher(role) + (role === 'Publik' ? landing() : workspace(role, page, step));
}

// Satu listener untuk semua tombol ber-atribut data-act (event delegation)
document.addEventListener('click', e => {
  const el = e.target.closest('[data-act]');
  if (!el) return;
  const { act, v } = el.dataset;
  if (act === 'role') { state.role = v; state.page = 'Dashboard'; state.step = 1; }   // ganti peran = mulai dari awal
  else if (act === 'page') { state.page = v; }
  else if (act === 'step') { state.step = v === '-1' ? Math.max(1, state.step - 1) : state.step < 4 ? state.step + 1 : 1; }
  render();
});

render();
