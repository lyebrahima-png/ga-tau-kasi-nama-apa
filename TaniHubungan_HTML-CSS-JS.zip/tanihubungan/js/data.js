/* Data statis (contoh) */
const heroPhoto = 'https://images.unsplash.com/photo-1520052203542-d3095f1b6cf0?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=88&w=1400';
const farmPhoto = 'https://images.unsplash.com/photo-1530507629858-e4977d30e9e0?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=900';

const PRICES = [
  { crop: 'Beras Medium', price: 'Rp13.200', unit: '/ kg', market: 'Pasar Induk Cipinang, Jakarta', source: 'PIBC Jakarta', date: '18 Juni 2025', status: 'Terbaru', tone: 'green', icon: 'rice' },
  { crop: 'Cabai Merah', price: 'Rp46.500', unit: '/ kg', market: 'Pasar Caringin, Bandung', source: 'Dinas Pangan Jabar', date: '17 Juni 2025', status: 'Terbaru', tone: 'green', icon: 'leaf' },
  { crop: 'Jagung Pipil', price: 'Rp5.800', unit: '/ kg', market: 'Pasar Wates, Yogyakarta', source: 'Petugas Lapangan', date: '14 Juni 2025', status: 'Perlu diperbarui', tone: 'yellow', icon: 'rice' },
  { crop: 'Bawang Merah', price: 'Rp34.000', unit: '/ kg', market: 'Pasar Brebes, Jawa Tengah', source: 'Bapanas', date: '8 Juni 2025', status: 'Data lama', tone: 'gray', icon: 'leaf' },
];

const NAVS = {
  Petani: ['Dashboard','Informasi Harga','Buat Penawaran','Penawaran Saya','Calon Pembeli','Status Penjualan'],
  Pembeli: ['Dashboard','Informasi Harga','Cari Hasil Panen','Penawaran Saya','Negosiasi','Kesepakatan'],
  Petugas: ['Dashboard','Antrean Penawaran','Verifikasi Petani','Sumber Data Harga','Perbarui Data Harga','Laporan Data Tidak Sesuai','Riwayat Verifikasi'],
  Admin: ['Dashboard','Kelola Akun','Verifikasi Mitra','Kategori Komoditas','Sumber Harga','Pantau Penawaran','Aktivitas Pembeli','Laporan Penipuan','Laporan Perdagangan'],
};

const TABLES = {
  offer: { heads:['Komoditas','Petani','Wilayah','Jumlah','Tanggal panen','Status','Aksi'], rows:[['Cabai Merah','Mulyono','Garut, Jawa Barat','2,5 ton','25 Jun 2025','Menunggu','Periksa'],['Jagung Pipil','Sutrisno','Bantul, DIY','4 ton','28 Jun 2025','Perlu Revisi','Periksa'],['Bawang Merah','Sri Wahyuni','Brebes, Jateng','1,8 ton','2 Jul 2025','Menunggu','Periksa'],['Beras Medium','H. Ridwan','Subang, Jabar','8 ton','5 Jul 2025','Disetujui','Lihat']]},
  account: { heads:['Nama pengguna','Peran','Wilayah','Terdaftar','Status','Aksi'], rows:[['Budi Santoso','Petani','Garut, Jawa Barat','18 Jun 2025','Aktif','Lihat'],['CV Sari Makmur','Pembeli','Bandung, Jawa Barat','17 Jun 2025','Menunggu','Periksa'],['Sri Wahyuni','Petani','Brebes, Jawa Tengah','16 Jun 2025','Aktif','Lihat'],['UD Pangan Jaya','Pembeli','Jakarta Timur','14 Jun 2025','Diblokir','Lihat']]},
  verify: { heads:['ID Verifikasi','Objek','Petugas','Tanggal','Hasil','Catatan'], rows:[['VRF-250618-42','Cabai Merah — Mulyono','Dewi Wulandari','18 Jun 2025','Disetujui','Data lengkap'],['VRF-250618-41','Beras Medium — H. Ridwan','Agus Pratama','18 Jun 2025','Disetujui','Sesuai foto'],['VRF-250617-39','Jagung — Sutrisno','Dewi Wulandari','17 Jun 2025','Perlu Revisi','Satuan belum jelas'],['VRF-250617-38','Bawang — Sri Wahyuni','Agus Pratama','17 Jun 2025','Terkirim','Ke admin']]},
  price: { heads:['Komoditas','Pasar / Lokasi','Harga','Sumber','Pencatatan','Status','Aksi'], rows:[['Beras Medium','Pasar Induk Cipinang','Rp13.200 / kg','PIBC Jakarta','18 Jun 2025','Terbaru','Ubah'],['Cabai Merah','Pasar Caringin','Rp46.500 / kg','Dinas Pangan Jabar','17 Jun 2025','Terbaru','Ubah'],['Jagung Pipil','Pasar Wates','Rp5.800 / kg','Petugas Lapangan','14 Jun 2025','Perlu diperbarui','Ubah'],['Bawang Merah','Pasar Brebes','Rp34.000 / kg','Bapanas','8 Jun 2025','Data lama','Ubah']]},
  report: { heads:['ID Laporan','Pelapor','Objek','Jenis masalah','Tanggal','Status','Aksi'], rows:[['LPR-1028','CV Tani Sejahtera','Akun M. Yusuf','Dugaan penipuan','18 Jun 2025','Prioritas','Selidiki'],['LPR-1027','Sari Makmur','Penawaran #2194','Data tidak sesuai','17 Jun 2025','Diproses','Lihat'],['LPR-1026','Budi Santoso','Akun UD Karya','Penyalahgunaan','16 Jun 2025','Baru','Selidiki'],['LPR-1025','Dewi Wulandari','Harga Cabai','Sumber tidak valid','15 Jun 2025','Selesai','Lihat']]},
};
