/* Halaman: setiap fungsi mengembalikan string HTML */

const landing = () => `<div class="landing">
<nav class="public-nav">${logo()}<div class="nav-links"><a href="#harga">Harga Komoditas</a><a href="#fitur">Cara Kerja</a><a href="#keamanan">Keamanan</a></div><div class="nav-actions"><button class="btn text" data-act="role" data-v="Petani">Masuk</button><button class="btn primary" data-act="role" data-v="Petani">Daftar Sekarang</button></div></nav>
<main>
<section class="hero"><div class="hero-copy"><div class="eyebrow"><span></span> Tumbuh dan terhubung bersama</div><h1>Harga Transparan,<br>Panen Terhubung <em>ke Pembeli</em></h1><p>Akses informasi harga pasar yang terpercaya dan temukan pembeli lokal untuk hasil panen Anda, tanpa perantara yang rumit.</p><div class="hero-actions"><button class="btn primary large" data-act="role" data-v="Petani">${icon('leaf')} Daftar sebagai Petani</button><button class="btn secondary large" data-act="role" data-v="Pembeli">${icon('basket')} Daftar sebagai Pembeli</button></div><div class="trust-row"><span>${icon('check', 16)} Gratis untuk bergabung</span><span>${icon('check', 16)} Data terverifikasi</span></div></div>
<div class="hero-visual"><img src="${heroPhoto}" alt="Petani merawat sawah di Indonesia"><div class="floating-price"><div><span>Harga hari ini</span>${badge('Terbaru')}</div><strong>Beras Medium</strong><b>Rp13.200 <small>/ kg</small></b><span>Pasar Induk Cipinang</span></div><div class="verified-chip"><span>${icon('shield')}</span><div><b>Petani terverifikasi</b><small>Aman untuk bertransaksi</small></div></div></div></section>
<section class="stats-strip"><div><b>12.480+</b><span>Petani terhubung</span></div><div><b>3.240+</b><span>Pembeli aktif</span></div><div><b>28</b><span>Provinsi terjangkau</span></div><div><b>96%</b><span>Data harga terverifikasi</span></div></section>
<section id="fitur" class="section"><div class="section-heading"><span class="kicker">FITUR UTAMA</span><h2>Satu tempat untuk panen yang lebih menguntungkan</h2><p>Informasi yang jelas dan koneksi yang tepat untuk membantu keputusan usaha tani Anda.</p></div><div class="feature-grid">${L([
  ['tag', 'Informasi Harga Komoditas', 'Bandingkan harga berdasarkan komoditas, pasar, tanggal, dan sumber data yang jelas.'],
  ['rice', 'Papan Penawaran Hasil Panen', 'Catat komoditas, jumlah, dan perkiraan waktu panen agar mudah ditemukan pembeli.'],
  ['message', 'Direktori Pembeli & Negosiasi', 'Temukan calon pembeli, terima atau tolak penawaran, lalu negosiasi aman di aplikasi.']
], (f, i) => `<article class="feature-card"><span class="feature-no">0${i + 1}</span><div class="feature-icon">${icon(f[0], 28)}</div><h3>${f[1]}</h3><p>${f[2]}</p><a>Pelajari selengkapnya ${icon('arrow', 17)}</a></article>`)}</div></section>
<section id="harga" class="section prices-section"><div class="heading-row"><div><span class="kicker">HARGA PASAR TERKINI</span><h2>Pantau harga sebelum menjual</h2></div><button class="btn secondary">Lihat semua harga ${icon('arrow', 17)}</button></div><div class="price-grid">${L(PRICES, p => priceCard(p))}</div></section>
<section class="section how"><div class="how-image"><img src="${farmPhoto}" alt="Petani memanen padi"><div class="photo-note"><b>Panen lebih pasti</b><span>Dengan pembeli yang sudah terhubung</span></div></div><div class="how-copy"><span class="kicker">CARA KERJA</span><h2>Dari lahan hingga pembeli, semudah 1—2—3</h2>${L([
  ['1', 'Daftar dan lengkapi profil', 'Pilih peran sebagai petani atau pembeli, lalu verifikasi profil Anda.'],
  ['2', 'Pasang atau cari penawaran', 'Petani mencatat hasil panen. Pembeli mencari sesuai kebutuhan.'],
  ['3', 'Sepakati transaksi', 'Negosiasi aman di aplikasi dan selesaikan transaksi dengan jelas.']
], x => `<div class="step"><span>${x[0]}</span><div><h3>${x[1]}</h3><p>${x[2]}</p></div></div>`)}</div></section>
<section id="keamanan" class="security"><div><span class="kicker light">KEPERCAYAAN & KEAMANAN</span><h2>Bertransaksi dengan lebih tenang</h2><p>Identitas mitra diverifikasi, sumber harga selalu ditampilkan, dan percakapan tersimpan aman tanpa membagikan nomor pribadi.</p></div><div class="security-list"><span>${icon('shield')} Verifikasi identitas mitra</span><span>${icon('clock')} Penanda usia data harga</span><span>${icon('message')} Negosiasi aman di aplikasi</span></div></section>
<section class="closing"><span class="crop-icon">${icon('rice')}</span><h2>Siap menghubungkan panen Anda?</h2><p>Bergabung dengan ribuan pelaku pertanian Indonesia yang tumbuh bersama.</p><button class="btn white large" data-act="role" data-v="Petani">Mulai sekarang ${icon('arrow')}</button></section>
</main>
<footer>${logo(true)}<p>Menghubungkan petani dan pembeli lokal melalui informasi yang transparan.</p><div><a>Tentang Kami</a><a>Bantuan</a><a>Kebijakan Privasi</a></div><small>© 2025 TaniHubungan. Dibuat untuk pertanian Indonesia.</small></footer>
</div>`;

const welcome = (kicker, title, desc, btn = '') => `<div class="welcome"><div><span>${kicker}</span><h1>${title}</h1><p>${desc}</p></div>${btn}</div>`;
const panelTitle = (title, desc, right = '') => `<div class="panel-title"><div><h3>${title}</h3><p>${desc}</p></div>${right}</div>`;
const seeAll = (act = '') => `<button class="link-btn" ${act}>Lihat semua ${icon('arrow', 16)}</button>`;

const adminDashboard = () => welcome('Rabu, 18 Juni 2025', 'Selamat pagi, Arif', 'Pantau aktivitas dan kesehatan platform TaniHubungan hari ini.', `<button class="btn primary">${icon('file')} Unduh ringkasan</button>`)
  + `<div class="stats-grid">${statCard('leaf', 'Total Petani', '12.480', '↑ 8,2% bulan ini')}${statCard('basket', 'Total Pembeli', '3.240', '↑ 5,4% bulan ini')}${statCard('tag', 'Penawaran Aktif', '1.864', '142 baru minggu ini')}${statCard('chart', 'Transaksi Bulan Ini', 'Rp2,8 M', '↑ 12,6% dari Mei')}</div>`
  + `<div class="dash-grid"><section class="panel activity">${panelTitle('Aktivitas perdagangan', 'Nilai transaksi 7 hari terakhir', '<select><option>7 hari terakhir</option></select>')}${barChart()}</section>`
  + `<section class="panel fraud">${panelTitle('Laporan penipuan terbaru', 'Perlu ditindaklanjuti', badge('3 prioritas', 'red'))}${L(['Dugaan pembayaran palsu', 'Komoditas tidak sesuai', 'Akun mencurigakan'], (x, i) => `<div class="fraud-row"><span class="alert-icon">${icon('warning')}</span><div><b>${x}</b><small>${['LPR-1028 • 12 menit lalu', 'LPR-1027 • 2 jam lalu', 'LPR-1026 • kemarin'][i]}</small></div><button>${icon('arrow')}</button></div>`)}</section></div>`
  + `<section class="panel">${panelTitle('Akun menunggu verifikasi', 'Periksa kelengkapan mitra baru sebelum menyetujui', seeAll())}${table('account')}</section>`;

const officerDashboard = () => welcome('Rabu, 18 Juni 2025', 'Selamat pagi, Dewi', 'Berikut ringkasan tugas verifikasi data pertanian Anda.', `<button class="btn primary">${icon('check')} Mulai verifikasi</button>`)
  + `<div class="stats-grid">${statCard('clock', 'Perlu Diperiksa', '24', '12 prioritas hari ini', 'yellow')}${statCard('check', 'Diverifikasi Hari Ini', '18', 'Target harian: 25')}${statCard('tag', 'Harga Perlu Diperbarui', '7', '2 data kedaluwarsa', 'yellow')}${statCard('warning', 'Dilaporkan Tidak Sesuai', '3', 'Perlu tindak lanjut', 'red')}</div>`
  + `<div class="dash-grid"><section class="panel">${panelTitle('Verifikasi 7 hari terakhir', 'Jumlah data yang selesai diperiksa', badge('126 selesai'))}${barChart()}</section>`
  + `<section class="panel expiry">${panelTitle('Harga kedaluwarsa', 'Segera perbarui sumber data')}${L(PRICES.slice(2), p => priceCard(p, true))}</section></div>`
  + `<section class="panel">${panelTitle('Antrean terbaru', 'Penawaran yang menunggu pemeriksaan', seeAll())}${table()}</section>`;

const pricePage = () => welcome('DATA HARGA TERPERCAYA', 'Informasi Harga Komoditas', 'Bandingkan harga terbaru dari pasar dan sumber yang terverifikasi.', `<button class="btn secondary">${icon('bell')} Atur pengingat harga</button>`)
  + filters(true) + `<div class="price-grid app-prices">${L(PRICES, p => priceCard(p))}</div>`
  + `<section class="panel history">${panelTitle('Riwayat harga — Beras Medium', 'Pasar Induk Cipinang • Harga per kg • 30 hari', '<div class="tabs"><button class="active">30 hari</button><button>3 bulan</button><button>1 tahun</button></div>')}<div class="line-chart"><div class="chart-labels"><span>Rp14 rb</span><span>Rp13 rb</span><span>Rp12 rb</span><span>Rp11 rb</span></div><svg viewBox="0 0 900 210" preserveAspectRatio="none"><path class="area" d="M0 180 C80 175 100 120 170 130 S270 80 350 105 S480 55 560 80 S680 30 760 60 S850 30 900 20 L900 210 L0 210Z"/><path class="line" d="M0 180 C80 175 100 120 170 130 S270 80 350 105 S480 55 560 80 S680 30 760 60 S850 30 900 20"/></svg></div></section>`;

const WIZ = [
  ['Pilih komoditas hasil panen', 'Pilih jenis komoditas yang akan Anda tawarkan.'],
  ['Tentukan jumlah hasil panen', 'Masukkan perkiraan jumlah yang tersedia.'],
  ['Atur waktu panen dan harga', 'Berikan jadwal dan harga harapan yang jelas.'],
  ['Unggah foto dan tinjau', 'Foto yang baik membantu pembeli lebih percaya.']
];
const wizardBody = step => [
  `<div class="commodity-grid">${L(['Cabai Merah', 'Beras', 'Jagung', 'Bawang Merah', 'Tomat', 'Kentang'], (x, i) => `<button class="${i === 0 ? 'selected' : ''}"><span>${icon(i < 2 ? 'rice' : 'leaf')}</span><b>${x}</b>${i === 0 ? `<i>${icon('check', 14)}</i>` : ''}</button>`)}</div>`,
  `<div class="fields"><label>Jumlah hasil panen<input value="2.500"></label><label>Satuan<select><option>Kilogram (kg)</option><option>Ton</option><option>Ikat</option></select></label><div class="hint">${icon('shield')} Masukkan perkiraan jumlah. Anda dapat memperbaruinya nanti.</div></div>`,
  `<div class="fields"><label>Perkiraan tanggal panen<input type="date" value="2025-06-28"></label><label>Harga yang diharapkan<input value="Rp 44.000 / kg"></label><div class="hint yellow">${icon('tag')} Harga pasar terbaru Cabai Merah di Garut: <b>Rp42.000–Rp47.500 / kg</b></div></div>`,
  `<div class="upload"><div>${icon('plus', 32)}<b>Unggah foto hasil panen</b><span>PNG atau JPG, maksimal 5 MB</span><button class="btn secondary">Pilih foto</button></div><aside><img src="${farmPhoto}" alt="Pratinjau panen"><b>Cabai Merah • 2.500 kg</b><span>Panen 28 Juni 2025</span></aside></div>`
][step - 1];

const offerWizard = (role, step) => {
  const buyer = role === 'Pembeli';
  return `<div class="form-page"><div class="form-intro"><span>${buyer ? 'PENAWARAN PEMBELIAN' : 'LANGKAH MUDAH'}</span><h1>${buyer ? 'Ajukan Penawaran Pembelian' : 'Buat Penawaran Hasil Panen'}</h1><p>${buyer ? 'Ajukan jumlah dan harga yang wajar kepada petani.' : 'Isi informasi hasil panen Anda agar mudah ditemukan pembeli.'}</p></div>`
    + `<div class="stepper">${L(['Komoditas', 'Jumlah & satuan', 'Waktu & harga', 'Foto & tinjau'], (x, i) => `<div class="${step === i + 1 ? 'active' : ''} ${step > i + 1 ? 'done' : ''}"><span>${step > i + 1 ? icon('check', 16) : i + 1}</span><b>${x}</b></div>`)}</div>`
    + `<section class="form-card"><div class="form-card-head"><span>Langkah ${step} dari 4</span><h2>${WIZ[step - 1][0]}</h2><p>${WIZ[step - 1][1]}</p></div>${wizardBody(step)}`
    + `<div class="form-actions"><button class="btn secondary" data-act="step" data-v="-1" ${step === 1 ? 'disabled' : ''}>Kembali</button><span>Draf tersimpan otomatis</span><button class="btn primary" data-act="step" data-v="1">${step === 4 ? 'Kirim untuk diverifikasi' : 'Lanjutkan'} ${icon('arrow')}</button></div></section></div>`;
};

const harvestSearch = () => {
  const cards = [['Cabai Merah Segar', 'Mulyono', 'Garut, Jawa Barat', '2,5 ton', '25 Jun 2025'], ['Beras IR64', 'H. Ridwan', 'Subang, Jawa Barat', '8 ton', '5 Jul 2025'], ['Bawang Merah', 'Sri Wahyuni', 'Brebes, Jawa Tengah', '1,8 ton', '2 Jul 2025'], ['Jagung Pipil Kering', 'Sutrisno', 'Bantul, DIY', '4 ton', '28 Jun 2025']];
  return welcome('PAPAN HASIL PANEN', 'Temukan Panen Berkualitas', 'Terhubung langsung dengan petani terverifikasi di sekitar Anda.', `<button class="btn secondary">${icon('bell')} Simpan pencarian</button>`)
    + `<div class="search-layout"><aside class="filter-side"><div><h3>Filter pencarian</h3><button>Reset</button></div>${L(['Komoditas', 'Lokasi panen', 'Jumlah tersedia', 'Waktu panen'], (x, i) => `<label>${x}${i < 2 ? `<select><option>${i ? 'Semua wilayah' : 'Semua komoditas'}</option></select>` : `<input type="range"><small>${i === 3 ? '7 hari — 3 bulan' : '100 kg — 10 ton'}</small>`}</label>`)}</aside>`
    + `<section class="results"><div class="result-head"><b>126 penawaran ditemukan</b><select><option>Terbaru</option></select></div><div class="offer-grid">${L(cards, (c, i) => `<article class="offer-card"><div class="offer-image" style="background-image:linear-gradient(0deg,rgba(27,94,32,.35),transparent),url(${i % 2 ? heroPhoto : farmPhoto})">${badge('Aktif')}<button>♡</button></div><div class="offer-body"><div><span>${i % 2 ? 'Biji-bijian' : 'Sayuran'}</span><h3>${c[0]}</h3></div><p>${icon('map', 15)}${c[2]}</p><div class="offer-stats"><span><small>Jumlah</small><b>${c[3]}</b></span><span><small>Panen</small><b>${c[4]}</b></span></div><div class="farmer"><span>${c[1].split(' ').map(x => x[0]).join('').slice(0, 2)}</span><div><b>${c[1]}</b><small>${icon('shield', 13)} Terverifikasi</small></div><button>${icon('arrow')}</button></div></div></article>`)}</div></section></div>`;
};

const verificationDetail = () => welcome('Antrean Penawaran / #TH-24018', 'Verifikasi Penawaran Panen', 'Periksa seluruh informasi sebelum memberikan keputusan.', badge('Menunggu pemeriksaan', 'yellow'))
  + `<div class="verify-layout"><section class="panel"><div class="detail-cover" style="background-image:url(${farmPhoto})"><span>3 foto</span></div><div class="detail-title"><span>Sayuran</span><h2>Cabai Merah Segar</h2><p>${icon('map')} Garut, Jawa Barat</p></div><div class="detail-data"><div><small>Jumlah panen</small><b>2.500 kg</b></div><div><small>Perkiraan panen</small><b>25 Juni 2025</b></div><div><small>Harga diharapkan</small><b>Rp44.000 / kg</b></div><div><small>Nama petani</small><b>Mulyono ${badge('Terverifikasi')}</b></div></div></section>`
  + `<section class="panel checklist-panel">${panelTitle('Checklist pemeriksaan', 'Centang setelah data dipastikan sesuai', '<span>4/7 selesai</span>')}${L([['Kelengkapan data komoditas', ['Nama dan jenis komoditas sesuai', 'Jumlah dan satuan telah diisi', 'Foto panen tampak jelas']], ['Informasi petani', ['Identitas petani terverifikasi', 'Lokasi lahan dapat dikonfirmasi']], ['Sumber harga', ['Harga wajar terhadap harga pasar', 'Tanggal pencatatan masih berlaku']]], (g, gi) => `<div class="check-group"><b>${g[0]}</b>${L(g[1], (x, i) => `<label><input type="checkbox" ${gi === 0 || i === 0 ? 'checked' : ''}><span>${icon('check', 14)}</span>${x}</label>`)}</div>`)}</section></div>`
  + `<div class="decision-bar"><div><b>Keputusan verifikasi</b><span>Pastikan semua pemeriksaan selesai</span></div><button class="btn danger-outline">${icon('warning')} Laporkan</button><button class="btn warning">Minta Revisi</button><button class="btn primary">${icon('check')} Setujui Penawaran</button></div>`;

const queuePage = () => welcome('VERIFIKASI DATA', 'Antrean Penawaran', '24 penawaran menunggu pemeriksaan kelengkapan data.', `<button class="btn secondary">${icon('filter')} Atur prioritas</button>`)
  + `<section class="panel">${filters()}${table()}</section>`;

const genericPage = (page, role) => {
  const isReport = page.includes('Penipuan') || page.includes('Tidak Sesuai');
  const isAccount = page.includes('Akun') || page.includes('Mitra') || page.includes('Petani');
  const isPrice = page.includes('Harga') || page.includes('Sumber');
  const btn = page.includes('Laporan') ? 'Ekspor laporan' : page.includes('Riwayat') ? 'Unduh riwayat' : isPrice ? 'Tambah sumber' : 'Tambah data';
  return welcome(`${role.toUpperCase()} / PENGELOLAAN DATA`, page, 'Kelola, periksa, dan pantau data TaniHubungan dengan informasi yang transparan.', `<button class="btn primary">${icon('plus')} ${btn}</button>`)
    + `<section class="panel">${panelTitle(`Daftar ${page.toLowerCase()}`, 'Data diperbarui secara berkala oleh sistem dan petugas', badge(isReport ? '4 perlu tindakan' : 'Data tersinkron'))}${filters(isPrice)}${table(isReport ? 'report' : isAccount ? 'account' : isPrice ? 'price' : page.includes('Riwayat') ? 'verify' : 'offer')}</section>`;
};

const userDashboard = role => {
  if (role === 'Pembeli') return `<div class="buyer-hero"><div><span>Selamat pagi, Sari Makmur</span><h1>Panen berkualitas,<br>langsung dari petani.</h1><p>Cari komoditas berdasarkan lokasi, jumlah, dan waktu panen.</p><label>${icon('search')}<input placeholder="Cari cabai, beras, jagung..."><button data-act="page" data-v="Cari Hasil Panen">Cari panen</button></label></div><div class="buyer-art">${icon('basket', 100)}</div></div>`
    + `<div class="category-row">${L([['rice', 'Beras & Padi'], ['leaf', 'Sayuran'], ['rice', 'Jagung'], ['leaf', 'Rempah'], ['basket', 'Lainnya']], x => `<button><span>${icon(x[0])}</span>${x[1]}<b>›</b></button>`)}</div>`
    + `<div class="heading-row compact"><div><h2>Penawaran terbaru</h2><p>Hasil panen yang baru ditambahkan di sekitar Anda</p></div>${seeAll('data-act="page" data-v="Cari Hasil Panen"')}</div>${harvestSearch()}`;
  return welcome('Rabu, 18 Juni 2025', 'Selamat pagi, Pak Budi', 'Semoga panen hari ini membawa hasil terbaik.', `<button class="btn primary" data-act="page" data-v="Buat Penawaran">${icon('plus')} Buat penawaran</button>`)
    + `<div class="user-summary"><article class="summary-main"><div><span>Nilai penawaran aktif</span><b>Rp38.750.000</b><small>2 penawaran sedang ditayangkan</small></div>${icon('rice', 72)}</article>${statCard('message', 'Calon Pembeli Baru', '4', '2 belum dibaca')}${statCard('basket', 'Panen Terjual', '12,5 ton', 'Dalam 3 transaksi')}</div>`
    + `<div class="heading-row compact"><div><h2>Harga komoditas favorit</h2><p>Diperbarui berdasarkan wilayah Anda</p></div>${seeAll('data-act="page" data-v="Informasi Harga"')}</div><div class="price-grid app-prices">${L(PRICES.slice(0, 3), p => priceCard(p))}</div>`
    + `<section class="panel">${panelTitle('Penawaran saya', 'Pantau perkembangan hasil panen yang ditawarkan', seeAll())}${table()}</section>`;
};

const workspace = (role, page, step) => {
  const staff = role === 'Admin' || role === 'Petugas';
  let content;
  if (page === 'Dashboard') content = role === 'Admin' ? adminDashboard() : role === 'Petugas' ? officerDashboard() : userDashboard(role);
  else if (page === 'Informasi Harga') content = pricePage();
  else if (page === 'Buat Penawaran' || (page === 'Penawaran Saya' && role === 'Pembeli')) content = offerWizard(role, step);
  else if (page === 'Cari Hasil Panen') content = harvestSearch();
  else if (page === 'Antrean Penawaran') content = queuePage();
  else if (page === 'Verifikasi Petani') content = verificationDetail();
  else content = genericPage(page, role);
  return `<div class="workspace ${staff ? 'staff' : 'user'}">${staff ? sidebar(role, page) : ''}<div class="app-shell">${staff ? topHeader(role, page) : userNav(role, page)}<main class="app-content">${content}</main></div></div>`;
};
