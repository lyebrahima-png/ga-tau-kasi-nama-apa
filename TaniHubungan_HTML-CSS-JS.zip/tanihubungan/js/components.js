/* Komponen kecil: setiap fungsi mengembalikan string HTML */
const L = (arr, fn) => arr.map(fn).join('');

const icon = (n, s = 20) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICON_PATHS[n]}</svg>`;

const logo = (light = false) => `<div class="logo ${light ? 'light' : ''}"><span class="logo-mark">${icon('leaf', 24)}</span><span>Tani<span>Hubungan</span></span></div>`;

const badge = (text, tone = 'green') => `<span class="badge ${tone}">${tone === 'green' ? icon('check', 13) : ''} ${text}</span>`;

const priceCard = (it, compact = false) => `<article class="price-card ${compact ? 'compact' : ''}"><div class="price-head"><span class="crop-icon">${icon(it.icon)}</span>${badge(it.status, it.tone)}</div><h3>${it.crop}</h3><div class="price"><strong>${it.price}</strong> <span>${it.unit}</span></div><div class="meta"><span>${icon('map', 15)}${it.market}</span><span>${icon('shield', 15)}${it.source}</span><span>${icon('clock', 15)}Dicatat ${it.date}</span></div>${it.tone === 'gray' ? `<div class="stale">${icon('warning', 15)} Bukan harga terkini</div>` : ''}</article>`;

const ROLES = ['Publik', 'Petani', 'Pembeli', 'Petugas', 'Admin'];
const roleSwitcher = role => `<div class="role-switcher"><span>Pratinjau peran</span>${L(ROLES, r => `<button class="${role === r ? 'active' : ''}" data-act="role" data-v="${r}">${r}</button>`)}</div>`;

const navIcon = n => n.includes('Harga') ? 'tag' : n.includes('Penawaran') ? 'basket' : n.includes('Verifikasi') ? 'shield' : n.includes('Laporan') ? 'file' : n.includes('Akun') || n.includes('Petani') ? 'users' : n === 'Dashboard' ? 'home' : n.includes('Negosiasi') ? 'message' : 'chart';

const PROFILE = { Admin: ['AR', 'Arif Rahman'], Petugas: ['DW', 'Dewi Wulandari'], Pembeli: ['SM', 'Sari Makmur'], Petani: ['BS', 'Budi Santoso'] };

const topHeader = (role, page) => { const [ini, nama] = PROFILE[role]; return `<header class="app-header"><div><span class="breadcrumb">${role} / ${page}</span><h2>${page}</h2></div><div class="header-actions"><label class="search">${icon('search')}<input placeholder="Cari di TaniHubungan..."></label><button class="icon-btn">${icon('bell')}<i></i></button><button class="profile"><span>${ini}</span><div><b>${nama}</b><small>${role}</small></div>${icon('menu', 17)}</button><button class="back-public" data-act="role" data-v="Publik">Keluar</button></div></header>`; };

const sidebar = (role, page) => `<aside class="sidebar">${logo(true)}<div class="side-role">${role === 'Admin' ? 'Pusat kendali platform' : 'Verifikator data pertanian'}</div><nav>${L(NAVS[role], n => `<button class="${page === n ? 'active' : ''}" data-act="page" data-v="${n}">${icon(navIcon(n))}<span>${n}</span>${n === 'Antrean Penawaran' ? '<b>12</b>' : ''}</button>`)}</nav><div class="side-help">${icon('message')}<b>Butuh bantuan?</b><span>Hubungi pusat dukungan</span><button>Hubungi dukungan</button></div></aside>`;

const userNav = (role, page) => `<nav class="user-nav">${logo()}<div>${L(NAVS[role].slice(0, 5), n => `<button class="${page === n ? 'active' : ''}" data-act="page" data-v="${n}">${n}</button>`)}</div><div class="user-nav-actions"><button class="icon-btn">${icon('bell')}<i></i></button><button class="avatar">${role === 'Petani' ? 'BS' : 'SM'}</button><button class="exit" data-act="role" data-v="Publik">Keluar</button></div></nav>`;

const statCard = (ic, label, value, note, tone = 'green') => `<article class="stat-card"><div class="stat-icon ${tone}">${icon(ic)}</div><div class="stat-label">${label}</div><b>${value}</b><span>${note}</span></article>`;

const barChart = () => `<div class="bar-chart"><div class="axis"><span>80</span><span>60</span><span>40</span><span>20</span><span>0</span></div><div class="bars">${L([42, 58, 47, 72, 64, 84, 76], (v, i) => `<div><span style="height:${v}%"></span><small>${['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'][i]}</small></div>`)}</div></div>`;

const statusTone = s => s.includes('Disetujui') || s === 'Aktif' || s === 'Terbaru' || s === 'Selesai' || s === 'Terkirim' ? 'green' : s.includes('Blok') || s === 'Prioritas' ? 'red' : s.includes('Revisi') || s.includes('diperbarui') || s === 'Diproses' ? 'yellow' : 'gray';

const table = (type = 'offer') => {
  const d = TABLES[type];
  return `<div class="table-wrap"><table><thead><tr>${L(d.heads, h => `<th>${h}</th>`)}</tr></thead><tbody>${L(d.rows, r => `<tr>${L(r, (c, j) => `<td>${j === d.heads.length - 2 ? badge(c, statusTone(c)) : j === d.heads.length - 1 ? `<button class="table-action">${c} ${icon('arrow', 14)}</button>` : j === 0 ? `<b>${c}</b>` : c}</td>`)}</tr>`)}</tbody></table><div class="pagination"><span>Menampilkan 1–4 dari 24 data</span><div><button>‹</button><button class="current">1</button><button>2</button><button>3</button><button>›</button></div></div></div>`;
};

const filters = (price = false) => `<div class="filters"><label>${icon('search')}<input placeholder="${price ? 'Cari komoditas atau pasar...' : 'Cari nama, komoditas, atau ID...'}"></label><button>${icon('filter')} Semua ${price ? 'komoditas' : 'status'}⌄</button><button>${icon('map')} Semua wilayah⌄</button><button>${icon('clock')} 30 hari terakhir⌄</button></div>`;
